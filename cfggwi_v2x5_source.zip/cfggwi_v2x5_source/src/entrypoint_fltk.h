#pragma once
#include <ctime>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Input_Choice.H>
#include <FL/Fl_Native_File_Chooser.H>
#include "flhli/flhli_main.h"
#include "mw_fl.h"
#include "hef/hef_str_args.h"
#include "hef/hef_str_piece.h"
using namespace hef;


extern GWI_Globals_T GWI_Globals;

