
#include "mw_fl.h"
#include "hef/hef_assert.h"
#include "hef/hef_file.h"
#include <stdint.h>		//uint8_t
#include "xehi_linux_helper.h"

GWI_Globals_T GWI_Globals;

CCfggwiMw::CCfggwiMw( int argc2, const char*const* argv2, const char* lbl, const char* szArgZeroDir )
	: Fl_Window( 330, 190, "" ), Success2(0), Canceled2(1), bErlvZeroOnCancel(0), bFileBrOpened(0)
	, TitleStr(lbl), uLastIdent(1000), BtnCancel(0)
	, strArgZeroDir(szArgZeroDir), EdtOnF4Key(0), EdtOnContextMnu(0), bContextMnuAsKey(0)
	, bF4SelectDir(0), Brr2(0), bStdout(0), bConfMode(0)
{
	size_range( 120, 100, 0, 0 );
	label( TitleStr.c_str() );
	std::string strCfgFn;
	bStdout   = !!atoi( hf_getCommandLineParameter<char>("--bStdout", argc2, argv2, EGCLPF_NOAUTODASH|EGCLPF_NOVALUE ).c_str() );
	bConfMode = !!atoi( hf_getCommandLineParameter<char>("--bConfMode", argc2, argv2, EGCLPF_NOAUTODASH|EGCLPF_NOVALUE ).c_str() );
	{
		const char* configAr[] = {"-c","--controls",0,};
		strCfgFn = hf_getCommandLineParameter2<char>( HfSCmdNames<char>(configAr), argc2, argv2, EGCLPF_NOAUTODASH );
		if( strCfgFn.empty() ){
			Msg = "No configuration JSON file on commandline, argument: -c or --controls.";
			return;
		}
	}
	{
		const char* configAr[] = {"-o","--output",0,};
		StrOutpFn = hf_getCommandLineParameter2<char>( HfSCmdNames<char>(configAr), argc2, argv2, EGCLPF_NOAUTODASH );
		if( StrOutpFn.empty() && !bStdout ){
			Msg = "No output file name on commandline, argument: -o or --output.";
			return;
		}
	}
	LsKeyVal_t lsDfItems;
	{
		std::string strDfltsFn;
		const char* configAr[] = {"-d","--defaults",0,};
		strDfltsFn = hf_getCommandLineParameter2<char>( HfSCmdNames<char>(configAr), argc2, argv2, EGCLPF_NOAUTODASH );
		//printf("strDfltsFn: [%s]\n", strDfltsFn.c_str() );
		if( !strDfltsFn.empty() ){
			if( !assignConfigDefaults( strDfltsFn.c_str(), lsDfItems ) )
				return;
		}
	}
	{
		jnSParseError<char> err2;
		jnValue<char> jsnCfg;
		bool rs = jn_QuickFileParse( strCfgFn.c_str(), jsnCfg, 0, &err2 );
		if(!rs){
			Msg = HfArgs(
					"Failed parsing JSON file (.../%1).\n"
					"%2\n"
					"Line: %3")
							.arg( hf_basename(strCfgFn.c_str()) )
							.arg( err2.msg.c_str() )
							.arg( err2.uLine ).c_str();
			return;
		}
		{
			std::string str;
			str = hf_getCommandLineParameter2<char>( HfSCmdNames<char>("-bErlvZeroOnCancel"), argc2, argv2, EGCLPF_NOAUTODASH );
			if( !str.empty() )
				bErlvZeroOnCancel = !!atoi( str.c_str() );
			str = jsnCfg.getPropertyByName2("bErlvZeroOnCancel","").c_str();
			if( !str.empty() )
				bErlvZeroOnCancel = !!atoi( str.c_str() );
		}
		std::vector<jnValue<char> >::const_iterator a;
		// 'items' array.
		size_t i;
		const jnValue<char>& vItems = jsnCfg.getPropertyByName("items");
		for( a = vItems.children().begin(), i=0; a != vItems.children().end(); ++a, i++ ){
			SCfItem sci;
			//printf("%s: %s\n", a->getName().c_str(), a->toSTDString().c_str() );
			if( !a->isObjectOrArray() )
				continue;
			sci.strDesc = a->getPropertyByName2("szDesc","").c_str();
			//if( sci.strDesc.empty() ){
			//	Msg = HfArgs("No 'szDesc' property, item:%1.").arg(i+1).c_str();
			//	return;
			//}
			sci.strVarname = a->getPropertyByName2("szVarname","").c_str();
			if( sci.strVarname.empty() ){
				Msg = HfArgs("No 'szVarname' property, item:%1.").arg(i+1).c_str();
				return;
			}
			sci.strType = a->getPropertyByName2("szType","string").c_str();
			sci.strDflt = a->getPropertyByName2("szDefault","").c_str();
			if(0){
			}else if( sci.strType == "string" ){
				sci.eType = ECFIT_Str;
			}else if( sci.strType == "bool" ){
				sci.eType = ECFIT_Bool;
			}else if( sci.strType == "enum" ){
				sci.eType = ECFIT_Enum;
				if( !parseEnums( *a, i, sci.lsEnums ) )
					return;
			}else{
				Msg = HfArgs("Unknown type ('szType'), item:%d.").arg(i+1).c_str();
				return;
			}
			std::string str = a->getPropertyByName2("bDisabled","").c_str();
			if( !str.empty() ){
				sci.bDisabled = atoi( str.c_str() );
			}
			sci.ident = ++uLastIdent;
			Items2.push_back( sci );
		}
		//printf("Got %d items.\n", (int)Items2.size() );
		fprintf( stderr, "Got %d items.\n", (int)Items2.size() );

		const jnValue<char>& vMain = jsnCfg.getPropertyByName("main");
		std::string str = vMain.getPropertyByName2("szWindowTitle","").c_str();
		if( !str.empty() ){
			TitleStr = str;
			this->label( TitleStr.c_str() );
		}
	}
	{
		IconFn = hf_getCommandLineParameter2<char>( HfSCmdNames<char>("--mainicon"), argc2, argv2, EGCLPF_NOAUTODASH );
		IconFn = ( ( IconFn == "none" || IconFn == "0" ) ? "<none>" : IconFn.c_str() );
	}
	size_t uRectSizeOut[2] = { 99,77, };
	if( !createGuiWidgets( uRectSizeOut, lsDfItems ) )
		return;
	size_t uNewW = uRectSizeOut[0] + decorated_w() - w();
	size_t uNewH = uRectSizeOut[1] + decorated_h() - h();
	uNewH = std::max<size_t>( uNewH, 400 );
	this->size( uNewW, uNewH );

	flhli_MakeWindowCenterOnScreen( this, 0x0 );	// center mw on screen.

	//Fl::add_handler( Fl_Event_Handler ha );
	Success2 = 1;
}
CCfggwiMw::~CCfggwiMw()
{
}
int CCfggwiMw::handle( int e )
{
	static size_t flx = FLHIEFHF_AltPlusDownForCbx|FLHIEFHF_CtrlQClosesMw|FLHIEFHF_NextPrevForCbx;
	//flx |= FLHIEFHF_EscDontCloseMw;
	//if( bFileBrOpened )
	//	return 0;
	if( flhli_HelperFunctionalityOnHandle( e, flx, this ) )
		return 1;
	if( e == FL_KEYDOWN ){
		int const key2 = Fl::event_key();
		if( key2 == FL_Enter || key2 == FL_KP_Enter ){
			if( !( Fl::event_state() & (FL_CTRL|FL_ALT|FL_SHIFT|FL_META) ) ){
				Fl_Widget* wgt = Fl::focus();
				if( wgt == BtnCancel ){
					return 1;
				}else{
					onButtonOkAction2();
					return 1;
				}
			}
		}
		// F2 key in text edit: switch-select different word parts functionality.
		if( key2 == FL_F+2 ){
			Fl_Input* edt3 = dynamic_cast<Fl_Input*>( Fl::focus() );
			//Fl_Input,Fl_Check_Button,Fl_Input_Choice
			if( edt3 ){ // also if Fl_Input is part of Fl_Input_Choice.
				consecutiveF2KeyFunctionality( edt3 );
			}
		}else if( key2 == FL_F+4 || key2 == FL_F+5 ){ //F4 key in text edit: open the browse-for-file dialogbox.
			Fl_Input* edt4 = dynamic_cast<Fl_Input*>( Fl::focus() );
			if( edt4 ){
				bF4SelectDir = ( key2 == FL_F+5 ); //if F5, select dir mode.
				EdtOnF4Key = edt4;
				Fl::add_timeout( 0.0, cbF4KeyTimeout, this );
			/*	bool bDirMode = ( key2 == FL_F+5 ); //if F5, select dir mode.
				if( !Brr2 )
					Brr2 = new Fl_File_Chooser("","*",0,"");
				std::string str = ( edt4->value() && *edt4->value() ? edt4->value() : "" );
				Brr2->callback( CCfggwiMw::calbOnBrwForFile, this );
				Brr2->value( str.empty() ? "." : str.c_str() );
				Brr2->preview(0);
				Brr2->type( (!bDirMode ? Fl_File_Chooser::SINGLE : Fl_File_Chooser::DIRECTORY) | Fl_File_Chooser::CREATE );
				Brr2->label( !bDirMode ? "Select File" : "Select Directory" );
				Fl_Button* btn = new Fl_Button(0,0,64,0,"");
				Brr2->add_extra( btn );
				Fl_Group* br3 = btn->parent();
				btn->hide();
				//add( br3 );
				Brr2->show();
				flhli_MakeWindowCenterInsideParent( br3, this, FLHIWCIP_InsideOnScreen );
				//*/
			}
		}else if( key2 == FL_F+10 || key2 == FL_Menu ){ //context menu using keys.
			Fl_Input* edt4 = dynamic_cast<Fl_Input*>( Fl::focus() );
			if( edt4 ){
				EdtOnContextMnu = edt4;
				bContextMnuAsKey = 1;
				Fl::add_timeout( 0.0, cbContextMenuTimeout, this );
			}
		}
	}else if( e == FL_SHOW ){ //FL_SHOW
#		ifdef Fl_X_H // [A68YrWJkhbcZ]
			static bool bOnce = 0;
			do{
				if( bOnce )
					break;
				bOnce = 1;
				Window xwnd = fl_xid( this ); //fl_window
				if( !xwnd || !fl_display )
					break;
				if( IconFn == "<none>" )
					break;
				if( IconFn.empty() ){
					IconFn = "mainicon.tga";
					if( !hf_FileExists( IconFn.c_str() ) ){
						IconFn = strArgZeroDir + "/mainicon.tga";
						if( !hf_FileExists( IconFn.c_str() ) )
							break;
					}
				}else if( !hf_FileExists( IconFn.c_str() ) ){
					//printf()
					fprintf(stderr,"ERROR: Icon file not found.\n");
					fprintf(stderr,"File: [%s]\n", IconFn.c_str() );
					break;
				}
				std::vector<unsigned long> pxs2; bool rs2; std::string err;
				//printf("xwnd: %d, fl_display: %d\n", (int)xwnd, (int)(long)fl_display );
				rs2 = xehi_LoadTgaIconAsUlongs( IconFn.c_str(), pxs2, &err );
				if( rs2 )
					rs2 = xehi_SetWindowIcon( fl_display, xwnd, &pxs2[0], (int)pxs2.size(), &err );
				if( !rs2 ){
					//printf
					fprintf(stderr,"ERROR: Load window icon failed.\n");
					fprintf(stderr,"Message: [%s]\n", err.c_str() );
				}
			}while(0);
#		endif // end Fl_X_H [A68YrWJkhbcZ]

	}else if( e == FL_FOCUS || e == FL_ACTIVATE ){ //FL_ACTIVATE
		//printf("fa...\n");

	}else if( e == FL_PUSH ){
		if( Fl::event_button() == FL_RIGHT_MOUSE ){
			Fl_Input* edt4 = dynamic_cast<Fl_Input*>( Fl::focus() );
			if( edt4 ){
				Fl_Input_Choice* cbx3 = dynamic_cast<Fl_Input_Choice*>( edt4->parent() );
				Fl_Widget* wgt = ( cbx3 ? cbx3 : dynamic_cast<Fl_Widget*>(edt4) );
				int wx,wy,xx = Fl::event_x(), yy = Fl::event_y();
				flhli_GetWidgetAbsolutePos( wgt, this, wx, wy );
				int rct[] = { wx, wy, wx+wgt->w(), wy+wgt->h(), };
				if( xx >= rct[0] && xx < rct[2] ){
					if( yy >= rct[1] && yy < rct[3] ){
						EdtOnContextMnu = edt4;
						bContextMnuAsKey = 0;
						Fl::add_timeout( 0.0, cbContextMenuTimeout, this );
						return 0;
					}
				}
			}
		}
	}

	int ret = Fl_Group::handle(e);
	return ret;
}

bool CCfggwiMw::parseEnums( const jnValue<char>& item2, size_t itmIndex, LsKeyVal_t& outp )
{
	std::vector<jnValue<char> >::const_iterator a;
	const jnValue<char>* vEnums = &item2.getPropertyByName("enums");
	if( vEnums->isInvalid() || !vEnums->isObjectOrArray() ){
		vEnums = 0;
	}
	if( !vEnums ){
		// try backward compat, specific.enums: [...].
		vEnums = &item2.getPropertyByName("specific").getPropertyByName("enums");
		if( vEnums->isInvalid() || !vEnums->isObjectOrArray() )
			vEnums = 0;
	}
	if( !vEnums ){
		Msg = HfArgs("No enumerated property ('enums'), item:%1.")
				.arg(itmIndex+1).c_str();
		return 0;
	}
	size_t k;
	for( a = vEnums->children().begin(), k=0; a != vEnums->children().end(); ++a, k++ ){
		std::pair<std::string,std::string> enumitm;
		if( a->isObjectOrArray() ){
			const std::vector<jnValue<char> >* chis = &a->children();
			if( chis->size() < 2 ){
				Msg = HfArgs(
						"Invalid enumerated property %1, item:%2.\n"
						"Must be made out of 2 elements.")
							.arg( k + 1 )
							.arg( itmIndex + 1 ).c_str();
				return 0;
			}
			enumitm.first  = (*chis)[0].toSTDString().c_str();
			enumitm.second = (*chis)[1].toSTDString().c_str();
			//printf("first: [%s]\n", enumitm.first.c_str() );
		}else{
			enumitm.first  = a->toSTDString().c_str();
			enumitm.second = enumitm.first;
		}
		outp.push_back( enumitm );
	}
	return 1;
}
// uRectSizeOut - returns size of rect of created widgets.
bool CCfggwiMw::createGuiWidgets( size_t uRectSizeOut[2], const LsKeyVal_t& lsDfItems2 )
{
	LsKeyVal_t::const_iterator d;
	std::vector<SCfItem>::iterator a;
	size_t uBox[4] = { 0,0,0,0, };
	//
	//FL_NORMAL_SIZE *= fUiScale;
	const float fUiScale = GWI_Globals.fUiScale;
	static const size_t uLblH = 37 * fUiScale, uLblW = 192 * fUiScale;
	static const size_t uWgtH = 24 * fUiScale, uWgtW = 192 * fUiScale;
	static const size_t uHSpacing = 4 * fUiScale, uVSpacing = 4 * fUiScale;
	static const size_t uHMargin = 6 * fUiScale, uVMargin = 16 * fUiScale;
	//
	static const size_t uButtonW = uWgtW / 3;
	const size_t uItmH = std::max( uLblH, uWgtH );
	size_t i;
	for( a = Items2.begin(), i=0; a != Items2.end(); ++a, i++ ){
		uBox[0] = uHMargin + uLblW + uHSpacing;
		uBox[1] = uVMargin + i*uItmH + i*uVSpacing;
		uBox[2] = uWgtW;
		uBox[3] = uWgtH;
		Fl_Widget* wgt2 = 0;
		std::string strDflt2;
		{
			HfPredTTPair<std::string,std::string> pred( a->strVarname.c_str() );
			d = std::find_if( lsDfItems2.begin(), lsDfItems2.end(), pred );
			if( d != lsDfItems2.end() ){
				strDflt2 = d->second.c_str();
			}else if( !a->strDflt.empty() ){
				strDflt2 = a->strDflt;
			}
		}

		if(0){
		}else if( a->eType == ECFIT_Str ){
			Fl_Input* edt2 = new Fl_Input( uBox[0], uBox[1], uBox[2], uBox[3] );
			//edt2->textfont( FL_TIMES );
			//edt2->textsize( 24 );
			//edt2->label_.font = FL_HELVETICA;
			//edt2->label_.size = (uchar)FL_NORMAL_SIZE;
			//edt2->setfont();
			wgt2 = edt2;
			if( !strDflt2.empty() )
				edt2->replace( 0, -1, strDflt2.c_str(), 0 );
		}else if( a->eType == ECFIT_Bool ){
			Fl_Check_Button* chk =
					new Fl_Check_Button( uBox[0], uBox[1], uBox[2], uBox[3] );
			bool bChecked = !!atoi( strDflt2.c_str() );
			chk->value( bChecked );
			wgt2 = chk;
		}else if( a->eType == ECFIT_Enum ){
			Fl_Input_Choice* cbx2 = new CMyFl_Input_Choice( uBox[0], uBox[1], uBox[2], uBox[3] );
			wgt2 = cbx2;
			flhli_MakeComboboxLessFocusRO( cbx2 );
			{
				LsKeyVal_t::const_iterator b;
				for( b = a->lsEnums.begin(); b != a->lsEnums.end(); ++b ){
					cbx2->add( b->second.c_str() );
				}
			}
			cbx2->value(0);
			if( !strDflt2.empty() ){
				LsKeyVal_t::const_iterator c;
				HfPredTTPair<std::string,std::string> pred( strDflt2.c_str() );
				c = std::find_if( a->lsEnums.begin(), a->lsEnums.end(), pred );
				if( c != a->lsEnums.end() ){
					int idx = c - a->lsEnums.begin();
					cbx2->value( idx );
				}
			}
		}else{
			hf_assert(0);
		}
		hf_assert(wgt2);
		wgt2->user_data( (void*)a->ident );
		Fl_Box* lbl2 = new Fl_Box( uHMargin, uBox[1], uLblW, uLblH, a->strDesc.c_str() );
		lbl2->align( FL_ALIGN_TOP_LEFT|FL_ALIGN_INSIDE|FL_ALIGN_WRAP|FL_ALIGN_CLIP );
		//lbl2->labelfont( FL_COURIER );
		//lbl2->labelsize( FL_NORMAL_SIZE );
		//lbl2->box( FL_BORDER_BOX );
		//lbl2->box( FL_PLASTIC_DOWN_FRAME );
		lbl2->box( FL_GTK_THIN_DOWN_FRAME );
		if( a->bDisabled ){
			hf_assert(wgt2);
			wgt2->deactivate();
		}
		if( a->strDesc.size() > 42 )
			lbl2->tooltip( a->strDesc.c_str() );
	}
	uRectSizeOut[0] = uHMargin + uBox[0] + uBox[2];
	uRectSizeOut[1] = uVMargin + uBox[1] + uBox[3];
	{
		size_t k, uBx[4] = {0,0,0,0,};
		uBx[0] = uHMargin + uLblW + uHSpacing;
		uBx[1] = uVMargin + i*uItmH + i*uVSpacing;
		uBx[2] = uButtonW;
		uBx[3] = uWgtH;
		Fl_Button* btnOk = new Fl_Button( uBx[0], uBx[1], uBx[2], uBx[3], "OK" );
		btnOk->callback( onButtonOkAction, (void*)this );
		//for( k=0; k < sizeof(uBx)/sizeof(uBx[0]); k++ )
		//	uBox[k] = std::max( uBox[k], uBx[k] );
		uBx[0] = uHMargin + uLblW + uHSpacing + uButtonW + uHSpacing;
		BtnCancel = new Fl_Button( uBx[0], uBx[1], uBx[2], uBx[3], "Cancel" );
		BtnCancel->callback( onButtonCaAction, (void*)this );
		//for( k=0; k < sizeof(uBx)/sizeof(uBx[0]); k++ )
		//	uBox[k] = std::max( uBox[k], uBx[k] );
		uRectSizeOut[0] = std::max( uRectSizeOut[0], uBx[0] + uBx[2] + uHMargin );
		uRectSizeOut[1] = std::max( uRectSizeOut[1], uBx[1] + uBx[3] + uVMargin );
	}
	return 1;
}
bool CCfggwiMw::assignConfigDefaults( const char* szCfgFn, LsKeyVal_t& lsDfItemsOu )
{
	//LsKeyVal_t lsDfItems;
	std::string ext = hf_basename3(szCfgFn).second.c_str();
	if( !hf_strcasecmp( ext.c_str(), "INI" ) ){
		//printf("Parsing INI: [.../%s]\n", hf_basename(szCfgFn) );
		if( !hf_ParseSimpleIniFile( szCfgFn, lsDfItemsOu ) ){
			Msg = "Unknown INI parse error.";
			return 0;
		}
	}else{
		jnValue<char> jsnDflts;
		bool rs = jn_QuickFileParse( szCfgFn, jsnDflts );
		if(!rs){
			Msg = HfArgs("Failed parsing defaults JSON file (.../%1).")
					.arg( hf_basename(szCfgFn) )
					.c_str();
			return 0;
		}
		std::vector<jnValue<char> >::const_iterator a;
		for( a = jsnDflts.children().begin(); a != jsnDflts.children().end(); ++a ){
			lsDfItemsOu.push_back( std::make_pair(
					a->getName().c_str(), a->toSTDString().c_str() ) );
		}
	}
	//printf()
	fprintf( stderr, "Defaults file, num items: %d\n", (int)lsDfItemsOu.size() );

	//LsKeyVal_t::const_iterator b;
	//for( b = lsDfItemsOu.begin(); b != lsDfItemsOu.end(); ++b ){
	//	printf("%s: %s\n", b->first.c_str(), b->second.c_str() );
	//}

	return 1;
}
void CCfggwiMw::onButtonOkAction( Fl_Widget* wgt, void* data )
{
	CCfggwiMw* thisp = (CCfggwiMw*)data;
	thisp->onButtonOkAction2();
}
void CCfggwiMw::onButtonCaAction( Fl_Widget* wgt, void* data )
{
	CCfggwiMw* thisp = (CCfggwiMw*)data;
	thisp->onButtonCaAction2( wgt );
}
void CCfggwiMw::onButtonCaAction2( Fl_Widget* wgt )
{
	Canceled2 = 1;
	hide();
}
Fl_Widget* CCfggwiMw::findConfigWidget( size_t ident2 )const
{
	size_t i;
	for( i=0; i < children(); i++ ){
		Fl_Widget* wgt = child( i );
		size_t data2 = (size_t)wgt->user_data();
		if( data2 == ident2 ){
			return wgt;
		}
	}
	return 0;
}
void CCfggwiMw::getCfItemsAsKeyValPairs( LsKeyVal_t& outp )const
{
	std::vector<SCfItem>::const_iterator a;
	Fl_Input* edt; Fl_Check_Button* chk; Fl_Input_Choice* cbx;
	size_t i;
	for( a = Items2.begin(), i=0; a != Items2.end(); ++a, i++ ){
		Fl_Widget* wgt = findConfigWidget( a->ident );
		hf_assert(wgt);
		std::string val;
		if(0){
		}else if( (edt = dynamic_cast<Fl_Input*>(wgt)) ){
			val = edt->value();
			//printf("%s: [%s]\n", a->strVarname.c_str(), val.c_str() );
		}else if( (chk = dynamic_cast<Fl_Check_Button*>(wgt)) ){
			bool val2 = !!chk->value();
			//printf("%s: %d\n", a->strVarname.c_str(), (int)val2 );
			val = HfArgs("%1").arg( (int)val2 ).c_str();
		}else if( (cbx = dynamic_cast<Fl_Input_Choice*>(wgt)) ){
			size_t idx = (size_t)cbx->menubutton()->value();	//Fl_Menu_Button
			hf_assert( idx < a->lsEnums.size() );
			val = a->lsEnums[idx].first.c_str();
			//printf("%s: [%s]\n", a->strVarname.c_str(), a->lsEnums[idx].first.c_str() );
		}
		outp.push_back( std::make_pair( a->strVarname, val.c_str() ) );
	}
}
void CCfggwiMw::onButtonOkAction2()
{
	LsKeyVal_t values2;
	getCfItemsAsKeyValPairs( values2 );

	//hf_assert( !StrOutpFn.empty() );
	LsKeyVal_t::const_iterator a; std::string str;

	bool bIsIni = 0;
	std::string ext2 = hf_basename3(StrOutpFn.c_str()).second.c_str();
	if( !hf_strcasecmp(ext2.c_str(),"INI") || !hf_strcasecmp(ext2.c_str(),"CONF") )
		bIsIni = 1;

	if( bIsIni || bConfMode ){
		for( a = values2.begin(); a != values2.end(); ++a ){
			str += HfArgs("%1=\"%2\"\n")
				.arg( a->first.c_str() )
				.arg( a->second.c_str() ).c_str();
		}
	}else{
		str += "\x7B\n";
		for( a = values2.begin(); a != values2.end(); ++a ){
			str += HfArgs("\t%1: \"%2\",\n")
				.arg( a->first.c_str() )
				.arg( a->second.c_str() )
				.c_str();
		}
		str += "\x7D\n"; //7b="{", 7d="}"
	}
	if(bStdout){
		printf("%s\n", str.c_str() );
	}
	if( !StrOutpFn.empty() ){
		bool rs = hf_PutFileBytes( StrOutpFn.c_str(), str.c_str(), str.size() );
		if(!rs){
			Msg = HfArgs("Failed writing output file: [.../%1]")
					.arg( hf_basename(StrOutpFn.c_str()) )
					.c_str();
			Success2 = 0;
			fprintf( stderr, "ERROR: %s\n", Msg.c_str() );
			return;
		}
	}

	Canceled2 = 0;
	hide();
}
std::vector<CCfggwiMw::SCfItem>::iterator CCfggwiMw::
findConfigWidget2( Fl_Widget* wgt )
{
	std::vector<SCfItem>::iterator a;
	//
	//std::vector<SCfItem>::const_iterator a;
	for( a = Items2.begin(); a != Items2.end(); ++a ){
		//findConfigWidget( a->ident ) == wgt
		//->menubutton()
		;
	}
	;
	return a;
}
CMyFl_Input_Choice::
CMyFl_Input_Choice( int xx, int yy, int ww, int hh , const char* lbl )
	: Fl_Input_Choice( xx, yy, ww, hh, lbl )
{
}
int CMyFl_Input_Choice::handle( int e )
{
	// TODO:
	// code moved to: flhli_FilterInputChoiceEventsAddCommonActions()
	//e==;

/*	if( e == FL_KEYDOWN ){
		int k = Fl::event_key();
		if( k=='-' || k=='[' || k==',' || k==FL_Left ){
			value( std::max<int>( menubutton()->value()-1, 0 ) );
			return 1;
		}
		if( k=='=' || k==']' ||k=='.' || k==FL_Right ){
			int num = flhli_GetItemCountForInputChoice( this );
			value( std::min<int>( menubutton()->value()+1, (num? num-1 : 0) ) );
			return 1;
		}
	}//*/
	return Fl_Input_Choice::handle( e );
}

bool CCfggwiMw::isNonalphanumAnsiChar( int inp )
{
	if( inp && inp <= 127 ){
		if( !isalnum( (char)inp ) )
			return 1;
	}
	return 0;
}
void CCfggwiMw::
strToSelectableParts( const char* sz2, std::vector<SStrSelPart>& outp, int nCursor, int* ouCurPartIdx )
{
	int idx = 0, chr2, len2 = hf_strlen(sz2), len3, i;
	bool bAlnum = 0;
	if(ouCurPartIdx) *ouCurPartIdx = 0;
	//
	for( i=0; idx < len2; idx += len3, i++ ){
		chr2 = (int)fl_utf8decode( sz2+idx, sz2+len2, &len3 );
		if( !i ){
			bAlnum = !isNonalphanumAnsiChar(chr2);
			outp.push_back( SStrSelPart() );
			outp.back().bAlnum = bAlnum;
			outp.back().nStart = 0;
		}
		if( bAlnum ){
			if( isNonalphanumAnsiChar(chr2) ){
				bAlnum = 0;
				outp.push_back( SStrSelPart() );
				outp.back().bAlnum = 0;
				outp.back().nStart = idx;
			}
		}else{
			if( !isNonalphanumAnsiChar(chr2) ){
				bAlnum = 1;
				outp.push_back( SStrSelPart() );
				outp.back().bAlnum = 1;
				outp.back().nStart = idx;
			}
		}
		outp.back().lenUc++;
		outp.back().str.append( sz2+idx, len3 );
		if( idx < nCursor ){
		}
	}
	// update cursor pos.
	std::vector<SStrSelPart>::iterator a;
	for( a = outp.begin(), i=0; a != outp.end(); ++a, i++ ){
		int endp = a->nStart + a->str.size();
		if( a->nStart <= nCursor && endp > nCursor ){
			a->bCursor = 1;
			a->bCursorAtFirst = a->nStart == nCursor;
			if(ouCurPartIdx)
				*ouCurPartIdx = i;
			break;
		}
	}
}
/// Toggles text selection in edit box (Fl_Input*).
/// Typically consectutive F2 key presses.
/// * If text is a filename that has extension:
///   - if selected all, selects base-name-part
///   - If selected is base-name-part, selects extension-part
/// * otherwise selects next word part,
/// Word part is considered following:
/// * letters, one or more consecutively;
/// * syjmbol or space characters, two or more consecutively, (ie. non ANSI alphanumerics).
void CCfggwiMw::consecutiveF2KeyFunctionality( Fl_Input* edt )
{
	const char* lbl = edt->value();
	std::string strTxt = ( lbl ? lbl : "" );
	if( strTxt.empty() )
		return;
	int selA = std::min<int>( edt->position(), edt->mark() );
	int selB = std::max<int>( edt->position(), edt->mark() );
	selB = std::min<int>( selB, strTxt.size() );
	selA = std::min<int>( selA, strTxt.size() );
	int selL = selB - selA;

	bool bAllSlctd = ( !selA && selL == strTxt.size() );

	std::pair<std::string,std::string> fnParts;
	fnParts = hf_basename3( strTxt.c_str(), HF_EBN3F_ExtAnyChars, 32 );
	//printf("fn: [%s], ext:[%s]\n", fnParts.first.c_str(), fnParts.second.c_str() );

	if( bAllSlctd ){ // if selected all.
		if( !fnParts.second.empty() ){ // if selected all and is filename -> select filename part.
			edt->position( 0, fnParts.first.size() );
			return;
		}
	}else{
		int endp = std::min<int>( selA + selL, strTxt.size() );
		std::string strSel = strTxt.substr( selA, endp - selA );
		if( strSel == fnParts.first ){ // if selection is filename -> select ext part.
			int bgn2 = fnParts.first.size() + 1;
			int end2 = bgn2 + fnParts.second.size();
			edt->position( bgn2, end2 );
			return;
		}
	}
	//
	// next-word-part selection advance...
	//
	if( selB >= strTxt.size() ){
		selB = 0;
	}
	std::vector<SStrSelPart> sparts; int nCurPart = 0;
	strToSelectableParts( strTxt.c_str(), sparts, selB, &nCurPart );
	if( nCurPart < sparts.size() ){
		int nNextPart = 0;
		if( sparts[nCurPart].bCursorAtFirst ){
			nNextPart = nCurPart;
		}else{
			nNextPart = nCurPart + 1;
		}
		if( nNextPart < sparts.size() ){
			if( !sparts[nNextPart].bAlnum && sparts[nNextPart].lenUc == 1 ){
				if( nNextPart+1 < sparts.size() )
					nNextPart++;
			}
			int indexA = sparts[nNextPart].nStart;
			int indexB = sparts[nNextPart].str.size() + indexA;
			edt->position( indexA, indexB );
		}
	}
}
void CCfggwiMw::calbOnBrwForFile( Fl_File_Chooser* brr, void* user2 )
{
	CCfggwiMw* this2 = (CCfggwiMw*)user2;
	hf_assert( brr );
	hf_assert( this2 );
	this2->calbOnBrwForFile2( brr );
}
void CCfggwiMw::calbOnBrwForFile2( Fl_File_Chooser* brr )
{
	const char* fnm = ( brr->count() ? brr->value() : "" );
	if( !brr->shown() ){
		if( EdtOnF4Key ){
			EdtOnF4Key->value( fnm );
			EdtOnF4Key = 0;
		}

	}
}
void CCfggwiMw::cbContextMenuTimeout( void* user2 )
{
	CCfggwiMw* thisp = (CCfggwiMw*)user2;
	thisp->cbContextMenuTimeout2( user2 );
}


void CCfggwiMw::cbContextMenuTimeout2( void* user2 ) //cbContextMenuTimeout
{
	if(!EdtOnContextMnu)
		return;
	//printf("[%s]\n", EdtOnContextMnu->value() );
	// fix dissapearing cursor in edit-box when right-mouse is pressed.
	cursor(FL_CURSOR_DEFAULT); //FL_CURSOR_DEFAULT,FL_CURSOR_CROSS
	Fl_Menu_Item mis[] = {
		{ "Cu&t",         0, 0, (void*)EMI_Cut, },//Cut
		{ "&Copy",        0, 0, (void*)EMI_Copy, },
		{ "&Paste",       0, 0, (void*)EMI_Paste, },
		{ "&Delete",      0, 0, (void*)EMI_Del, FL_MENU_DIVIDER, },
		{ "Select &All",  0, 0, (void*)EMI_SelAll, },
		{ "Select &File...",      0, 0, (void*)EMI_SelFile, },
		{ "Select &Directory...", 0, 0, (void*)EMI_SelDir, },
		{ "Path To &Relative",    0, 0, (void*)EMI_PathToRel, },
		{ 0, },
	};
	hf_assert( EMI_Del    == (int)(size_t)mis[EMI_Del   ].user_data_ );
	hf_assert( EMI_SelDir == (int)(size_t)mis[EMI_SelDir].user_data_ );
	int bgn2 = EdtOnContextMnu->position();
	int end2 = EdtOnContextMnu->mark();
	if( bgn2 == end2 ){
		mis[EMI_Cut].flags |= FL_MENU_INACTIVE;
		mis[EMI_Copy].flags |= FL_MENU_INACTIVE;
		mis[EMI_Del].flags |= FL_MENU_INACTIVE;
	}else if( bgn2 > end2 ){
		std::swap( bgn2, end2 );
	}
	int xy[] = { Fl::event_x(), Fl::event_y(), };
	if(bContextMnuAsKey){
		Fl_Input_Choice* cbx3 = dynamic_cast<Fl_Input_Choice*>( EdtOnContextMnu->parent() );
		Fl_Widget* wgt = ( cbx3 ? cbx3 : dynamic_cast<Fl_Widget*>(EdtOnContextMnu) );
		flhli_GetWidgetAbsolutePos( wgt, this, xy[0], xy[1] );
	}
	const Fl_Menu_Item *mi = mis->popup( xy[0], xy[1], 0, ( bContextMnuAsKey ? 0 : &mis[0] ), 0 );
	if(mi){
		//printf("mi: %s\n", mi->text );
		int sel = (int)(size_t)mi->user_data_;
		if( 0 ){
		}else if( sel == EMI_Cut || sel == EMI_Copy ){
			EdtOnContextMnu->copy(0);
			EdtOnContextMnu->copy(1);
		}else if( sel == EMI_Paste ){
			Fl::paste( *EdtOnContextMnu, 1 );
		}else if( sel == EMI_SelAll ){
			EdtOnContextMnu->position( 0, EdtOnContextMnu->size() );
		}else if( sel == EMI_SelFile || sel == EMI_SelDir ){
			bF4SelectDir = ( sel == EMI_SelDir ? 1 : 0 );
			EdtOnF4Key   = EdtOnContextMnu;
			Fl::add_timeout( 0.0, cbF4KeyTimeout, this );
		}else if( sel == EMI_PathToRel ){
			std::string str, strVal = EdtOnContextMnu->value();
			std::string strCwd = hf_getcwd();
			str = hf_GetRelativePath( strCwd.c_str(), strVal.c_str(), HF_EGRP_DotMarkIfCwd );
			EdtOnContextMnu->value( str.c_str() );
		}else if( sel == EMI_Del ){
			// do nothing.
		}else{
			//printf()
			fprintf(stderr,"Unknown context menu selection.\n");
		}
		if( sel == EMI_Del || sel == EMI_Cut ){
			if( bgn2 < end2 )
				EdtOnContextMnu->replace( bgn2, end2, "", 0 );
		}
	}
	EdtOnContextMnu = 0;
}
void CCfggwiMw::cbF4KeyTimeout( void* user2 )
{
	CCfggwiMw* this2 = (CCfggwiMw*)user2;
	hf_assert( this2 );
	this2->cbF4KeyTimeout2();
}
void CCfggwiMw::cbF4KeyTimeout2() //cbF4KeyTimeout
{
/*	struct{
		const char* a, *b;
	} ssx[] = {
		{"/tmp/abc",
		 "/tmp/abc/xxx/yyy",},
		 // --> "xxx/yyy"
		{"/tmp/abc",
		 "/tmp/abc",},
		 // --> ""
		{"/tmp/abc/def/ghi",
		 "/tmp/abc",},
		 // --> "../.."
		{"/tmp/abc/def/ghi",
		 "/tmp/abc/xxx/yyy",},
		 // --> "../../xxx/yyy"
		{"/bin",
		 "/tmp/abc/xxx/yyy",},
		 // --> "../tmp/abc/xxx/yyy"
		{"/",
		 "/tmp/abc/xxx/yyy",},
		 // --> "/tmp/abc/xxx/yyy"
		{"/abc/def/ghi",
		 "/xxx",},
		 // --> "../../../xxx"
		{"/x/y",
		 "/a/b/c/d",},
		 // --> ../../a/b/c/d
		{"c:/abc",
		 "c:/abc/def",},
		 // --> ../../a/b/c/d
		{0,0,},
	};
	std::string strRel;
	for( int i=0; ssx[i].a; i++ ){
		strRel = hf_GetRelativePath( ssx[i].a, ssx[i].b, 0 );
		printf("a: [%s]\n", ssx[i].a );
		printf("b: [%s]\n", ssx[i].b );
		printf("strRel: [%s]\n", strRel.c_str() );
	}
	//*/
	if( !Brr2 )
		Brr2 = new Fl_File_Chooser("","*",0,"");
	std::string str = ( EdtOnF4Key->value() && *EdtOnF4Key->value() ? EdtOnF4Key->value() : "" );
	Brr2->callback( CCfggwiMw::calbOnBrwForFile, this );
	Brr2->value( str.empty() ? "." : str.c_str() );
	Brr2->preview(0);
	Brr2->type( (!bF4SelectDir ? Fl_File_Chooser::SINGLE : Fl_File_Chooser::DIRECTORY) | Fl_File_Chooser::CREATE );
	Brr2->label( !bF4SelectDir ? "Select File" : "Select Directory" );
	Fl_Button* btn = new Fl_Button(0,0,64,0,"");
	Brr2->add_extra( btn );
	Fl_Group* br3 = btn->parent();
	btn->hide();
	//add( br3 );
	Brr2->show();
	flhli_MakeWindowCenterInsideParent( br3, this, FLHIWCIP_InsideOnScreen );
}
void CCfggwiMw::draw()
{
	//fl_font( FL_HELVETICA, 24 );
	//fl_font(FL_COURIER, 16);
	//fl_font(FL_HELVETICA | FL_BOLD, 14);
	//fl_font( FL_SCREEN, 16 );

	//Fl::set_font(FL_HELVETICA, "Kochi Gothic");
	//FL_NORMAL_SIZE = 24;
	//Fl_Fontsize
	Fl_Window::draw();
}
