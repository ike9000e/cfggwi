
#include "entrypoint_fltk.h"
#include "hef/hef_file.h"
#include "hef/hef_assert.h"
#include "xehi_linux_helper.h"


void fixLXColorsIf( int argc, const char*const* argv )
{
	std::string str;
	str = hf_getCommandLineParameter( "--LXColorsFix", argc, argv, EGCLPF_NOAUTODASH|EGCLPF_NOVALUE );
	if( atoi(str.c_str()) ){
		std::vector<std::pair<std::string,std::string> >::const_iterator a;
		std::vector<std::pair<std::string,std::string> > clrs; int i;
		xehi_GetLXDELubuntuThemeColors( clrs, 0 );
		//#67D0BD
		//for( a = clrs.begin(), i=0; a != clrs.end(); ++a, i++ ){
		//	printf("%d, %s: [%s]\n", i, a->first.c_str(), a->second.c_str() );
		//}
		//FL_FOREGROUND_COLOR//FL_BACKGROUND2_COLOR//FL_BACKGROUND_COLOR
		//FL_INACTIVE_COLOR//FL_SELECTION_COLOR
		int r,g,b;
		sscanf( clrs[XEHILXCT_WndBgClr].second.c_str(), "%d,%d,%d", &r,&g,&b );
		Fl::set_color( FL_BACKGROUND_COLOR, r,g,b );
		sscanf( clrs[XEHILXCT_TextBgClr].second.c_str(), "%d,%d,%d", &r,&g,&b );
		Fl::set_color( FL_BACKGROUND2_COLOR, r,g,b );
		sscanf( clrs[XEHILXCT_SelectBgClr].second.c_str(), "%d,%d,%d", &r,&g,&b );
		Fl::set_color( FL_SELECTION_COLOR, r,g,b );
		sscanf( clrs[XEHILXCT_SelectFgClr].second.c_str(), "%d,%d,%d", &r,&g,&b );
		Fl::set_color( FL_FOREGROUND_COLOR, r,g,b );
	}
}

int main( int argc, const char*const* argv )
{
	std::vector<std::string> argv3;
	std::vector<std::string>::const_iterator a;
	{
		int i;
		for(i=0; i<argc; i++ )
			argv3.push_back( argv[i] );
	}
	{
		// xxxx-s added for later convinient exec hex editing, if any.
		const char* szCmdLineReplacementEnv = "CFGGUIAPP_CMDLINE;xxxxxxxxxxxxxxx[ecspEQrSb1HW]";
		std::string strCmdLineReplacementEnv = HfCStrPiece<char>( szCmdLineReplacementEnv,
				HfCStrPiece<char>(szCmdLineReplacementEnv).strpos(";")).toStd();
		char* env = getenv( strCmdLineReplacementEnv.c_str() );
		std::string strEnvVal = ( env ? env : "" );
		if( !strEnvVal.empty() ){
			//printf()
			fprintf(stderr,
				"Using alternate commandline from %s enviroment variable.\n"
				"Merging with %u arguments from standard commandline.\n",
				strCmdLineReplacementEnv.c_str(), (unsigned int)argv3.size() );
			std::vector<HfCStrPiece<char> >::const_iterator a;
			std::vector<HfCStrPiece<char> > lscmd =
				HfCStrPiece<char>(strEnvVal.c_str()).toCommandLineArgv();
			for( a = lscmd.begin(); a != lscmd.end(); ++a ){
				argv3.push_back( a->c_str() );
			}
		}
	}
	std::vector<const char*> argv2, argv5;
	{
		// for FLTK enginem, make new list of argv_ starting since own
		// position marked with "--fltk--" on commandline.
		if( !argv3.empty() )
			argv2.push_back( argv3[0].c_str() );
		bool bHaveFlMark = 0;
		for( a = argv3.begin(); a != argv3.end(); ++a ){
			if( !hf_strcmp( "--fltk--", a->c_str() ) ){
				bHaveFlMark = 1;
				continue;
			}
			if(bHaveFlMark)
				argv2.push_back( a->c_str() );
		}
	}
	const std::string capt = HfArgs("CFG.G.W.I. 2.5 (%1)").arg(__DATE__).c_str();
	for( a = argv3.begin(); a != argv3.end(); ++a ){
		argv5.push_back( a->c_str() );
	}
	std::string str, pathfn, title2; bool bSeDir = 0;
	str = hf_getCommandLineParameter( "--mSelectFile", argc, argv, EGCLPF_NOAUTODASH|EGCLPF_NOVALUE );
	if( atoi(str.c_str()) ){
		fixLXColorsIf( argc, argv );
		pathfn = hf_getCommandLineParameter("--szSFFName", argc, argv, EGCLPF_NOAUTODASH, "." );
		title2 = hf_getCommandLineParameter("--szSFTitle", argc, argv, EGCLPF_NOAUTODASH, "Select Item" );
		bSeDir = atoi( hf_getCommandLineParameter("--bSFDir", argc, argv, EGCLPF_NOAUTODASH|EGCLPF_NOVALUE ).c_str() );
		const char* sz2; int rs2 = 1, rs3;
		if( bSeDir ){
			sz2 = fl_dir_chooser( title2.c_str(),pathfn.c_str(),0 );
		}else{
			sz2 = fl_file_chooser( title2.c_str(),"*",pathfn.c_str(),0 );
		}
		if( sz2 ){
			//printf
			fprintf(stderr,"%s\n", sz2 );
			rs2 = 0;
		}
		if( (rs3 = Fl::run()) )
			return rs3;
		return rs2;
	}
	{
		GWI_Globals.fUiScale = atof( hf_getCommandLineParameter(
				"--fUiScale", argc, argv, EGCLPF_NOAUTODASH, "1.0f").c_str() );
		GWI_Globals.bTryUseFont2 = atoi( hf_getCommandLineParameter(
				"--bFontS2", argc, argv, EGCLPF_NOAUTODASH, "").c_str() );
		std::string sr2;
		sr2 = ( hf_getCommandLineParameter(
				"--szFS2Needle", argc, argv, EGCLPF_NOAUTODASH, "").c_str() );
		if(!sr2.empty())
			GWI_Globals.srFont2GroupName = sr2;

		//printf("bTryUseFont2: %d\n", GWI_Globals.bTryUseFont2 );
		//printf("fUiScale    : %f\n", GWI_Globals.fUiScale );
		if( GWI_Globals.bTryUseFont2 ){
			// "*clean*", "-*", "*", "courier".
			Fl_Font nFonts = Fl::set_fonts( GWI_Globals.srFont2GroupName.c_str() );
			printf("number of system fonts found: %d\n", nFonts );
			bool bGotResizableFont = 0;
			for( int ii2=0; ii2 < nFonts; ii2++ ){
				const char* fontname2 = Fl::get_font( ii2 );
				int* ptr3 = 0;
				int nSizes = Fl::get_font_sizes( ii2, ptr3 );
				std::string srSizes;
				for( int i=0; i<nSizes; i++ ){
					srSizes += std::to_string( ptr3[i] ) + ",";
				}
				//printf("%d: fontname2: [%s], s:[%s]\n", ii2, fontname2, srSizes.c_str() );
				//16: fontname2: [-*-clean-medium-r-normal--*], s:[0,12,]
				const bool bOk = ( !bGotResizableFont && ii2 >= FL_FREE_FONT &&
									nSizes && ptr3 && ptr3[0] == 0 );
				if( bOk ){
					Fl::set_font( FL_HELVETICA, fontname2 );
					bGotResizableFont = 1;
					break;
				}
			}
		}
		if( GWI_Globals.fUiScale != 1.0f ){
			FL_NORMAL_SIZE *= GWI_Globals.fUiScale;
		}
	}
	//
	CCfggwiMw* w = new CCfggwiMw( argv5.size(), &argv5[0], capt.c_str(), hf_dirname( argv3[0].c_str() ).c_str() );
	if( !w->success() ){
		fprintf(stderr,"ERROR:\n%s\n", w->message() );
		return 3;
	}
	w->end();
	w->show( (int)argv2.size(), (char**)&argv2[0] );
	//
	fixLXColorsIf( argc, argv );
	int nRunRs = Fl::run();
	if( nRunRs ){
		fprintf(stderr,"ERROR: Fl::run() returned error code %d.\n", nRunRs );
		nRunRs = ( nRunRs==1 ? 91 : ( nRunRs==2 ? 92 : nRunRs ) );
		return nRunRs;
	}
	if( w->hasCanceled() ){
		if( w->reverseErrorlevel() )
			return 0;
		return 2;
	}
	if( w->reverseErrorlevel() )
		return 1;
	return 0;
}
