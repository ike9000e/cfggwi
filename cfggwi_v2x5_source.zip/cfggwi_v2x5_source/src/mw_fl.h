#pragma once
#include <string>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Input_Choice.H>
#include <FL/Fl_Native_File_Chooser.H>
#include "flhli/flhli_main.h"
#include "jsont6/jsont6_main.h"
#include "hef/hef_str.h"
#include "hef/hef_str_args.h"
#include "xehi_linux_helper_lv2.h"
using namespace jsni;
using namespace hef;
//-fpermissive

class CCfggwiMw : public Fl_Window {
	struct SCfItem;
public:
	CCfggwiMw( int argc2, const char*const* argv2, const char* lbl, const char* szArgZeroDir );
	virtual ~CCfggwiMw();
    virtual int handle( int e );

    bool success()const {return Success2;}
    const char* message()const {return Msg.c_str();}
    bool hasCanceled()const {return Canceled2;}
    bool reverseErrorlevel()const {return bErlvZeroOnCancel;}
private:
	typedef std::vector<std::pair<std::string,std::string> > LsKeyVal_t;
	bool        parseEnums( const jnValue<char>& item2, size_t itmIndex, LsKeyVal_t& outp );
	bool        createGuiWidgets( size_t uBoxSIzeOut[2], const LsKeyVal_t& lsDfItems2 );
	bool        assignConfigDefaults( const char* szCfgFn, LsKeyVal_t& lsDfItemsOu );
	static void onButtonOkAction( Fl_Widget* wgt, void* data );
	static void onButtonCaAction( Fl_Widget* wgt, void* data );
	void        onButtonOkAction2();
	void        onButtonCaAction2( Fl_Widget* wgt );
	Fl_Widget*                     findConfigWidget( size_t ident2 )const;
	std::vector<SCfItem>::iterator findConfigWidget2( Fl_Widget* wgt );
	void        getCfItemsAsKeyValPairs( LsKeyVal_t& outp )const;
	void        consecutiveF2KeyFunctionality( Fl_Input* edt );
	static void calbOnBrwForFile( Fl_File_Chooser* brr, void* user2 );
	void        calbOnBrwForFile2( Fl_File_Chooser* brr );
	void        browseForFileF4KeyFunctionality( Fl_Input* edt );
	static bool isNonalphanumAnsiChar( int inp );
	struct SStrSelPart{
		int lenUc, nStart;
		std::string str;
		bool bAlnum, bCursor, bCursorAtFirst;
		SStrSelPart() : lenUc(0), nStart(-1), bCursor(0), bCursorAtFirst(0) {}
	};
	static void strToSelectableParts( const char* sz2, std::vector<SStrSelPart>& outp, int nCursor = -1, int* ouCurPartIdx = 0 );
	static void cbContextMenuTimeout( void* user2 );
	void        cbContextMenuTimeout2( void* user2 );
	static void cbF4KeyTimeout( void* user2 );
	void        cbF4KeyTimeout2();
	virtual void draw();
private:
	enum { ECFIT_Unknown = 1, ECFIT_Str, ECFIT_Bool, ECFIT_Enum, };
	enum { EMI_Cut=0, EMI_Copy, EMI_Paste, EMI_Del, EMI_SelAll, EMI_SelFile, EMI_SelDir, EMI_PathToRel, };
	// Describes single config item.
	// if enum element is made out of 2 elelemnts,
	// 1st is ini-value, 2nd is display-text.
	struct SCfItem{
		std::string strDesc, strType, strDflt, strVarname;
		bool        bDisabled;
		LsKeyVal_t  lsEnums;
		int         eType;
		size_t      ident, uSubEditIdent;
		SCfItem() : eType(ECFIT_Unknown), bDisabled(0), ident(0), uSubEditIdent(0) {}
		struct SBySubIdent{
			size_t uSubEditIdent2;
			SBySubIdent( size_t uSubEditIdent3 ) : uSubEditIdent2(uSubEditIdent3) {}
			bool operator()( const SCfItem& other )const{
				return uSubEditIdent2 == other.uSubEditIdent;
			}
		};
	};
    bool Success2, Canceled2, bErlvZeroOnCancel, bFileBrOpened;
    std::string Msg, StrOutpFn, TitleStr;
    std::vector<SCfItem> Items2;
    size_t uLastIdent;
    Fl_Button* BtnCancel;
    std::string IconFn;
    std::string strArgZeroDir;
    Fl_Input* EdtOnF4Key, *EdtOnContextMnu; bool bContextMnuAsKey, bF4SelectDir;
    Fl_File_Chooser* Brr2;
    bool bStdout, bConfMode;
};

class CMyFl_Input_Choice : public Fl_Input_Choice {
public:
	CMyFl_Input_Choice( int xx, int yy, int ww, int hh , const char* lbl="" );
	virtual int handle( int event );
};

struct GWI_Globals_T{
	float       fUiScale = 1.0f;
	bool        bTryUseFont2 = 0;
	std::string srFont2GroupName = "*";    // "*clean*", "-*", "*", "courier".
};


