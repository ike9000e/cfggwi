
#include "flhli_main.h"
#include <assert.h>
#include <algorithm>
#include "hef/hef_file.h"

/**
	Additinal functionality on Fl_Widget::handle() virtual method.
	Intended to be implemented inside main-window handle().
	nEvent - ineger event parameter from inside ::hsndle() call.
	flags2 - fe. FLHIEFHF_AltPlusDownForCbx.

	Returns 1 if event was processed and caller from original ::handle() should
	return integer 1 to indicate to FLTK that event was processed.
*/
bool flhli_HelperFunctionalityOnHandle( int nEvent, size_t flags2, Fl_Widget* wgt2 )
{
	if( nEvent == FL_KEYDOWN ){
		if( flags2 & FLHIEFHF_AltPlusDownForCbx ){
			if( Fl::event_key() == FL_Down ){
				if( Fl::event_state() & FL_ALT ){
					Fl_Input* edt2 = dynamic_cast<Fl_Input*>( Fl::focus() );
					if( edt2 ){
						Fl_Input_Choice* cbx3 = dynamic_cast<Fl_Input_Choice*>( edt2->parent() );
						if( cbx3 ){
							// Alt + DownArrow functionality for comboboxes,
							// ie. Alt+Down for Fl_Input_Choice widgets.
							Fl_Menu_Button* mbtn = cbx3->menubutton();
							mbtn->popup();
							return 1;
						}
					}
				}
			}
		}
		if( flags2 & FLHIEFHF_NextPrevForCbx ){
			Fl_Input* edt2 = dynamic_cast<Fl_Input*>( Fl::focus() );
			if( edt2 ){
				Fl_Input_Choice* cbx3 = dynamic_cast<Fl_Input_Choice*>( edt2->parent() );
				if( cbx3 ){
					int key2 = Fl::event_key(), nextprev = 0, nAllModk = FL_CTRL|FL_ALT|FL_SHIFT|FL_META;
					const char* szPrevs = "1[,-", *szNexts = "2].=";
					if( strchr(szPrevs,(char)key2) && (Fl::event_state() & nAllModk)){
						nextprev = -1;
					}else if( strchr(szNexts,(char)key2) && (Fl::event_state() & nAllModk)){
						nextprev = 1;
					}
					if( nextprev ){
						int idx = cbx3->menubutton()->value();
						if( idx != -1 ){
							if( nextprev == 1 ){
								int nSiz = cbx3->menubutton()->size();
								idx = std::min( idx+1, nSiz-1 );
							}else{
								idx = std::max( idx-1, 0 );
							}
							const char* szVal2 = cbx3->menubutton()->text(idx);
							if( szVal2 && *szVal2 )
								cbx3->value( (int)idx  );
						}
					}
				}
			}
		}
		if( FLHIEFHF_CtrlQClosesMw & flags2 ){
			if( Fl::event_key() == 'q' && Fl::event_state() & FL_CTRL ){
				//printf("Ctrl+Q, Closing main window...\n");
				Fl_Window* mwi = dynamic_cast<Fl_Window*>(wgt2);
				if(mwi){
					wgt2->hide();
					return 1;
				}
			}
		}
		if( FLHIEFHF_EscDontCloseMw & flags2 ){
			if( Fl::event_key() == FL_Escape ){
				//if( !( Fl::event_state() & (FL_CTRL|FL_ALT|FL_SHIFT|FL_META) ) ){
					return 1;
				//}
			}
		}
	}
	return 0;
}

/// Makes combobox readonly and disables keyboard focus from its down-arrow button
/// when navigating with TAB key.
void flhli_MakeComboboxLessFocusRO( Fl_Input_Choice* cbx2 )
{
	//Fl_Input_Choice* cbx2 = new Fl_Input_Choice( 10, 95, 100, 35 );
	Fl_Menu_Button* mbtn = cbx2->menubutton();
	mbtn->clear_visible_focus();	//Disables keyboard focus navigation.
	cbx2->input()->readonly( 1 );	//makes input readonly.
}

/// Cernters window on screen.
/// \param flags3 - flags, fe. FLHIWCSF_AllowXYOutside.
void flhli_MakeWindowCenterOnScreen( Fl_Window* wnd, size_t flags3 )
{
	int x = Fl::w() / 2 - wnd->w() / 2;
	int y = Fl::h() / 2 - wnd->h() / 2;
	if( !(flags3 & FLHIWCSF_AllowXYOutside) ){
		x = std::max(x,0);
		y = std::max(y,0);
	}
	wnd->position( x, y );
}
int flhli_GetItemCountForInputChoice( Fl_Input_Choice* inp )
{
	int cnt = 0;
	const Fl_Menu_Item* mii = inp->menu();
	while( mii->text ){
		mii++;
		cnt++;
	}
	return cnt;
}

// iItem - 1-based item index.
void flhli_SetMultiBrowserCurrentItem( Fl_Browser* brsr, int iItem )
{
	// set cursor pos but not activate selection.
	brsr->select( iItem, 0 );
	;
}

const char* CFlhli_FontSelector::szTestText = "abc DEF Xyz";
Fl_Font CFlhli_FontSelector::nNumFontsLoadedGlob = 0;

CFlhli_FontSelector::
CFlhli_FontSelector( size_t flags2_, const char* szDfltFontName, size_t uDfltSize, const char* szIoFname )
	: Fl_Window( 144, 133, 600, 440, "Font" ), bOkPressed(0)
	, DfltFontName(szDfltFontName), DfltFontSize(uDfltSize), Flags2(flags2_)
	, brFontNm(0), brFnSiz(0), boxFntTest(0), edtFnSiz(0), btnCa(0)
	, strIoFname(szIoFname?szIoFname:"")
{
	if( !strIoFname.empty() ){
		// Lines: [0] font name, [1] font size.
		std::vector<std::string> lns(2,"");
		hf_GetFileDSVContents( strIoFname.c_str(), "\n", lns, "\r\n\t\x20" );
		printf("[%s][%s]\n", lns[0].c_str(), lns[1].c_str() );
		DfltFontName = lns[0].c_str();
		DfltFontSize = atoi( lns[1].c_str() );
	}
	size_range( 40,30, 0, 0 );
	//
	brFontNm = new CBr( 5,5, 300, 100 );//Fl_Hold_Browser,Fl_Select_Browser,Fl_Multi_Browser
	brFontNm->format_char(0);
	brFontNm->sgSelected.connect( this, &CFlhli_FontSelector::soFontNameSelected );

	edtFnSiz = new CInp( 310, 5, 100, 25, "" );
	edtFnSiz->sgTextChanged.connect( this, &CFlhli_FontSelector::soSizeTextChanged );
	brFnSiz = new CBr( 310, 35, 100, 100 );
	brFnSiz->format_char(0);
	brFnSiz->sgSelected.connect( this, &CFlhli_FontSelector::soSizeSelected );
	boxFntTest = new Fl_Box( 4, 120, 300, 42, szTestText );	//Fl_Box
	boxFntTest->box( FL_DOWN_BOX );

	Fl_Button* btnOk = new Fl_Button( 4, 170, 64, 24, "OK" );
	           btnCa = new Fl_Button( 72, 170, 64, 24, "Cancel" );
	btnOk->callback( onButtonOkAction, (void*)this );
	btnCa->callback( onButtonCaAction, (void*)this );

	if( Flags2 & EFLHLI_LoadSystemFonts ){
		loadSystemFonts();
	}
	{
		//nNumFontsLoadedGlob
		const char* sz;
		for( Fl_Font k=0; ; k++ ){	//k<32
			sz = Fl::get_font( k );
			if( !sz || !*sz )
				break;
			if( nNumFontsLoadedGlob ){
				if( k >= nNumFontsLoadedGlob )
					break;
			}else{
				if( k >= 8 )
					break;
			}

			int attrs = 0;
			sz = Fl::get_font_name( k, &attrs );
			if( !sz || !*sz )
				break;
			//if( attrs )
			//	continue;
			std::string str = sz;
			brFontNm->add( str.c_str() );
			SFont2 sf;
			sf.name = str.c_str();
			int* sizes2 = 0;
			int num = Fl::get_font_sizes( k, sizes2 );
			//printf("k%d: %s, num sizes: %d\n", k, str.c_str(), num );
			for( int s=0; s<num; s++ ){
				//printf("\t""s%d: %d\n", s, sizes2[s] );
				sf.sizes.push_back( sizes2[s] );
			}
			Fonts2.push_back( sf );
		}
	}
	end();

	if( !DfltFontName.empty() ){
		for( int i=1; i <= brFontNm->size(); i++ ){
			if( DfltFontName == brFontNm->text(i) ){
				brFontNm->select(i,1);
				break;
			}
		}
	}
	if( DfltFontSize ){
		char bfr[128];
		sprintf( bfr, "%d", DfltFontSize );
		edtFnSiz->value( bfr );
		soSizeTextChanged( CInp::STextChanged( bfr ) );
	}
	flhli_MakeWindowCenterOnScreen( this, 0x0 );
}
CFlhli_FontSelector::~CFlhli_FontSelector()
{
	//printf("~CFlhli_FontSelector().\n");
}
int CFlhli_FontSelector::handle( int e )
{
	if( e == FL_SHOW ){
		printf("sh.\n");
		if( Flags2 & EFLHLI_AutoAcceptIoFile && !strIoFname.empty() && !DfltFontName.empty() ){
			onButtonOkAction2();
			hide();
		}
	}else if( e == FL_HIDE ){
		SFlhli_Close sc;
		sc.wnd = this;
		sgClose.emitf( sc );
	}else if( e == FL_KEYDOWN ){
		if( Fl::event_key() == FL_Enter ){
			if( !( Fl::event_state() & (FL_CTRL|FL_ALT|FL_SHIFT|FL_META) ) ){
				Fl_Widget* wgt = Fl::focus();
				if( wgt == btnCa ){
					return 1;
				}else{
					onButtonOkAction2();
					return 1;
				}
			}
		}
	}
	return Fl_Window::handle( e );
}
void CFlhli_FontSelector::CBr::item_select( void* item, int val )
{
	//printf("item_select(%u,%d), 1sel:%d.\n", (uint32_t)(size_t)item, val, selected(1) );
	Fl_Hold_Browser::item_select( item, val );
	//printf("item_select, 1sel:%d.\n",  selected(1) );
	for( int i=1; i <= size(); i++ ){
		if( selected(i) ){
			SSelected ss;
			ss.nLine = i;
			ss.strText = text( i );
			sgSelected.emitf(ss);
			break;
		}
	}
}
void CFlhli_FontSelector::soFontNameSelected( const CBr::SSelected& inp )
{
	//printf("select(%d,%s).\n", inp.nLine, inp.strText.c_str() );
	if( inp.nLine < 1 )
		return;
	int nFont = inp.nLine - 1;
	assert( nFont < (int)Fonts2.size() );
	boxFntTest->labelfont( nFont );
	boxFntTest->label( szTestText );

	brFnSiz->clear();
	const SFont2& fn = Fonts2[ nFont ];
	std::vector<int>::const_iterator a;
	for( a = fn.sizes.begin(); a != fn.sizes.end(); ++a ){
		if( *a > 0 ){
			char bfr[128];
			sprintf( bfr, "%d", *a );
			brFnSiz->add(bfr);
		}
	}
}
int CFlhli_FontSelector::CInp::handle( int e )
{
	int retv = Fl_Input::handle( e );
	if( e == FL_KEYDOWN ){
		STextChanged tc;
		tc.strNewText = value();
		sgTextChanged.emitf( tc );
	}
	return retv;
}
void CFlhli_FontSelector::soSizeTextChanged( const CInp::STextChanged& inp )
{
	int fontsiz = std::min( std::max( atoi(inp.strNewText.c_str()), 1 ), 200 );
	boxFntTest->labelsize( (Fl_Fontsize) fontsiz );
	boxFntTest->label( szTestText );
}
void CFlhli_FontSelector::soSizeSelected( const CBr::SSelected& inp )
{
	edtFnSiz->value( inp.strText.c_str() );
	CInp::STextChanged tc;
	tc.strNewText = inp.strText;
	soSizeTextChanged( tc );
}
void CFlhli_FontSelector::onButtonOkAction( Fl_Widget* wgt, void* data )
{
	CFlhli_FontSelector* thisp = (CFlhli_FontSelector*) data;
	thisp->onButtonOkAction2();
}
void CFlhli_FontSelector::onButtonCaAction( Fl_Widget* wgt, void* data )
{
	CFlhli_FontSelector* thisp = (CFlhli_FontSelector*) data;
	thisp->onButtonCaAction2();
}
void CFlhli_FontSelector::onButtonCaAction2()
{
	hide();
}
void CFlhli_FontSelector::onButtonOkAction2()
{
	int nFontSiz = atoi( edtFnSiz->value() );
	if(!nFontSiz)
		nFontSiz = FL_NORMAL_SIZE;
	int nFontIndex = brFontNm->value();
	// selection number returned is 1-based. if nothing selected, value is 0
	// and code defaults to 1st element (index 0) (array in question: 'Fonts2').
	if( nFontIndex > 0 )
		nFontIndex--;
	assert( nFontIndex < (int)Fonts2.size() );
	const SFont2& fn2 = Fonts2[ nFontIndex ];

	printf("selected font name : '%s'\n", fn2.name.c_str() );
	printf("selected font index: '%d'\n", nFontIndex );
	printf("selected font size : '%d'\n", nFontSiz );

	FontOu.name   = fn2.name;
	FontOu.nIndex = nFontIndex;
	FontOu.nSize  = nFontSiz;

	bOkPressed = 1;
	if( Flags2 & EFLHLI_UpdateChangesOnOk ){
		SFont ft2 = getAcceptedFontDetails();
		Fl::set_font( FL_HELVETICA, ft2.nIndex );
		FL_NORMAL_SIZE = ft2.nSize;
		if( !strIoFname.empty() ){
			FILE* fpx = fopen( strIoFname.c_str(), "w+b" );
			if( fpx ){
				char bfr[128];
				sprintf(bfr,"%s\n%d\n", ft2.name.c_str(), ft2.nSize );
				fwrite( bfr, hf_strlen(bfr), 1, fpx );
				fclose( fpx );
			}else{
				fprintf(stderr,"ERROR: File open RW failed. (%s(%d))\n",
						hf_basename(__FILE__), __LINE__ );
			}
		}
	}
	hide();
}
/// Returns details about selected font.
/// Yields valid results only when called after window has been
/// closed with OK button.
CFlhli_FontSelector::SFont CFlhli_FontSelector::getAcceptedFontDetails()const
{
	return FontOu;
}
Fl_Font CFlhli_FontSelector::findFontByName( const char* szNm )
{
	for( Fl_Font k=0; ; k++ ){
		int attrs = 0;
		const char* sz = Fl::get_font_name( k, &attrs );
		if( !sz || !*sz )
			break;
		if( !strcmp( szNm, sz ) ){
			return k;
		}
	}
	return -1;
}
int CFlhli_FontSelector::loadSystemFonts( const char* szXstarname )
{
	//fl_open_display();
	// references:
	// http://www.klauser.com/lxug/ch13.pdf
    // xset q --> Font Path
    // xset +fp /path/tofonts
    // XSetFontPath()
    // $> mkfontdir
	//XSetFontPath( fl_display, dirs3, 1 );

	nNumFontsLoadedGlob = Fl::set_fonts( szXstarname );
	return nNumFontsLoadedGlob;
}
/// Adds menu item and immediatelly returns newly created slot for it.
/// User code may immediatelly perform any connect() call on returned pointer to have
/// it's callback called every time menu item is activated.
/// flags2 - flags parameter for Fl_Menu_::add(), values passed unchanged.
sigslot::signal1<const CFlhli_Menubar::SAct&>*
CFlhli_Menubar::add2( const char* szName, const char* sc, int flags2 )
{
	SAct2 acn;
	acn.ident = ++uLastIdent;
	acn.ac2.strName = szName;
	Actions2.push_back( acn );
	add( szName, sc, fnMenuCallback2, (void*)acn.ident, flags2 );
	return &Actions2.back().ac3;
}
void CFlhli_Menubar::fnMenuCallback2( Fl_Widget* wgt, void* user )
{
	CFlhli_Menubar* mb = dynamic_cast<CFlhli_Menubar*>( wgt );
	assert(mb);
	mb->fnMenuCallback3( (size_t)user );
}
void CFlhli_Menubar::fnMenuCallback3( size_t ident2 )
{
	std::vector<SAct2>::iterator a;
	a = std::find_if( Actions2.begin(), Actions2.end(), SAct2::SByIdent(ident2) );
	assert( a != Actions2.end() );
	a->ac3.emitf( a->ac2 );
}
/// Returns viewport, first and last displayed line as 1-based numbers.
std::pair<int,int>
flhli_GetBrowserFirstLastDisplayedLine( const Fl_Browser* brsr, int* firstOu, int* lastOu )
{
	std::pair<int,int> out( brsr->topline(), 0 );
	;
	int p = out.first, num = brsr->size();
	for(; p+1 <= num && brsr->displayed(p+1); p++ ){
	}
	out.second = p;
	if(firstOu)
		*firstOu = out.first;
	if(lastOu)
		*lastOu = out.second;
	return out;
}
/// Calls function for each child widget, recursivelly.
/// calb2 - callback. return value '-1' from it causes iteration to stop.
/// szFlags2 - flags as c-string characters. 'R': non-recursive iteration.
int flhli_EachChildWidgetRcr( Fl_Widget* wgt, std::function<int(Fl_Widget*,void*)> calb2,
					void* userr, const char* szFlags2 )
{
	Fl_Group* gr = wgt->as_group();
	bool bNotRecursively = !!strchr( szFlags2, 'R' );
	if(gr){
		Fl_Widget* wgt2;
		for( int i=0; i < gr->children(); i++ ){
			wgt2 = gr->child(i);
			if( -1 == calb2( wgt2, userr ) )
				return -1;
			if( !bNotRecursively )
				if( -1 == flhli_EachChildWidgetRcr( wgt2, calb2, userr, szFlags2 ) )
					return -1;
		}
	}
	return 1;
}



//int COptionsMw::CCbx::handle( int e )
int flhli_FilterInputChoiceEventsAddCommonActions( int e, Fl_Input_Choice* cbx )
{
	if( e == FL_KEYDOWN ){
		int k = Fl::event_key();
		if( k=='-' || k=='[' || k==',' || k==FL_Left ){
			cbx->value( std::max<int>( cbx->menubutton()->value()-1, 0 ) );
			return 1;
		}
		if( k=='=' || k==']' ||k=='.' || k==FL_Right ){
			int num = flhli_GetItemCountForInputChoice( cbx );
			cbx->value( std::min<int>( cbx->menubutton()->value()+1, (num? num-1 : 0) ) );
			return 1;
		}
	}
	//return Fl_Input_Choice::handle( e );
	return 0;
}
/// Returns absolute position given optional widget's parent, in hierarchy, window.
/// If parent window ('wnd') is 0, retrieves coordinates on-screen.
void flhli_GetWidgetAbsolutePos( Fl_Widget* wgt, Fl_Window* wnd, int& x, int& y )
{
	// if(!wnd)
	// wnd = Fl::first_window();
	x = wgt->x();
	y = wgt->y();
	Fl_Group* par;
	for( par = wgt->parent(); par; par = par->parent() ){
		if( par == wnd )
			break;
		x += par->x();
		y += par->y();
	}
}
/// Centers window inside parent.
/// flags2 - flags fe. FLHIWCIP_InsideOnScreen.
bool flhli_MakeWindowCenterInsideParent( Fl_Group* wnd, Fl_Window* parent2, int flags2 )
{
	Fl_Group* par = ( parent2 ? parent2 : wnd->parent() );
	if( !par )
		return 0;
	int x = par->w() / 2;
	int y = par->h() / 2;
	if( flags2 & FLHIWCIP_InsideOnScreen ){
		x += par->x();
		y += par->y();
	}
	x -= wnd->w() / 2;
	y -= wnd->h() / 2;
	wnd->position( x, y );
	return 1;
}
bool flhli_UpdateCbxTextInItsHistory( Fl_Input_Choice* cbx, int nMaxHistory )
{
	const char* szVal2;
	std::string curr2 = ( cbx->value() ? cbx->value() : "" );
	if( curr2.empty() )
		return 0;
	Fl_Menu_Button* mbt = cbx->menubutton();  //get the drop down box.
	std::vector<std::string> aOrigItems;
	std::vector<std::string>::const_iterator a;
	bool bPresent = 0;
	// for each, check if current text is not already in the drop down box.
	int num = mbt->size();
	for( int i=0; i<num; i++ ){
		if( ( szVal2 = mbt->text(i) ) && *szVal2 ){
			if( curr2 == szVal2 )
				bPresent = 1;
			aOrigItems.push_back( szVal2 );
		}
	}
	if( !bPresent )
		mbt->insert( 0, curr2.c_str(), 0, 0, 0, 0 );
	num = mbt->size();
	if( nMaxHistory != -1 && aOrigItems.size() >= nMaxHistory ){
		// NOTE: method seems to do not work: ''mbt->remove(mbt->size()-1)''
		if( !aOrigItems.empty() )
			aOrigItems.resize( aOrigItems.size() - 1, "?" );
		mbt->clear();
		mbt->add( curr2.c_str() );
		for( a = aOrigItems.begin(); a != aOrigItems.end(); ++a ){
			mbt->add( a->c_str() );
		}
	}
	return 1;
}
