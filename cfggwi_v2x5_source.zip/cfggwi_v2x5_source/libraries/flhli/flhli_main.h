
#ifndef _FLHLI_MAIN_H_
#define _FLHLI_MAIN_H_
#include <vector>
#include <string>
#include <algorithm>
#include <functional>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Input_Choice.H>
#include <FL/Fl_Multi_Browser.H>
#include <FL/Fl_Select_Browser.H>
#include <FL/Fl_Hold_Browser.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Menu_Bar.H>
#include "hef/hef_sigslot_mod.h"
namespace hef {}
using namespace hef;

/// Flags for flhli_HelperFunctionalityOnHandle().
enum {
	/// Alt + DownArrow functionality for comboboxes.
	/// Ie. Alt+Down for Fl_Input_Choice widgets,
	/// when focus is inside combobox's (Fl_Input_Choice) editbox (Fl_Input) widget.
	FLHIEFHF_AltPlusDownForCbx = 0x1,
	/// Ctrl+Q closes main window.
	/// the 'wgt2' parameter must always be application main window.
	FLHIEFHF_CtrlQClosesMw = 0x2,
	/// By default, FLTK closes any Fl_Window when Esc key is pressed,
	/// this flag suppresses that.
	FLHIEFHF_EscDontCloseMw = 0x4,

	FLHIEFHF_NextPrevForCbx = 0x8,
};
/// Flags for flhli_MakeWindowCenterOnScreen().
enum { FLHIWCSF_AllowXYOutside = 0x1, };
/// Flags for flhli_MakeWindowCenterInsideParent().
enum { FLHIWCIP_InsideOnScreen = 0x1, };

bool flhli_HelperFunctionalityOnHandle( int nEvent, size_t flags2, Fl_Widget* wgt2 );
void flhli_MakeComboboxLessFocusRO( Fl_Input_Choice* cbx2 );
void flhli_MakeWindowCenterOnScreen( Fl_Window* wnd, size_t flags3 );
bool flhli_MakeWindowCenterInsideParent( Fl_Group* wnd, Fl_Window* parent2 = 0, int flags2=0 );
int  flhli_GetItemCountForInputChoice( Fl_Input_Choice* inp );
void flhli_SetMultiBrowserCurrentItem( Fl_Browser* brsr, int iItem );
std::pair<int,int> flhli_GetBrowserFirstLastDisplayedLine( const Fl_Browser* brsr, int* firstOu=0, int* lastOu=0 );
int  flhli_EachChildWidgetRcr( Fl_Widget* wgt, std::function<int(Fl_Widget*,void*)> calb2, void* user, const char* szFlags2 = "" );
int  flhli_FilterInputChoiceEventsAddCommonActions( int e, Fl_Input_Choice* cbx );
void flhli_GetWidgetAbsolutePos( Fl_Widget* wgt, Fl_Window* wnd, int& x, int& y );
bool flhli_UpdateCbxTextInItsHistory( Fl_Input_Choice* cbx, int nMaxHistory );

struct SFlhli_Close{
	Fl_Window* wnd;
	SFlhli_Close( Fl_Window* wnd_ = 0 ) : wnd(wnd_) {}
};
enum {
	EFLHLI_LoadSystemFonts = 0x1,
	EFLHLI_UpdateChangesOnOk = 0x2,
	EFLHLI_AutoAcceptIoFile = 0x4,
};

/// Font Selector window that optionally loads system fonts and allows
/// font name and size selection.
/// See also CFlhli_FontSelector::getAcceptedFontDetails().
class CFlhli_FontSelector : public Fl_Window, public sigslot::has_slots<> {
public:
	struct SFont{
		Fl_Font     nIndex;
		Fl_Fontsize nSize;
		std::string name;
		SFont() : nIndex(0), nSize(0) {}
	};
	CFlhli_FontSelector( size_t flags2, const char* szDfltFontName, size_t uDfltSize, const char* szIoFname = 0 );
	~CFlhli_FontSelector();
	virtual int    handle( int e );
	bool           wasAccepted()const {return bOkPressed;}
	SFont          getAcceptedFontDetails()const;
	static Fl_Font findFontByName( const char* szNm );
	static int     loadSystemFonts( const char* szXstarname = "*" );
	//
	sigslot::signal1<const SFlhli_Close&> sgClose;
private:
	class CBr : public Fl_Hold_Browser{
	public:
		CBr( int x, int y, int w, int h ) : Fl_Hold_Browser(x,y,w,h) {}
		virtual void item_select( void* item, int val );
		struct SSelected{
			int nLine;
			std::string strText;
		};
		sigslot::signal1<const SSelected&> sgSelected;
	};
	class CInp : public Fl_Input{
	public:
		CInp( int x, int y, int w, int h, const char* lbl ) : Fl_Input(x,y,w,h,lbl) {}
		virtual int handle( int e );
		struct STextChanged{
			std::string strNewText;
			STextChanged( const char* sz = "" ) : strNewText(sz) {}
		};
		sigslot::signal1<const STextChanged&> sgTextChanged;
	};
	void soFontNameSelected( const CBr::SSelected& );
	void soSizeSelected( const CBr::SSelected& );
	void soSizeTextChanged( const CInp::STextChanged& );
	static void onButtonOkAction( Fl_Widget* wgt, void* data );
	static void onButtonCaAction( Fl_Widget* wgt, void* data );
	void onButtonOkAction2();
	void onButtonCaAction2();
private:
	bool bOkPressed;  std::string DfltFontName; int DfltFontSize, Flags2;
	CBr* brFontNm, *brFnSiz;
	Fl_Box* boxFntTest;
	static const char* szTestText;
	struct SFont2{
		std::string name;
		std::vector<int> sizes;
	};
	std::vector<SFont2> Fonts2;
	CInp* edtFnSiz;
	SFont FontOu;
	Fl_Button* btnCa;
	static Fl_Font nNumFontsLoadedGlob;
	std::string strIoFname;
};

/// Helper class that provides add2() method that immediatelly return signal structure
/// that can be connected to user slot.
class CFlhli_Menubar : public Fl_Menu_Bar {
public:
	CFlhli_Menubar( int x, int y, int w, int  h ) : Fl_Menu_Bar(x,y,w,h), uLastIdent(0) {}
	virtual ~CFlhli_Menubar() {}
	struct SAct{
		std::string strName;
	};
	sigslot::signal1<const SAct&>* add2( const char* szName, const char* sc, int flags2 );
private:
	static void fnMenuCallback2( Fl_Widget* wgt, void* user );
	void fnMenuCallback3( size_t ident2 );
private:
	struct SAct2{
		size_t                        ident;
		SAct                          ac2;
		sigslot::signal1<const SAct&> ac3;
		struct SByIdent{
			size_t ident3;
			SByIdent(size_t ident3_) : ident3(ident3_) {}
			bool operator()( const SAct2& a )const {return ( a.ident == ident3 ? 1 : 0 );}
		};
	};
	std::vector<SAct2> Actions2;
	size_t uLastIdent;

};

#endif //_FLHLI_MAIN_H_
