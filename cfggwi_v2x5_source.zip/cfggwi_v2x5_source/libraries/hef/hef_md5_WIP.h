#ifndef _HV_MD5_H_
#define _HV_MD5_H_
#include <vector>
#include <string>

/**
	\file
	MD5 digest computing class and routines.
	Code taken from Poco C++ library, poco-1.6.0.
*/

/// Implementation of the MD5 message digest algorithm.
/// Described in RFC 1321.
struct MD5Engine
{
	;                       MD5Engine();
	virtual                 ~MD5Engine();
	virtual size_t          digestLength()const;
	virtual void            reset();
	virtual const std::vector<uint8_t>& getDigest();
	virtual void            update( const void* data, size_t length );
	virtual void            update( char data );
	virtual void            update( const std::string& data );
	static std::string      digestToHex( const std::vector<uint8_t>& bytes );
	static std::vector<uint8_t> digestFromHex( const std::string& digest );

	static void testMD5Misc();
protected:
	virtual void updateImpl(const void* data, size_t length);
private:
	static void transform(uint32_t state[4], const uint8_t block[64]);
	static void encode(uint8_t* output, const uint32_t* input, size_t len);
	static void decode(uint32_t* output, const uint8_t* input, size_t len);
private:
	enum{ BLOCK_SIZE  = 64, DIGEST_SIZE = 16, };
	struct Context {
		uint32_t state[4];          // state (ABCD)
		uint32_t count[2];          // number of bits, modulo 2^64 (lsb first)
		uint8_t buffer[64]; // input buffer
	};
	Context Context2;
	std::vector<uint8_t> Digest2;

	MD5Engine( const MD5Engine& );
	MD5Engine& operator=( const MD5Engine& );
};

inline void MD5Engine::update( const void* data, size_t length )
{
	updateImpl(data, length);
}
inline void MD5Engine::update( char data )
{
	updateImpl(&data, 1);
}
inline void MD5Engine::update( const std::string& data )
{
	updateImpl(data.data(), data.size());
}

#endif //_HV_MD5_H_
