
#ifndef _HEF_FILESYSTEM_H_
#define _HEF_FILESYSTEM_H_
#include "hef_str.h"
namespace hef{
;
enum {
	/// Flags for \ref HfDirContents constructor.
	EHFDCF_IncludeDotedOnes = 0x1,
};
/// Enumerates directory contents.
/// Done in similar way as with FindFirstFile(), FindNextFile() and FindClose() WIN32 APIs.
///
/// References:
/// * https://stackoverflow.com/questions/4204666/how-to-list-files-in-a-directory-in-a-c-program
class HfDirContents {
public:
	HfDirContents( const char* szDir, size_t flags2 = 0 );
	~HfDirContents();
	struct SFile {
		std::string fname;
		bool        bDir;
		void*       pUnixDirent;  /// On unix, this is 'struct dirent*', otherwise always null.
		SFile() : bDir(0), pUnixDirent(0) {}
	};
	bool getNextFile( SFile& out );
	void cleanup();
private:
	bool isFnameAcceptable( const std::string& fname2 );
private:
	std::string  Dir2;
	size_t       Flags2;   // fe. EHFDCF_IncludeDotedOnes.
	void*        WfdHandle;   // HANDLE (WIN32)
	void*        Dh3;   // DIR* (Linux/Unix)
};

} // end namespace hef

#endif //_HEF_FILESYSTEM_H_
