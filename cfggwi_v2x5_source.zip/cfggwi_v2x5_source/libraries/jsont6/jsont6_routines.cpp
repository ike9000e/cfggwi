
#include "jsont6_routines.h"
#include "jsont6_text.h"
namespace jsni{

/// Writes file bytes either replacing entire contents or appends data at file end.
/// \param fn - File name.
/// \param bytes - Pointer to data.
/// \param size - Size of data in bytes.
/// \param flags - Flags, eg jnEPFBF_Append.
bool jn_PutFileBytes( const char* fn, const void* bytes, size_t size, size_t flags )
{
	FILE* fp2 = 0;
	if( flags & jnEPFBF_Append ){
		fp2 = fopen( fn, "ab" );
	}else{
		fp2 = fopen( fn, "wb" );
	}
	if(fp2){
		fseek( fp2, 0, SEEK_END );
	//	if( size == -1 )
	//		size = si_strlen( bytes );
		fwrite( bytes, size, 1, fp2 );
		fclose(fp2);
		return 1;
	}
	return 0;
}

} // end namespace jsni
