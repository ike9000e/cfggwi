
#ifndef _JSONT6_C_TOKEN_H_
#define _JSONT6_C_TOKEN_H_
#include <vector>
#include <stdio.h>
#include "jsont6_routines.h"
#include "jsont6_CDataPiece.h"
#include "jsont6_sprint64.h"
namespace jsni{
;
enum ETokenType {
	ETT_UNKNOWN,	//x
	ETT_LITERAL,	//x
	ETT_WHITESPACES,	//x
	ETT_STRUCTURAL_CHARACTER,	//x
	ETT_STRING,		//x
	ETT_COMMENT,	//x
	ETT_NUMBER,		//x
	ETT_WORD,		//x - used only in 'unquoted-property-names' feature mode.
};
enum ETokenLiteralType {
	ETLT_FALSE,
	ETLT_NULL,
	ETLT_TRUE,
};
enum ETokenWhitespacesType {
	ETWST_ANYWHITESPACE,
};
enum ETokenStructuralCharacter {
	ETSC_LEFT_SQUARE_BRACKET, // [ left square bracket
	ETSC_LEFT_CURLY_BRACKET, // { left curly bracket
	ETSC_RIGHT_SQUARE_BRACKET, // ] right square bracket
	ETSC_RIGHT_CURLY_BRACKET, // } right curly bracket
	ETSC_COLON, // : colon
	ETSC_COMMA, // , comma
};
enum ETokenComment {
	ETCMT_SINGLELINE,
	ETCMT_MULTILINE,
};
enum ETokenNumber {
	ETNR_ANYNUMBER,
};
enum ETokenWord {
	ETWD_ANYWORD,
};

/**
	Contains partially parsed components of a number.
	\code
		result = (integer + decimalPart * 0.1) ^ exponent.
		pow(), exp(), ldexp(), frexp() - decompose exponent.
			 double pow (      double base,      double exponent );
		long double pow ( long double base, long double exponent );
			  float pow (       float base,       float exponent );
			 double pow (      double base,         int exponent );
		long double pow ( long double base,         int exponent );
	\endcode
*/
struct STokenNumberComponents {
	JSONT6_INT64    nInteger;		///< signed integer part.
	bool            bNegated;
	JSONT6_UINT64   uFractionPart;	///< unsigned fraction part, digits after dot, no leading or trailing zeros, see 'uFracPartLeadingZeros' for leading zeros count.
	JSONT6_INT64    nExponent;		///< signed exponent.
	std::string     strIntegerDigits;		///< digits only not including optional sign.
	std::string     strFractionPartDigits;	///< digits only...
	size_t          uFracPartLeadingZeros;
	std::string     strExponentDigits;		///< digits only...
	STokenNumberComponents()
		: nInteger(0), bNegated(0), uFractionPart(0), nExponent(1), uFracPartLeadingZeros(0)
	{}
	void assign( const char* integer, bool bIntegerNegated, const char* fractionPart, const char* exponent, bool bExponentNegated );
	std::string sprint()const;
};


template<class T>
class CToken
{
public:
	typedef std::vector<CToken<T> > LsToken;

#if !defined(JSONT6_INLINE)
public:
	CToken();
	~CToken();
	CToken( ETokenLiteralType e );
	CToken( ETokenWhitespacesType e );
	CToken( ETokenStructuralCharacter e );
	CToken( E_JSONT6_STR e );
	CToken( ETokenComment e );
	CToken( ETokenNumber e );
	CToken( ETokenWord e );
	const CDataPiece<T>&     stringPiece()const;
	void                     stringPiece( const CDataPiece<T>& in );
//	std::string              asString()const;
	void                     stringString( const T* in, size_t size );
	void                     stringString( const std::vector<T>& in );
	const std::vector<T>&    stringString()const;
	E_JSONT6_STR             stringType()const;
	void                          numberComponents( const STokenNumberComponents& in );
	const STokenNumberComponents& numberComponents()const;

	bool operator==( ETokenType e )const;
	bool operator==( ETokenStructuralCharacter e )const;
	bool operator==( ETokenLiteralType e )const;
private:
	void constructorCommon();
#else //JSONT6_INLINE
#	include "jsont6_CToken.inl"
#endif //JSONT6_INLINE
private:
	CDataPiece<T>           Sp;
	ETokenType              Type;
	std::vector<T>          Dstring;
	STokenNumberComponents  NumberComponents;
	union {
		ETokenLiteralType LiteralType;
		ETokenWhitespacesType WhitespacesType;
		ETokenStructuralCharacter StructuralCharacter;
		E_JSONT6_STR TokenString;
		ETokenComment TokenComment;
		ETokenNumber TokenNumber;
		ETokenWord TokenWord;
		int iAnySubtype;
	};
};

std::string StrNoSpecialChars( const char* in );


} // end namespace jsni

#endif //_JSONT6_C_TOKEN_H_
