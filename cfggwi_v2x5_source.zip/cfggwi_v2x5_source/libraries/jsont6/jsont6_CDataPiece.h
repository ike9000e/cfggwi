
#ifndef _JSONT6_C_DATA_PIECE_H_
#define _JSONT6_C_DATA_PIECE_H_
#include <vector>
#include <stdio.h>
namespace jsni{
;

template<class T>
class CDataPiece
{
public:
	CDataPiece()
		: Bgn(0), Size(0)
	{}
	CDataPiece( const T* begin, const T* end, int )
		: Bgn(begin), Size(end - begin)
	{}
	CDataPiece( const T* begin, size_t size )
		: Bgn(begin), Size(size)
	{}
	CDataPiece( const CDataPiece<T>& other )
		: Bgn(other.Bgn), Size(other.Size)
	{}
	CDataPiece& assign( const T* bgn, const T* end, int )
	{
		Bgn = bgn;
		Size = end - bgn;
		return *this;
	}
	CDataPiece& assignCString( const T* sz ){
		Size = getCStringLength( Bgn = sz );
		return *this;
	}
	CDataPiece& leftSideMove( int amount ){
		Bgn += amount;
		return *this;
	}
	const T* pointer()const{
		return Bgn;
	}
	const T* end()const{
		return Bgn + Size;
	}
	size_t size()const{
		return Size;
	}
	bool empty()const{
		return !Bgn || !Size;
	}
	T charAt( size_t a )const{
		if( a < Size ){
			return Bgn[a];
		}
		T tmp = 0;
		return tmp;
	}
	const T& operator*()const{
		return *Bgn;
	}
	void getAsVector( std::vector<T>& out )const{
		const T* a = Bgn, *endx = end();
		for( a = Bgn; a != endx; ++a ){
			out.push_back( *a );
		}
	}
	bool equalsToVector( const std::vector<T>& other )const{
		size_t i;
		typename std::vector<T>::const_iterator a;
		if( other.size() == Size ){
			for( i=0, a = other.begin(); i<Size && a != other.end(); i++, ++a ){
				if( !( Bgn[i] == *a ) ){
					return 0;
				}
			}
			return 1;
		}else{
			return 0;
		}
	}
	/// Counts the number of substring occurrences.
	/// Returns the number of times the 'szSubstr' substring occurs in the
	/// string-piece. Case sensitive.
	size_t getSubstrCount( const T* szSubstr )const{
		size_t len = getCStringLength(szSubstr);
		size_t cnt = 0, i,k, num = Size;
		for( i=0; num; num--, i++ ){
			for( k=0; i+k < Size && k<len && Bgn[i+k] == szSubstr[k] ; k++ ){
				if( k+1 == len )
					cnt++;
			}
		}
		return cnt;
	}
	static size_t getCStringLength( const T* in ){
		const T* sz = in;
		for(; *sz; sz++ );
		return sz - in;
	}
private:
	const T* Bgn;
	size_t   Size;
};

} // end namespace jsni

#endif //_JSONT6_C_DATA_PIECE_H_
