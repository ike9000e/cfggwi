
#include "jsont6_CParser.h"
namespace jsni {
;

#if !defined(JSONT6_INLINE)
#	include "jsont6_CParser.inl"
#	ifdef _MSC_VER
		// MSVC specific template iinstatiations.
		template class CParser<char>;
		template class CParser<short>;
		template class CParser<long>;
		template class CParser<unsigned char>;
		template class CParser<unsigned short>;
		template class CParser<unsigned long>;//*/
#	endif //_MSC_VER
#endif //JSONT6_INLINE

/// \cond DOXYGEN_SKIP
void js_TestMisc()
{
	jnValue<char> testval;
	jn_ParseString<char>("{e:'4',f:'5',}",-1,testval );
	testval.getPropertyByName("varA").toSTDString().c_str();
	testval.getPropertyByName2("varB","--").c_str();
	testval.getProperty(0).isInvalid();
	testval.getName();
	testval.isObjectOrArray();
	testval.setName("testval-1").setIsObject();
	jnValue<char>().setString("");
	const std::vector<jnValue<char> >& ch1 = testval.children();
	ch1.size();
	std::vector<jnValue<char> >& ch2 = testval.children();
	ch2.size();
}
/// \endcond //DOXYGEN_SKIP

} // end namespace jsni

/**
	Function to quickly parse JSON file without need to create any parser instance
	first.
	Multibyte character only, cannot set template parameter of input arguments
	to other type than 'char'.
	Parameters 'err' and 'err2' are optional and can be set to null to ignore.

	Example:
	\verbatim
		jnValue<char> RootValue;
		jn_QuickFileParse("./config.json", RootValue );

		std::vector<jnValue<char> >::const_iterator a;
		std::vector<jnValue<char> >& properties = RootValue.children();
		for( a = properties.begin(); a != properties.end(); ++a ){
			printf("%s: %s\n", a->getName().c_str(), a->toSTDString().c_str() );
			if( a->isObjectOrArray() ){
				// ...
			}
		}
	\endverbatim
	\sa GP_ParseMainFncs
*/
bool jn_QuickFileParse( const char* szFname, jnValue<char>& RootValueOut,
					   std::string* err, jnSParseError<char>* err2,
					   const jnSParseFeatures& features )
{
	return jsni::CParser<char>::quickFileParse( szFname, RootValueOut, err, err2, features );
}
