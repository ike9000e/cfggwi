
#ifndef _JSONT6_ROUTINES_H_
#define _JSONT6_ROUTINES_H_
#ifdef _MSC_VER
#	pragma warning ( disable: 4786 )	//"...identifier truncated..."
#	if _MSC_VER >= 1400
#		pragma warning( disable: 4996 )	//sprintf unsafe warning.
#	endif
#endif

#include <vector>
#include <string>
#include "jsont6_CDataPiece.h"
namespace jsni{
/**
	\namespace jsni
	Internal namespace, see \ref GP_ParseMainFncs "main routines" instead.
	This namespace that holds functions and classes that are intended for inteernal use.
	Instead, check documentation for for eg. jn_QuickFileParse() or jn_ParseString().
*/

// If not defined, template class' functions are compiled as non-inline.
// On MSVC compilers in non-inline mode classes are only instantiated
// with few common types, char, short, unsigned short, etc.
// In inline mode instantiation may be done automatically to any type.
// Compiling as non-inline is intended for debug purposes.
#define JSONT6_INLINE

// Define basic numeric types library is using.
// Three types: signed integer, unsigned enteger and floating point.
#ifdef _MSC_VER
	typedef __int64          JSONT6_INT64;
	typedef unsigned __int64 JSONT6_UINT64;
#else	//_MSC_VER
	typedef long long          JSONT6_INT64;
	typedef unsigned long long JSONT6_UINT64;
#endif	//_MSC_VER
typedef double JSONT6_FLOAT;


// Maximum nesting for "objects", objects and arrays.
// If exceeded, nesting is considered "too deep" and error is returned.
// NOTE: May be overriden by runtime setup of parser features.
#define JSONT6_MAX_NESTING (19)

// Macros for regarding inline or non-inline compiling.
#ifdef JSONT6_INLINE
#	define JSONT6_PUBLIC           public:
#	define JSONT6_PROTECTED        protected:
#	define JSONT6_PRIVATE          private:
#	define JSONT6_STATIC           static
#	define JSONT6_VIRTUAL          virtual
#	define JSONT6_TEMPLATECLASST
#else //JSONT6_INLINE
#	define JSONT6_PUBLIC
#	define JSONT6_PROTECTED
#	define JSONT6_PRIVATE
#	define JSONT6_STATIC
#	define JSONT6_VIRTUAL
#	define JSONT6_TEMPLATECLASST   template<class T>
#endif //JSONT6_INLINE


enum E_JSONT6_STR {
	JSONT6_STR_UNKNOWN,
	JSONT6_STR_UNQUOTED,
	JSONT6_STR_QUOTED_DBL,
	JSONT6_STR_QUOTED_SNGL,
};
enum ETokenizerError {
	ETKE_NONE,					///< no error.
	ETKE_UNEXPECTED_CHARACTER,	///< //x
	ETKE_NEWLINE_INSIDE_STRING,		//x
	ETKE_TAB_INSIDE_STRING,
	ETKE_UNEXPECTED_STR_END,		//x
	ETKE_UNKNOWN_STR_ESC_SEQ,	//x
	ETKE_ML_COMMENT_NOT_TERM,	///< multiline comment not terminated.
	ETKE_INVALID_FRACTION_FORMAT,	//x
	ETKE_INVALID_EXPONENT_FORMAT,	//x
	ETKE_UCSEQ_INVALID_CHARACTER,
	ETKE_UCSEQ_TOO_SHORT,
};

bool jn_PutFileBytes( const char* fn, const void* bytes, size_t size, size_t flags );

template<class T>
void AssignStdContainer( const T* ptr, size_t size, std::vector<T>& out )
{
	out.clear();
	for(; size; size--, ptr++ ){
		out.push_back( *ptr );
	}
}
template<class T>
void ConvertASCIICStringToVector( const char* sz, std::vector<T>& out )
{
	for(; *sz; sz++ ){
		out.push_back( T(*sz) );
	}
}

template<class T>
bool MatchAsciiStringToAnyArray( const char* szAsciiStr, const T* ptrAnyStr, size_t maxLength )
{
	const char* sz = szAsciiStr;
	for(; *sz; sz++, ptrAnyStr++, maxLength-- ){
		if(!maxLength)
			return 0;
		if( !(*ptrAnyStr == T(*sz)) )
			return 0;
	}
	return 1;
}
template<class T>
void ConvertStringToAnyArray( const char* szAsciiStr, std::vector<T>& out )
{
	out.clear();
	const char* sz = szAsciiStr;
	for(; *sz; sz++ ){
		T tmp( *sz );
		out.push_back( tmp );
	}
}

enum { ECTSF_NOFLAGS=0, ECTSF_ESCAPEQUOTES = 0x1, };

template<class T>
std::basic_string<T>& ConvertToSTDString( const std::vector<T>& arr, std::basic_string<T>& out, size_t flags = ECTSF_NOFLAGS )
{
	out.resize( 0 );
	T zeroc( 0 ), quot1('\''), quot2('\"'), bckslsh('\\');
	typename std::vector<T>::const_iterator a;
	for( a = arr.begin(); a != arr.end() && !(*a == zeroc); ++a ){
		//out.push_back( *a );
		if( flags & ECTSF_ESCAPEQUOTES && (*a == quot1 || *a == quot2 || *a == bckslsh)){
			out += bckslsh;
		}
		out += *a;
	}
	return out;
}
enum {
	/// One internal flag that is currently always assigned automatically.
	/// Related to it is \ref jnETKF_LiteralsAsDecimals "jnETKF_LiteralsAsDecimals".
	/// No literals or numbers, all will be stored as string type.
	/// eg. literal 'true' is stored simply as value of type STRING
	/// with it's text set to "true".
	jnETKF_Intrnl_AllAsStringTypes = 0x10000,
};

} // end namespace jsni

/// Flags used by jnSParseFeatures structure.
enum {
	/// Enables single quotes. In specification only double quotes are allowed.
	jnETKF_SingleQuote            = 0x1,
	/// Enables unquoted strings as property names.
	jnETKF_UnquotedStrings        = 0x2,
	/// Enables C++ style comments.
	/// Single line, that starts with double forward-slash character, and multiline.
	/// \image html "multiline_comment_text.png"
	jnETKF_Comments               = 0x4,
	/// Allow tab-character inside strings.
	/// Normally tab character or newline character are not allowed inside strings.
	/// This flag enables only tab-character (ASCII number: 0x09).
	jnETKF_TabInStrings           = 0x10,
	/// Converts literals to decimals. 'null' to 0, 'true' to 1 and 'false' to 0.
	/// Literals are converted to corresponding STRING types with text assigned "1" or "0".
	jnETKF_LiteralsAsDecimals = 0x40,
};
/// Used to specify which Json-T6 features should be enabled durning parsing.
/// See flags documentation, eg. \ref jnETKF_UnquotedStrings "jnETKF_UnquotedStrings".
struct jnSParseFeatures {
	size_t uFlags;			///< flags, eg. jnETKF_SingleQuote.
	jnSParseFeatures() : uFlags(0) {}
	jnSParseFeatures& all() { uFlags = 0xFFFFFFFF; return *this; }
	jnSParseFeatures& flags( size_t flags_ ) { uFlags = flags_; return *this; }
	jnSParseFeatures& flagsOn( size_t in ) { uFlags |= in; return *this; }
	jnSParseFeatures& flagsOff( size_t in ) { uFlags &= ~in; return *this; }
};
/// Error codes used by jnSParseError ('code' member).
enum jnETryParseError {
	jnETPE_None,
	jnETPE_TokenizerError,
	jnETPE_UnexpectedEof,
	jnETPE_InvalidPropertyname,
	jnETPE_NoColonAfterVarname,
	jnETPE_UnrecognizedValOfVar,
	jnETPE_InvalidNextpropchar,
	jnETPE_FailedRootObjParse,
	jnETPE_EmptySubject,
	jnETPE_RootObjTrailer,
	jnETPE_ObjNestingTooDeep,
};
/// Used as result for errors that may occur durning parsing.
template<class T> struct jnSParseError {
	std::string         msg;
	jnETryParseError    code;
	jsni::CDataPiece<T> sp;
	size_t              uLine;
	//
	jnSParseError() : code(jnETPE_None), uLine(0) {}
	void errorEOF(const jsni::CDataPiece<T>& sp_) { *this = jnSParseError<T>(); code = jnETPE_UnexpectedEof; msg = "Unexpected End of file"; sp = sp_; }
	void set( jnETryParseError code_, const char* msg_, jsni::CDataPiece<T> sp_ ) { code = code_; msg = msg_; sp = sp_; }
	bool error()const { return code != jnETPE_None; }
};

enum {
	jnEAEF_Recursive = 0x1,
};

enum {
	jnEPFBF_Append = 0x1,
};

#endif //_JSONT6_ROUTINES_H_
