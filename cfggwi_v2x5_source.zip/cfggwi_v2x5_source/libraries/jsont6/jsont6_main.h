
#ifndef _JSONT6_MAIN_H_
#define _JSONT6_MAIN_H_
#include "jsont6_CParser.h"

/**
	\mainpage

	\section intro_sec Introduction

	C++ oriented library that provides basic routines for working 
	with JSON formated text.
	
	Usefull documentation sections:
	\li jn_QuickFileParse() function
	\li jn_ParseString() function
	\li \ref jnValue "jnValue<T>" class

	Example of JSON format file:
	\verbatim
		{
			"varA": "var_a",
			"varB": "var_b",
			"varC": 1.1,
			"varD": 25000
		}
	\endverbatim
	
	C++ code example:
	\verbatim
		#include "jsont6_main.h"
		using namespace jsni;
		// ...
		// ...
		jnValue<char> RootValue;
		jn_QuickFileParse("./config.json", RootValue );

		std::vector<jnValue<char> >::const_iterator a;
		std::vector<jnValue<char> >& properties = RootValue.children();
		for( a = properties.begin(); a != properties.end(); ++a ){
			printf("%s: %s\n", a->getName().c_str(), a->toSTDString().c_str() );
			if( a->isObjectOrArray() ){
				// ...
			}
		}
	\endverbatim
	

	<b>Notes about JSON files:</b> \n
	All JSON files must have it's root element appear as object or array.
	<ul>
		<li> Object: curly brackets.</li>
		<li> Array: square brackets, no property names for each element because they're autonumbered.</li>
	</ul>
	By default in specification every ptoperty name must appear as quoted string.
	This library extends this by allowing setting appropriate flags, to allow for 
	shorter syntax and property names without quotes.
	For this, jnSParseFeatures structure is used, for default parsing
	it's metod \ref jnSParseFeatures::all() "all()" is used that sets all 
	additional features provided by this library.
	Example flags: \ref jnETKF_SingleQuote "jnETKF_SingleQuote", 
	\ref jnETKF_Comments "jnETKF_Comments", etc.\n

	Library is using various modules from STL Library, eg.
	<ul>
		<li> std::string </li>
		<li> std::vector<T> </li>
	</ul>

	\section instructions_sec Instructions

	Compile all source files with your program.
	
	Use this file as main include file:
	\code
		#include "jsont6_main.h"
	\endcode
	Alternativelly individual files may be used as well.
	eg. "jsont6_jnValue.h".
*/

#endif //_JSONT6_MAIN_H_
