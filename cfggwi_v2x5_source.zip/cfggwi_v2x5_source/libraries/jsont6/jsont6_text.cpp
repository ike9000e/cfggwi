
#include "jsont6_text.h"
namespace jsni{
;

} // end namespace jsni
