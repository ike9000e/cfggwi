
#ifndef _JSONT6_SPRINT64_H_
#define _JSONT6_SPRINT64_H_
#include "jsont6_text.h"
#include "jsont6_routines.h"
namespace jsni{
;
/*
	file descr.
	------------
	String print functions for 64 bit integers.
	//Note, operating on multibyte strings is enough since only ascii characters are used...
*/

char*         si_sprintU64( JSONT6_UINT64 a, char* Buffer, const char* comma = "", int base = 10, int digit_grouping = 3, int desired_min_length = 0, char prepend_with = 0 );
char*         si_sprintS64( JSONT6_INT64 a, char* Buffer, const char* comma="", int base=10, int digit_grouping=3 );
JSONT6_UINT64 si_atoU64( const char* in, int base = 10, bool* u64overflow = 0 );


void _SprintThousand( unsigned int in, char* Buffer, int base );
extern const char* jsont6_sprint64_indiced_characters;

/// Comprehensive string print of unsigned integer of any type (uses template parameter).
/// May be used to print any type of value, incl. 64-bit, bool, ..., and output
/// string in any desired base (note: currrently max safe base is 32).
/// For example, set 'base' to 10 for decimal output, to 2 for binary and to 16 for 
/// hexadecimal. 'base' must not be lower than 2.
template<class T>
char* si_sprintUT( T in, char* Buffer, const char* comma = "", int base = 10,
				  int digit_grouping = 3, int desired_min_length = 0, char prepend_with = 0 )
{
	*Buffer = 0;
	char bfrThousand[128], bfrTmp[128];
	int i;
	T a = in, reminder, thousand = 1;
	for( i=0; i<digit_grouping; i++, thousand *= base );
	for(;;){
		reminder = a % thousand;
		a /= thousand;
		if(a){
			si_sprintUT( reminder, bfrThousand, 0, base, digit_grouping + 1, digit_grouping, 
				jsont6_sprint64_indiced_characters[0] );
		}else{
			_SprintThousand( (unsigned int)reminder, bfrThousand, base );
		}
		si_strcpy( bfrTmp, Buffer );
		si_strcpy( Buffer, bfrThousand );
		if( comma && *bfrTmp ){
			si_strcat( Buffer, comma );
		}
		si_strcat( Buffer, bfrTmp );
		if(!a)
			break;
	}
	if( desired_min_length && prepend_with ){
		int ln = (int) si_strlen( Buffer );
		if( ln < desired_min_length ){
			int num = desired_min_length - ln;
			char bfr[] = { prepend_with, 0, };
			si_strcpy( bfrTmp, Buffer );
			*Buffer = 0;
			for(; num--; ){
				si_strcat( Buffer, bfr );
			}
			si_strcat( Buffer, bfrTmp );
		}
	}
	return Buffer;
}

/// Similar to si_sprintUT() but for signed integers.
template<class T>
char* si_sprintST( T a, char* Buffer, const char* comma="", int base=10, int digit_grouping=3 )
{
	*Buffer = 0;
	char* bfr = Buffer;
	T val = a;
	if( val < 0 ){
		val *= -1;
		Buffer[0] = '-';
		Buffer[1] = 0;
		bfr = &Buffer[1];
	}
	si_sprintUT<T>( val, bfr, comma, base, digit_grouping );
	return Buffer;
}

} // end namespace jsni

#endif //_JSONT6_SPRINT64_H_
