
#ifndef _JSONT6_TEXT_H_
#define _JSONT6_TEXT_H_
#include <string>
namespace jsni {

template<class T>
size_t si_strlen( const T* in )
{
	const T* sz = in;
	for(; *sz; sz++ );
	return sz - in;
}
template<class T>
const T* si_strchr( const T* sz, T ch )
{
	T a;
	for(; (a = *sz); sz++ )
		if( a == ch )
			return sz;
	return 0;
}
template<class T>
const T* si_strrchr( const T* in, T ch )
{
	size_t len = si_strlen( in );
	if(len){
		const T* sz = &in[len];
		for( sz--; sz >= in; sz-- ){
			if( *sz == ch )
				return sz;
		}
	}
	return 0;
}

/// Returns new position in left trimmed string.
template<class T>
const T* si_ltrim( const T* in, const T* szCharset )
{
	size_t i;
	for( i=0; in[i] && si_strchr( szCharset, in[i] ); i++  );
	return &in[i];
}

/// Returns new string length, after right trim operation.
template<class T>
size_t si_rtrim( const T* in, const T* szCharset )
{
	int len = (int) si_strlen(in);
	int c = 0;
	const T* b = &in[len];
	b--;
	for(; b>=in && si_strchr( szCharset, *b ); b-- )
		c++;
	return len - c;
}
/// See si_ltrim() and si_rtrim().
template<class T>
const T* si_trim( const T* in, const T* szCharset, size_t* length_out )
{
	const T* str = si_ltrim( in, szCharset );
	*length_out = si_rtrim( str, szCharset );
	return str;
}
template<class T>
std::basic_string<T> si_ltrim_stdstring( const T* in, const T* whitespacescharset )
{
	return si_ltrim( in, whitespacescharset );
}
template<class T>
std::basic_string<T> si_rtrim_stdstring( const T* in, const T* whitespacescharset )
{
	std::basic_string<T> str = in;
	typename std::basic_string<T >::reverse_iterator a;
	for( a = str.rbegin(); a != str.rend(); ){
		if( si_strchr( whitespacescharset, *a ) ){
			a = std::basic_string<T>::reverse_iterator( str.erase( (++a).base() ) );
		}else{
			break;
		}
	}
	return str;
}
template<class T>
std::basic_string<T> si_trim_stdstring( const T* in, const T* whitespacescharset )
{
	std::basic_string<T> str;
	size_t size = 0;
	const T* sz = si_trim( in, whitespacescharset, &size );
	str.assign( sz, size );
	return str;
}
template<class T>
long si_strcmp( const T* sz1, const T* sz2, long len = -1 )
{
	if(len){
		for(; *sz1 == *sz2 && *sz1 && --len; sz1++, sz2++ );
		if( *sz1 != *sz2 )
			return *sz1 < *sz2 ? -1: 1;
	}
	return 0;
}
template<class T>
class SiICharPredicate {
public:
	virtual bool lessThan( const T& a, const T& b )const = 0;
	virtual bool equal( const T& a, const T& b )const = 0;
};
template<class T>
class SiCCharDfltPred : public SiICharPredicate<T> {
public:
	virtual bool lessThan( const T& a, const T& b )const{
		return a < b;
	}
	virtual bool equal( const T& a, const T& b )const{
		return a == b;
	}
};
// String comparison with predicate class.
template<class T>
long SiStrCmpPred( const T* sz1, const T* sz2, long len,
				 const SiICharPredicate<T>& predicate )
{
	if(len){
		for(; predicate.equal( *sz1, *sz2 ) && *sz1 && --len; sz1++, sz2++ );
		if( !predicate.equal( *sz1, *sz2 ) )
			return predicate.lessThan( *sz1, *sz2 ) ? -1: 1;
	}
	return 0;
}
template<class T>
T SiGetLowerThroughASCII( const T& in )
{
	static const char* lwrs = "abcdefghijklmnopqrstuvwxyz";
	static const char* uprs = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	long a = (long)in;
	if( a <= 'Z' ){
		char b = (char)a;
		const char* pos;
		if( pos = si_strchr<char>( uprs, b ) ){
			size_t idx = pos - uprs;
			return (T) lwrs[idx];
		}
	}
	return in;
}
template<class T>
class SiCCharCaseInsensitivePred : public SiICharPredicate<T> {
public:
	virtual bool lessThan( const T& a, const T& b )const{
		return SiGetLowerThroughASCII(a) < SiGetLowerThroughASCII(b);
	}
	virtual bool equal( const T& a, const T& b )const{
		return SiGetLowerThroughASCII(a) == SiGetLowerThroughASCII(b);
	}
};
// Case-insensitive string comparison.
template<class T>
long si_strcasecmp( const T* sz1, const T* sz2, long len = -1 )
{
	SiCCharCaseInsensitivePred<T> pred;
	return SiStrCmpPred<T>( sz1, sz2, len, pred );
}
template<class T>
long si_stroptcmp( const T* sz1, const T* sz2, long len = -1, bool bCaseInsensitive=0 )
{
	if(bCaseInsensitive){
		SiCCharCaseInsensitivePred<T> pred;
		return SiStrCmpPred<T>( sz1, sz2, len, pred );
	}else{
		SiCCharDfltPred<T> pred;
		return SiStrCmpPred<T>( sz1, sz2, len, pred );
	}
}
template<class T>
const T* SiStrStrPred( const T* str1, const T* str2, const SiICharPredicate<T>& pred )
{
	size_t len2 = si_strlen( str2 );
	for(; *str1; str1++ )
		if( !SiStrCmpPred<T>( str1, str2, len2, pred ) )
			return str1;
	return 0;
}
template<class T>
const T* si_strstr( const T* str1, const T* str2 )
{
	SiCCharDfltPred<T> pred;
	return SiStrStrPred<T>( str1, str2, pred );
}
// Case-insensitive si_strstr.
template<class T>
const T* si_stristr( const T* str1, const T* str2 )
{
	SiCCharCaseInsensitivePred<T> pred;
	return SiStrStrPred<T>( str1, str2, pred );
}

/// Finds first occurence of str2 inside str1, returns 0 on failure.
//tcsstrnn_i
template<class T>
const T* si_strstrnn( const T* str1, size_t len1, const T* str2, size_t len2,
		   bool bCaseInsensitive )
{
	for(; len1 && len1>=len2; str1++, len1-- )
		if( !si_stroptcmp( str1, str2, len2, bCaseInsensitive ) )
			return str1;
	return 0;
}
template<class T>
bool si_strEndsWith( const T* in, const T* ending, bool bCaseInsensitive=0,
					int maxlen=-1 )
{
	int ln = si_strlen( ending );
	int len = si_strlen( in );
	if( maxlen >=0 && ln >= maxlen )
		ln = maxlen;
	while( ln-- ){
		if( !len-- )
			return 0;
		if( bCaseInsensitive ){
			if( si_strcasecmp( &in[len], &ending[ln], 1 ) )
				return 0;
		}else{
			if( in[len] != ending[ln] )
				return 0;
		}
	}
	return 1;
}

class CLengthAdaptor
{
	bool bLengthOmited, bLenNeg; long nLength;
public:
	CLengthAdaptor() : bLengthOmited(1)
	{}
	CLengthAdaptor( long len ) : bLengthOmited(0), nLength(len)
	{
		if(nLength < 0){
			nLength *= -1;
			bLenNeg = 1;
		}else{
			bLenNeg = 0;
		}
	}
	bool isLengthOmited()const { return bLengthOmited; }
	bool isLengthNegative()const { return bLenNeg; }
	long  length()const { return nLength; }
};
template<class T> T si_min( const T& a, const T& b )
{
	return a < b ? a : b;
}
template<class T> T si_max( const T& a, const T& b )
{
	return a < b ? b : a;
}

/**
	Returns the portion of input string ('in') specified by the 'start' and
	'length' parameters.
	in -
		The input string
	start -
		If start is non-negative, the returned string will start at the start'th
		position in string, counting from zero. For instance, in the string 'abcdef',
		the character at position 0 is 'a', the character at position 2 is 'c', and so forth.

		If start is negative, the returned string will start at the start'th character from
		the end of string.

		If string is less than or equal to start characters long, empty string
		will be returned.

	length -
		If length is given and is positive, the string returned will contain at most
		length characters beginning from start (depending on the length of string).

		If length is given and is negative, then that many characters will be omitted
		from the end of string
*/
template<class T>
std::basic_string<T> si_substr( const T* in, long start,
							   const CLengthAdaptor& length = CLengthAdaptor() )
{
	if( !length.isLengthOmited() && !length.length() )
		return std::basic_string<T>();
	size_t len = si_strlen(in);
	const T* sz;
	if( start >= 0 ){
		if( start > len )
			return std::basic_string<T>();
		sz = &in[start];
	}else{
		start *= -1;		//abs.
		start = si_min<long>( start, len );
		sz = &in[ len - start ];
	}
	if( !length.isLengthOmited() ){
		if( !length.isLengthNegative() ){
			len = length.length();
		}else{
			len = si_strlen(sz);
			if( len < length.length() ){
				len = 0;
			}else{
				len = si_min<size_t>( len, len - length.length() );
			}
		}
	}
	return std::basic_string<T>( sz, len );
}
// Returns directory part given path.
template<class T>
std::basic_string<T> si_dirname( const T* in )
{
	const T *sz;
	sz = si_max( si_strrchr( in, (T)'\\' ), si_strrchr( in, (T)'/' ) );
	if( sz ){
		return std::basic_string<T>( in, sz - in );
	}else{
		return in;
	}
}
template<class T>
std::basic_string<T> si_anyStr( const char* in )
{
	std::basic_string<T> out;
	for(; *in; in++ )
		out += (T)*in;
	return out;
}
// Returns base name part (filename + extension) given path.
template<class T>
std::basic_string<T> si_basename( const T* in )
{
	const T *sz;
	if( *in == (T)0 )
		return si_anyStr<T>(".");
	sz = si_max( si_strrchr( in, (T)'\\' ), si_strrchr( in, (T)'/' ) );
	if( sz ){
		return sz + 1;
	}else{
		return in;
	}
}
template<class T>
std::string si_AsciiStr( const T* in )
{
	std::string out;
	for( ; *in; in++ ){
		char c = (char)*in;
		out += c;
	}
	return out;
}
/// Reverses a string inside buffer given number of starting characters to perform reverse on.
template<class T>
T* si_strrevn( T* in, size_t num )
{
	if( num > 1 ){
		T* const end  = in + num;
		T* const bgn  = in;
		T* const rbgn = end - 1;
		const size_t half = num / 2;
		size_t i;
		T* head, *tail, tmp;
		for( i=0; i<half; i++ ){
			head = bgn  + i;
			tail = rbgn - i;
			//
			tmp = *head;
			*head = *tail;
			*tail = tmp;
		}
	}
	return in;
}
/// Reverses a string inside buffer.
template<class T>
T* si_strrev( T* in )
{
	return si_strrevn<T>( in, si_strlen( in ) );
}

/// Reverses a string returning std string.
template<class T>
std::basic_string<T> si_strrevn_stdstring( const T* in, size_t num )
{
	std::basic_string<T> out;
	if( num > 1 ){
		const T* const end  = in + num;
		const T* const bgn  = in;
		const T* const rbgn = end - 1;
		const size_t half = num / 2;
		size_t i;
		const T *src;
		for( i=0; i<num; i++ ){
			if( i < half ){
				src = rbgn - i;
			}else if( i > half - !(num&1) ){
				src = bgn + ((num - i) - 1);
			}else{
				src = bgn + i;
			}
			out += *src;
		}
	}else if( num == 1 ){
		out += *in;
	}
	return out;
}
template<class T>
std::basic_string<T> si_strrev_stdstring( const T* in )
{
	return si_strrevn_stdstring( in, si_strlen( in ) );
}


template<class T>
T* si_strcat( T* str1, const T* str2 )
{
	T* dst = str1 + si_strlen( str1 );
	for(; *str2; dst++, str2++ ){
		*dst = *str2;
	}
	*dst = 0;
	return str1;
}
template<class T>
T* si_strcpy( T* to, const T* from )
{
	T* dst = to;
	for(;; from++, dst++ ){
		*dst = *from;
		if( *from == 0 )
			break;
	}
	return to;
}
/// The strncpy function copies at most 'count' characters of 'from' to the string 'to'.
/// If 'from' has less than 'count' characters, the remainder is padded with '\0' characters.
/// The return value is the resulting string ('to').
/// Note, si_strncpy() not NULL terminate the resulting string automatically!
template<class T>
T* si_strncpy( T* to, const T* from, size_t count )
{
	T* dst = to;
	bool bEbdReached = 0;
	for(; count; dst++, count-- ){
		if( !bEbdReached ){
			*dst = *from;
			if( *from == 0 )
				bEbdReached = 1;
			from++;
		}else{
			*dst = 0;
		}
	}
	return to;
}

} // end namespace jsni

#endif //_JSONT6_TEXT_H_
