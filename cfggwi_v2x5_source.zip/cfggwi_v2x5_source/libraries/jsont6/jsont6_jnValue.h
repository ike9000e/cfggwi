
#ifndef _JSONT6_JN_VALUE_H_
#define _JSONT6_JN_VALUE_H_

#include <vector>
#include <string>
#include <stdio.h>
#include "jsont6_routines.h"
#include "jsont6_sprint64.h"
namespace jsni{
	template<class T> class CParser;
} // end namespace jsni


/// Class used as vaule result in parsing operations.
/// Recursive class that in case of objects/arays contains properties made of
/// one or more child values.
/// For properties, std::vector<jnValue<T> > arrays are used.
/// Methods getName() and toSTDString() can be used to extract name and value.
/// \sa GP_ParseMainFncs
template<class T>
class jnValue
{
	enum EValueType {
		EVT_OBJECT,
		EVT_ARRAY,
		EVT_INVALID_VALUE,
		EVT_STRING,
		EVT_NUMBER,
		EVT_LITERAL,
	};
	enum ENumberType {
		ENT_INTEGER,
		ENT_FLOAT,
	};
	typedef std::vector<jnValue<T> > LsCValue;
	friend class jsni::CParser<T>;
public:
	typedef std::vector<jnValue<T> > ArrayType;
#ifndef JSONT6_INLINE
public:
	jnValue();
	~jnValue();
	std::basic_string<T>            getName()const;
	bool                            isObjectOrArray()const;
	std::basic_string<T>            toSTDString()const;
	bool                            isInvalid()const;
	const jnValue<T>&               getProperty( size_t index )const;
	const jnValue<T>&               getPropertyByName( const T* szPropName )const;
	std::basic_string<T>            getPropertyByName2( const T* szPropName, const T* dfltIfNoSuchProp )const;
	jnValue<T>&                     getPropertyByName3( const T* szPropName );
	jnValue<T>&                     setName( const T* name_ );
	jnValue<T>&                     setString( const T* in );
	jnValue<T>&                     setIsObject();
	jnValue<T>&                     setIsArray();
	const std::vector<jnValue<T> >& children()const;
	std::vector<jnValue<T> >&       children();
	const jnValue<T>&               getPropertyByIndex( size_t index )const;
	// V 1.2:
	std::basic_string<T> strSerialize( const T* szNlMode )const;
	std::basic_string<T> strPrint( const T* szPrefix, size_t depth )const;
	static std::basic_string<T> strPrint2( const std::vector<jnValue<T> >& proplist, const T* szPrefix, size_t depth, bool bArray, const T* szNLMode );
	static void arrayExtendKey( std::vector<jnValue<T> >& inp, const std::vector<jnValue<T> >& extendWith, size_t flags );
	static void arrayIntersectKey( std::vector<jnValue<char> >& inp, const std::vector<jnValue<char> >& intersectWith, size_t flags );
	bool writeToJsonFile( const char* szJsonInitFname, const T* szOptionalRawHeader )const;
	jnValue<T>& setProperty( const T* szPropName, const T* szValue );
private: //JSONT6_PRIVATE
	bool                           isObject()const;
	bool                           isArray()const;
	bool                           isString()const;
	bool                           isInteger()const;
	bool                           isFloat()const;
	bool                           isLiteral()const;
	void                           toCString( T* buffer, size_t size )const;
	const jsni::JSONT6_INT64&            toInteger()const;
	const jsni::JSONT6_FLOAT&            toFloat()const;
	const std::vector<T>&          toLiteral()const;
	std::basic_string<T>           toLiteralViaSTDString()const;
	jnValue<T>& setName2( const std::vector<T>& in );
	jnValue<T>& setName2( const jsni::CDataPiece<T>& in );
	jnValue<T>& setFloat( const jsni::JSONT6_FLOAT& in );
	jnValue<T>& setInteger( const jsni::JSONT6_INT64& in );
	jnValue<T>& setLiteral( const std::vector<T>& in );
	jnValue<T>& setString2( const std::vector<T>& in );
	jnValue<T>& setString2( const jsni::CDataPiece<T>& in );
	jnValue<T>& setString2( const std::vector<T>& in, jsni::E_JSONT6_STR eStrType );
	jnValue<T>& setString2( const jsni::CDataPiece<T>& in, jsni::E_JSONT6_STR eStrType );
//	jnValue<T>              getPropertyByName3__( const T* szPropName, const T* szDfltIfNoSuchProp )const;
	const jnValue<T>&       getProperty3( const jsni::CDataPiece<T>& dpPropName )const;
	const jnValue<T>&       getProperty3( const std::vector<T>& arPropName )const;
	std::basic_string<T>    getProperty2( const T* szPropName )const;
//	jnValue<T>&             setPropertyAsCString( const T* szPropName, const T* szValue );
	const jnValue<T>&       getPropertyViaCString4( const T* szPropName )const;
	const jnValue<T>&       getPropertyViaCString2( const T* szPropName, const jnValue<T>& dfltIfNoSuchProp )const;
	const std::vector<T>&   getName3()const;
//private: //JSONT6_PRIVATE
	jnValue( EValueType e );
	typename LsCValue::iterator       addChild2( const jnValue<T>& in );
	typename LsCValue::iterator       findChildByName1( const jsni::CDataPiece<T>& name );
	typename LsCValue::const_iterator findChildByName1c( const jsni::CDataPiece<T>& name )const;
	typename LsCValue::iterator       findChildByName2( const std::vector<T>& name );
	typename LsCValue::const_iterator findChildByName3( const std::vector<T>& name )const;
	void                     assign( const jnValue<T>& other, bool bSkipName );
//private: //JSONT6_PRIVATE
	static size_t               calcBiggestLength2( typename LsCValue::const_iterator bgn, typename LsCValue::const_iterator end );
	static bool                 isObjectAndChildrenNotEmpty( typename LsCValue::const_iterator a );
	static size_t               maxLocalSizeT( size_t a, size_t b );
	void                        ctorCommon();
	std::string                 getNumberAsString()const;
	jnValue<T>&                 setIsObject2( bool in );
	jnValue<T>&                 setIsArray2( bool in );
	size_t                      getCStringLength( const T* in )const;
#else //JSONT6_INLINE
#	include "jsont6_jnValue.inl"
#endif //JSONT6_INLINE
private:
	std::vector<T>           Name;
	std::vector<T>           Dstring;
	jsni::JSONT6_INT64       IntegerValue;
	jsni::JSONT6_FLOAT       FloatValue;
	LsCValue                 Children;
	EValueType               Type;
	ENumberType              NumberType;
	jsni::E_JSONT6_STR       StringType;
	//
	static bool              bCountCValueTpls;
	static int               nCountCValueTpls;
};
template<class T> bool jnValue<T>::bCountCValueTpls = 0;
template<class T> int  jnValue<T>::nCountCValueTpls = 0;

typedef jnValue<char> jnVal;

#endif //_JSONT6_JN_VALUE_H_
