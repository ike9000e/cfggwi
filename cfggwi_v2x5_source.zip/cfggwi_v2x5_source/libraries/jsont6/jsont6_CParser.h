
#ifndef _JSONT6_C_PARSER_H_
#define _JSONT6_C_PARSER_H_
#include <cstdlib>
#include "jsont6_CStringPiece.h"
#include "jsont6_jnValue.h"
#include "jsont6_CTokenizer.h"
namespace jsni {
;

enum EParseFeaturesFlags {
	EPFF_SINGLE_QUOTE             = 0x1,	///< Allow single quote strings. Including single quoted property names.
	EPFF_UNQUOTED_PROPERTY_VALUES = 0x2,	///< Allow unquoted property values.
	EPFF_UNQUOTED_PROPERTY_NAMES  = 0x4,	///< Allow unquoted property names.
	EPFF_EXTRA_COMMA              = 0x8,	///< Allow extra comma trailing last object's or array's property.
	EPFF_COMMENTS                 = 0x10,	///< Allow C++ style comments.
	EPFF_NESTING_DEPTH_256        = 0x40,	///< Allow nesting for this depth maximum, default is defined by JSONT6_MAX_NESTING.
	EPFF_NESTING_DEPTH_1024       = 0x80,
	EPFF_NESTING_DEPTH_UNLIMITED  = 0x100,	///< Unlimited nesting for array and objects.
	EPFF_TAB_IN_STRINGS           = 0x200,	///< Allow tab character in strings, note, not escape sequence \\t but actual ASCII character.
};

template<class T> struct SParserIn {
	jnSParseFeatures                 features;
	IUnicodeSequenceConversion*    lpUnicodeSequenceConversion;
};

template<class T>
class CParser
{
	typedef std::vector<CToken<T> > LsToken2;
	typedef typename LsToken2::const_iterator TCITR;
	struct SBeginEnd {
		TCITR bgn;
		TCITR end;
		SBeginEnd( const TCITR& bgn_, const TCITR& end_ )
			: bgn(bgn_), end(end_)
		{}
		bool         empty()const { return bgn == end; }
		SBeginEnd&   inc() { ++bgn; return *this; }
	};
	struct SParseState {
		size_t uNestingAttempt;
		SParseState() : uNestingAttempt(0) {}
	};
#ifndef JSONT6_INLINE
public:
	CParser();
	CParser( const SParserIn<T>& in );
	CParser( const jnSParseFeatures& features_ );
	virtual ~CParser() {}
	// Parses input c-string.
	// 'length' parameter may be set to -1 to indicate null-terminated string.
	bool parse( const T* subject, int length, jnValue<T>& RootValue );
	bool parse( const CDataPiece<T>& subject, jnValue<T>& RootValue );
	// Returns error structure for user reference.
	virtual const jnSParseError<T>& error()const;
	virtual const STokenizerError<T>& tokenizerError()const;
	static bool quickFileParse( const char* szFname, jnValue<char>& RootValueOut, std::string* err, jnSParseError<char>* err2, const jnSParseFeatures& features );
private:	//JSONT6_PROTECTED
	bool parseForValueOnly( const CDataPiece<T>& subject, jnValue<T>& out );
	bool runTokenizer( const CDataPiece<T>& sp, LsToken2* resultlist, STokenizerError<T>& error )const;
	bool parseTokensForRootValue( const LsToken2* in, jnValue<T>* rootValue );
	void alterTokensAfterTokenizer( LsToken2& in )const;
	bool tryObjectParse( const SBeginEnd& be, jnValue<T>& values, TCITR& end, jnSParseError<T>& error );
	bool doPropertiesParse( const SBeginEnd& be, ETokenStructuralCharacter eTerminatingBrkt, std::vector<jnValue<T> >& values, TCITR& end, jnSParseError<T>& error );
	bool doVarColonValueParse( const SBeginEnd& be, jnValue<T>& value, TCITR& end, jnSParseError<T>& error );
	static CDataPiece<T> getErrorEofSp( const SBeginEnd& in );
	bool tokenToValue( const CToken<T>& token, jnValue<T>& value );
	void convertFromComponents( const STokenNumberComponents& in, JSONT6_FLOAT& outFloat, JSONT6_INT64& outInteger, bool* bIsIntegeer )const;
	bool doValueParse( const SBeginEnd& in, jnValue<T>& value, TCITR& end, jnSParseError<T>& error );
	void initCconstructorDefaults();
	static size_t jsont6_GetFileSize( FILE* hf );
	static size_t getLineNumberFromError( const CDataPiece<T>& subject2, const jnSParseError<T>& sErr );
#else //JSONT6_INLINE
#	include "jsont6_CParser.inl"
#endif //JSONT6_INLINE
private:
	jnSParseError<T>   Error;
	STokenizerError<T> TokenizeError;
	SParserIn<T>       In;
	SParseState        sPrsState;
	//
	static IUnicodeSequenceConversion UnicodeSequenceConversionDflt;
};
template<class T> IUnicodeSequenceConversion CParser<T>::UnicodeSequenceConversionDflt;

/// \cond DOXYGEN_SKIP
void js_TestMisc();
/// \endcond //DOXYGEN_SKIP

} // end namespace jsni

/**
	\defgroup GP_ParseMainFncs Main JSON parsing routines.
	...
	jn_ParseString() \n
	jn_QuickFileParse() \n
	\ref jnValue "jnValue<T>" \n
*/


bool jn_QuickFileParse( const char* szFname, jnValue<char>& RootValueOut, std::string* err = 0, jnSParseError<char>* err2 = 0, const jnSParseFeatures& features = jnSParseFeatures().all() );

/// Comprehensive JSON parsing function that takes c-string as input.
/// Input parameter 'length' may be set to -1 to indicate subject null-terminated.
/// \sa GP_ParseMainFncs
template<class T>
bool jn_ParseString( const T* subject, int length, jnValue<T>& RootValue,
					std::string* err = 0, jnSParseError<T>* err2 = 0,
					const jnSParseFeatures& features = jnSParseFeatures().all() )
{
	jsni::CParser<char> parser( features );
	bool rs = parser.parse( subject, length, RootValue );
	if(err)
		*err = parser.error().msg.c_str();
	if(err2)
		*err2 = parser.error();
	return rs;
}

#endif //_JSONT6_C_PARSER_H_
