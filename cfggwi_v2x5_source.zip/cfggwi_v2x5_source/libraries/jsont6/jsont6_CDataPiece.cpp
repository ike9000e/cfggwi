
#include "jsont6_CDataPiece.h"
namespace jsni{

} // end namespace jsni
