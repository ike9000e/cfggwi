
#include "jsont6_CTokenizer.h"
namespace jsni{
;

#if !defined(JSONT6_INLINE)
#	include "jsont6_CTokenizer.inl"
#	ifdef _MSC_VER
		// MSVC specific template iinstatiations.
		template class CTokenizer<char>;
		template class CTokenizer<short>;
		template class CTokenizer<long>;
		template class CTokenizer<unsigned char>;
		template class CTokenizer<unsigned short>;
		template class CTokenizer<unsigned long>;//*/
#	endif //_MSC_VER
#endif //JSONT6_INLINE


} // end namespace jsni
