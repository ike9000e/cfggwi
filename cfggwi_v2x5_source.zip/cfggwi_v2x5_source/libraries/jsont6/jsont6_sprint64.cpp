
#include "jsont6_sprint64.h"
namespace jsni{
;

// indiced array for finding value of a character.
const char* jsont6_sprint64_indiced_characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

void _SprintThousand( unsigned int in, char* Buffer, int base )
{
	unsigned int a = in;
	*Buffer = 0;
	int reminder, i;
	for( i=0;; i++ ){
		reminder = a % base;
		a /= base;
		Buffer[i] = jsont6_sprint64_indiced_characters[reminder];
		Buffer[i+1] = 0;
		if(!a)
			break;
	}
	si_strrev( Buffer );	//_tcsrev()
}

// String prints 64 bit value.
// a      - Value to convert to string.
// Buffer - Output buffer for value. Size 128 is enough.
// comma  - Separator for thosand parts.
// base   -
// digit_grouping - digit grouping. in base-10 setting this to 3 causes thousand grouping, each 3 digits comma is inserted.
// desired_min_length -
// prepend_with -
char* si_sprintU64( JSONT6_UINT64 in, char* Buffer, const char* comma, int base, int digit_grouping,
				 int desired_min_length, char prepend_with )
{
	return si_sprintUT( in, Buffer, comma, base, digit_grouping, desired_min_length, prepend_with );
}

char* si_sprintS64( JSONT6_INT64 a, char* Buffer, const char* comma, int base, int digit_grouping )
{
	*Buffer = 0;
	char* bfr = Buffer;
	JSONT6_INT64 val = a;
	if( val < 0 ){
		val *= -1;
		Buffer[0] = '-';
		Buffer[1] = 0;
		bfr = &Buffer[1];
	}
	si_sprintU64( (JSONT6_UINT64) val, bfr, comma, base, digit_grouping );
	return Buffer;
}


const char* whitespaces = " \r\n\t";

bool _CharacterToValue( int ch, int base, int* value )
{
	*value = 0;
	char bfr[2] = { (char)toupper(ch), 0, };
	//_strupr( bfr );
	//bfr[0] = toupper( bfr[0] );
	ch = bfr[0];
	const char* szChr = si_strchr<char>( jsont6_sprint64_indiced_characters, ch );
	if( szChr ){
		int index = (int) (szChr - jsont6_sprint64_indiced_characters);
		if( index < base ){
			*value = index;
			return 1;
		}
	}
	return 0;
}


JSONT6_UINT64 si_atoU64( const char* in, int base, bool* u64overflow )
{
	// skip any leading whitespaces.
//	for(; *in && _tcschr( whitespaces, *in ); in++ );
	for(; *in && si_strchr( whitespaces, *in ); in++ );

	const char* bgn = in;
	int i, value;

	// scan for end.
	const char* end; int dummy;
	for( end = bgn, i=0; *end && _CharacterToValue( *end, base, &dummy ); end++, i++ );

	if( bgn == end )
		return 0;

	JSONT6_UINT64 a = 0, weight = 1, tmp;
	const char* rbgn;
	char ch;
	for( rbgn = end-1, i=0; rbgn >= bgn; rbgn--, i++, weight *= base ){
		ch = *rbgn;
		_CharacterToValue( (int) ch, base, &value );
		// detect overflow.
		tmp = a + value * weight;
		if( tmp < a ){
			if( u64overflow )
				*u64overflow = 1;
			break;
		}
		a = tmp;
	}
	return a;
}//*/




} // end namespace jsni
