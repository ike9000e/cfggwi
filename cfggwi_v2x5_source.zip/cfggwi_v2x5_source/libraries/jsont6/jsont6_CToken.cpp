
#include "jsont6_CToken.h"
namespace jsni{
;

#if !defined(JSONT6_INLINE)
#	include "jsont6_CToken.inl"
#	ifdef _MSC_VER
		// MSVC specific template iinstatiations.
		template class CToken<char>;
		template class CToken<short>;
		template class CToken<long>;
		template class CToken<unsigned char>;
		template class CToken<unsigned short>;
		template class CToken<unsigned long>;//*/
#	endif //_MSC_VER
#endif //JSONT6_INLINE
;

/// Assign from string digits for each component.
void STokenNumberComponents::
assign( const char* integerDigits, bool bIntegerNegated, const char* fractionPartDigits,
	   const char* exponentDigits, bool bExponentNegated )
{
	JSONT6_UINT64 tmp = si_atoU64( integerDigits );
	nInteger = tmp;
//	if(bIntegerNegated){
//		nInteger *= -1;
//	}
	strIntegerDigits = integerDigits;
	//
	bNegated = bIntegerNegated;
	//
	std::string strFracDigitsL = si_trim_stdstring<char>( fractionPartDigits, "0 \r\n\t" );
	uFractionPart = si_atoU64( strFracDigitsL.c_str() );
	strFractionPartDigits = fractionPartDigits;
	//
	uFracPartLeadingZeros = 0;
	size_t i;
	for( i=0; fractionPartDigits[i] && fractionPartDigits[i] != '\0'; i++, uFracPartLeadingZeros++ );
	//
	tmp = si_atoU64( exponentDigits );
	nExponent = tmp;
	if(bExponentNegated){
		nExponent *= -1;
	}
	strExponentDigits = exponentDigits;
}
std::string STokenNumberComponents::
sprint()const
{
	std::string out;

	out = strIntegerDigits + "." + strFractionPartDigits + "E" + strExponentDigits;
	;
	return out;
}

} // end namespace jsni
