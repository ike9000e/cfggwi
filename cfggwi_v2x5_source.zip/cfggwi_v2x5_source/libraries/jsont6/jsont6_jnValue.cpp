
#include "jsont6_jnValue.h"
;

#if !defined(JSONT6_INLINE)
#	include "jsont6_jnValue.inl"
#	ifdef _MSC_VER
		// MSVC specific template iinstatiations.
		template class jnValue<char>;
		template class jnValue<short>;
		template class jnValue<long>;
		template class jnValue<unsigned char>;
		template class jnValue<unsigned short>;
		template class jnValue<unsigned long>;
#	endif //_MSC_VER
#endif //JSONT6_INLINE
