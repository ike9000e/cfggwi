
#ifndef _JSONT6_C_STRING_PIECE_H_
#define _JSONT6_C_STRING_PIECE_H_

#include "jsont6_text.h"
#include <vector>
namespace jsni{

struct SiSSPSplit {
	bool           bInclEmpty;			///< Include empty strings in output.
	int            nLimit;				///< -1 = no limit.
	bool           bCaseInsensitive;	///< Case insensitive string comparision.
	bool           bInclSplitter;
	SiSSPSplit( bool bInclEmpty_=0, int limit_=-1, bool bCaseInsensitive_=0,
			bool bInclSplitter_=0 )
		: bInclEmpty(bInclEmpty_)
		, nLimit(limit_)
		, bCaseInsensitive(bCaseInsensitive_)
		, bInclSplitter(bInclSplitter_)
	{}
	SiSSPSplit& inclSplitter(bool in){ bInclSplitter = in; return *this; }
	SiSSPSplit& limit(bool in) { nLimit = in; return *this; }
	SiSSPSplit& caseInsensitive(bool in) { bCaseInsensitive = in; return *this; }
};
// internal
static const SiSSPSplit SpSplitDflt;

template<class T>
class SiCCharset
{
	std::basic_string<T> chrs;
public:
	SiCCharset( const char* dflt, int ){
		for(; *dflt; dflt++ )
			chrs += (T)*dflt;
	}
	SiCCharset( const T* in ) : chrs(in) {
	}
	const T* charset()const { return chrs.c_str(); }
};

/// Specifies some options for ::calcLineDepthCharacters() method.
template<class T>
struct SiSChTDepth {
	T tabCharacter;		///< Tab character, the \\t.
	T spaceCharacter;	///< Space character, the ' '.
	SiSChTDepth( T tabCharacter_= (T)'\t', T spaceCharacter_ = (T)' ' )
		: tabCharacter(tabCharacter_)
		, spaceCharacter(spaceCharacter_)
	{}
};

/// Some options for CStringPiece::replace() method.
struct SiSStrReplace {
	int            limit;				///< -1 = no limit.
	bool           bCaseInsensitive;	///< Case insensitive string comparision.
	SiSStrReplace( int limit_=-1, bool bCaseInsensitive_=0 )
		: limit(limit_)
		, bCaseInsensitive(bCaseInsensitive_)
	{}
};

/// Interface for string replace_ callbacks.
template<class T>
class SiIStrReplCalb {
public:
	virtual void operator() ( const T* szz, size_t sizee ) {}
};
template<class T>	//old SStrReplaceExt
struct SiSStrReplaceExt : public SiSStrReplace {
	SiIStrReplCalb<T>*  eachString;
	SiSStrReplaceExt()
		: eachString(&isrStatic)
	{}
private:
	SiIStrReplCalb<T> isrStatic;//static
};

template<class T>
class SiIStrReplCalbOutString : public SiIStrReplCalb<T>
{
public:
	std::basic_string<T>* strOut;
	virtual void operator() ( const T* szz, size_t sizee ){
		strOut->append( szz, sizee );
	}
};

// forward declaration
template<class T> class SiCStringPiece;

template<class T>
class SiIStrReplCalbStrPceList : public SiIStrReplCalb<T>
{
public:
	std::vector<SiCStringPiece<T> >* Out;
	virtual void operator() ( const T* szz, size_t sizee )
	{
		//strOut->append( szz, sizee );
		Out->push_back( SiCStringPiece<T>(szz,sizee) );
	}
};

/// Specifies options for lines depth reduction.
template<class T>
struct SReduceLnDpth : public SiSChTDepth<T>
{
	int       nSpcsPerTab;		///< Number of spaces per tab character.
	std::basic_string<T> strNlSplitter;	///< New line splitter. Sequence that splits string into lines.
	int       nFirstLins;		///< Limit number of lines from start, -1 is ignore, 0 is only first line.
	int       maxReduce;		///< Maximum indent depth to reduce, -1 is ignore.
	std::basic_string<T> strEmptyLnChars;	///< Trimable characters when testing if line is empty.
	bool      bTrailingSpcsAsTab;	///< If set, spaces that follow last tab indent are treated as single tab indent.
	bool      bInclEmptyLines;
	//
	SReduceLnDpth( int nSpcsPerTab_=4, int maxReduce_=-1, bool bTrailingSpcsAsTab_=0 )
		: nSpcsPerTab(nSpcsPerTab_)
		, maxReduce(maxReduce_)
		, bTrailingSpcsAsTab(bTrailingSpcsAsTab_)
		, nFirstLins(-1)
		, bInclEmptyLines(1)
	{
		char* a = "\r\n\t ";
		for(; *a; ++a )
			strEmptyLnChars += (T)*a;
		char* b = "\n";
		for(; *b; ++b )
			strNlSplitter += (T)*b;
	}
/*	SReduceLnDpth<T>& indents( T tabCharacter_, T spaceCharacter_ )
	{
		tabCharacter = tabCharacter_;
		spaceCharacter = spaceCharacter_;
		return *this;
	}//*/
	SReduceLnDpth<T>& nlSplitter( const T* in ) { strNlSplitter = in; return *this; }
	SReduceLnDpth<T>& lines( int in ) { nFirstLins = in; return *this; }
	SReduceLnDpth<T>& inclEmpty( bool empty_ ) { bInclEmptyLines = empty_; return *this; }
	SReduceLnDpth<T>& skipEmpty() { bInclEmptyLines = 0; return *this; }
};
template<class T>
struct SiSGetEscapedSubString {
	bool bCaseInsensitive;
	bool bInclTerminator;		///< set to true to include terminator in result.
	bool bInclNeTerminator;		///< set to true to include no-escape terminator in result.
	std::basic_string<T>* escaped;			///< Optional. Output, escaped string will be stored here.
	/// Optional. If terminated by terminator (not by end of string piece) pointer
	/// to terminator character is stored here. Stored value is a pointer to character
	/// inside one of terminators string.
	const T** terminatedby;
	SiSGetEscapedSubString( bool bCaseInsensitive_=0, bool bInclTerminator_=0,
		bool bInclNeTerminator_=0, std::basic_string<T>* escaped_=0, const T** terminatedby_=0 )
		: bCaseInsensitive(bCaseInsensitive_)
		, bInclTerminator(bInclTerminator_)
		, bInclNeTerminator(bInclNeTerminator_)
		, escaped(escaped_)
		, terminatedby(terminatedby_)
	{}
};






template<class T>
class SiCStringPiece
{
public:
	// typedefs
	typedef std::vector<SiCStringPiece<T> > LsStrPiece;	//old LsStringPiece

	// constructors
	SiCStringPiece(){
		assign( 0 );
	}
	SiCStringPiece( const T* sz, long size_ = -1 ){
		assign( sz, size_ );
	}
	SiCStringPiece( const T* begin, const T* end_, int ){
		assign( begin, end_, -1 );
	}
	SiCStringPiece( const std::basic_string<T>& in ){
		assign( in );
	}
	SiCStringPiece( const SiCStringPiece<T>& other, long size_ = -1 ){
		assign( other, size_ );
	}
	// assign-s
	SiCStringPiece<T>& assign( const T* in, long size_ = -1 ){
		if( in == 0 ){
			sz  = 0; siz = 0;
		}else{
			sz = in;
			if( size_ < 0 ){
				siz = (long)si_strlen( in );
			}else{
				siz = size_;
			}
		}
		return *this;
	}
	SiCStringPiece<T>& assign( const T* begin, const T* end_, int ){
		return assign( begin, (long)( end_ - begin ) );
	}
	SiCStringPiece<T>& assign( const SiCStringPiece<T>& other, long size_ = -1 ){
		sz = other.sz;
		siz = other.siz;
		if( size_ != -1 )
			siz = size_;
		return *this;
	}
	SiCStringPiece<T>& assign( const std::basic_string<T>& in ){
		sz = in.c_str();
		siz = (long)in.size();
		return *this;
	}
	void operator=( const T* other ){
		assign( other );
	}
	void operator=( const SiCStringPiece<T>& other ){
		assign( other );
	}
	const T* c_str()const {
		if(sz){
			strTmp.assign( sz, siz );
		}else{
			strTmp.clear();
		}
		return strTmp.c_str();
	}//*/
/*	operator std::basic_string<T>()const{
		return std::basic_string<T>( sz, siz );
	}//*/
	const T* pointer()const { return sz; }
	const T* begin()const { return pointer(); }
	const T* end()const { return sz + siz; }
	size_t   size()const { return siz; }
	bool     empty()const { return !sz || !*sz || !siz; }
	void     clear() { assign( 0 ); }

	/// Converts to std string and returns.
	/// Do not use if template parameter is any non primitive class,
	/// it will compile only if template parameter is i.e. char, int, wchar_t, etc.
	std::basic_string<T> toStdString()const { return std::basic_string<T>( sz, siz ); }

	SiCStringPiece<T>& leftSideMove( long amount ){
		sz += amount;
		siz -= amount;
		return *this;
	}
	SiCStringPiece<T>& rightSideMove( long amount ){
		siz += amount;
		return *this;
	}
	bool equal( const T* str, long len=-1, bool bCaseInsensitive=0 )const{
		if( len == -1 )
			len = si_strlen( str );
		if( siz == len )
			if( !si_stroptcmp( str, sz, siz, bCaseInsensitive ) )
				return 1;
		return 0;
	}
	bool matchHead( const T* str, long num=-1, bool bCaseInsensitive=0 )const {
		if( num < 0 )
			num = si_strlen( str );
		if( num <= siz ){
			num = si_min<long>( siz, num );
			return !si_stroptcmp( sz, str, num, bCaseInsensitive );
		}
		return 0;
	}
	const T* matchHead( const T*const* in, bool bCaseInsensitive=0 )const{
		long i;
		for( i=0; in[i]; i++ )
			if( matchHead( in[i], -1, bCaseInsensitive ) )
				return in[i];
		return 0;
	}
/*	const T& charAt( int idx )const {
		if( idx < siz )
			return sz[idx];
		strTmp.assign( (T*)0, (int)0, 77 );
		return strTmp[0];
	}//*/
	T charAt( int idx )const {
		if( idx < siz )
			return sz[idx];
		T tmp;
		tmp = 0;
		return tmp;
	}

	const T& operator[]( size_t idx )const{
		return charAt( idx );
	}
	const T& operator*()const{
		return charAt( 0 );
	}
	// Merges string pieces. Works only if they refer to same string continuous in memory.
	SiCStringPiece<T>& merge( const SiCStringPiece<T>& other ){
		sz = si_min( sz, other.sz );
		const T* end1 = sz + siz;
		const T* end2 = other.sz + other.siz;
		end1 = si_max( end1, end2 );
		siz = end1 - sz;
		return *this;
	}
	void split( const SiCStringPiece<T>& separator, LsStrPiece& out,
		const SiSSPSplit& opt = SpSplitDflt )const
	{
		SiCStringPiece<T>::split( *this, separator, out, opt );
	}
	LsStrPiece split( const SiCStringPiece<T>& separator,
		const SiSSPSplit& opt = SpSplitDflt )const
	{
		LsStrPiece out;
		split( separator, out, opt );
		return out;
	}
	static std::basic_string<T> sprintList( const LsStrPiece& in ){
		std::basic_string<T> out;
		typename LsStrPiece::const_iterator a;
		for( a = in.begin(); a != in.end(); ++a )
			out += a->toStd();
		return out;
	}
/*
	Left trims current string piece.
	First parameter 'charset' is a class that will adopt string pointer through
	constructor parameter.
	Example:
		wprintf( L"spw.trim(), %s\n",
			SiCStringPiece<wchar_t>(L"abcdefw").trim(L"awf").c_str() );
*/
	SiCStringPiece<T>& ltrim( const SiCCharset<T>& charset=SiCCharset<T>(" \r\n\t",-9), int limit=-1 ){
		for(; siz && si_strchr( charset.charset(), *sz ) && limit; siz--, sz++, limit-- );
		return *this;
	}
	SiCStringPiece<T>& rtrim( const SiCCharset<T>& charset=SiCCharset<T>(" \r\n\t",-9), int limit=-1 ){
		const T* bk = end();
		bk--;
		for(; bk >= sz && si_strchr( charset.charset(), *bk ) && limit; siz--, bk--, limit-- );
		return *this;
	}
	SiCStringPiece<T>& trim( const SiCCharset<T>& charset=SiCCharset<T>(" \r\n\t",-9), int limit=-1 ){
		return ltrim(charset.charset(),limit).rtrim(charset.charset(),limit);
	}
	// Counts starting characters that are in set specified by 'charset' parameter.
	// Stops on first character that isn't in set.
	size_t countHeadCharacters( const T* charset )const{
		size_t i;
		for( i=0; i<siz && si_strchr( charset, (*this)[i] ); i++ );
		return i;
	}
	size_t countTailCharacters( const T* charset )const{
		if( empty() )
			return 0;
		size_t i;
		const T* back = sz + siz - 1;
		for( i=0; back >= sz && si_strchr( charset, *back ); back--, i++ );
		return i;
	}

	/**
		Returns line depth and line depth in characters given num spaces per tab character
		and optional maximum depth in tab characters.
		\param nSpcsPerTab - Number of spaces per tab character. Ie. windows notepad
		        as well windows console have it set to 8, most IDEs 4.
		\param chrDepthOut - Output character depth.
		\param depthMax    - Maximum tab depth to stop counting characters at.
			    Set to -1 to ignore.
		\param bTrailingSpcsAsTab - If true, trailing space characters with number less than
			   nSpcsPerTab will account into single tab.
		\param sctd        - Optional structure that may specify different tab and
		       space characters.
		\return Line depth in tab characters. If depthMax specified, less or equal depthMax.

		This method may be used to obtain number of characters at specified tab depth.
		This can be done by comparing return value against input depthMax value.
		If they equal, chrDepthOut contains
		desired nunmber of characters. If return value is less, it means line isn't "deep"
		enough, though, prior check, it should have been verified if it is.
	*/

	int calcLineDepthCharacters( int nSpcsPerTab, int& chrDepthOut, int depthMax=-1,
		bool bTrailingSpcsAsTab=0, const SiSChTDepth<T>& sctd = SiSChTDepth<T>() )const
	{
		chrDepthOut = 0;
		SiCStringPiece<T> sp = *this;
		int trailingSpcs = 0, spcs, depthOut = 0;
		T ch;
		for(; !sp.empty() && depthOut < depthMax || depthMax==-1; sp.leftSideMove(1) ){
			ch = sp.charAt(0);
			if(0){
			}else if( ch == sctd.spaceCharacter ){
				spcs         = trailingSpcs + 1;
				depthOut    += spcs / nSpcsPerTab;
				trailingSpcs = spcs % nSpcsPerTab;
			}else if( ch == sctd.tabCharacter ){
				depthOut    += 1;
				trailingSpcs = 0;
			}else
				break;
		}
		chrDepthOut = sp.pointer() - this->pointer();
		if(bTrailingSpcsAsTab){
			depthOut += !!trailingSpcs;
		}else{
			chrDepthOut -= trailingSpcs;
		}
		return depthOut;
	}

	/// Generic search-replace method.
	/// Note that because CStringPiece class has many constructor versions,
	/// regular strings may be used as corresponding parameters.
	std::basic_string<T> replace( const SiCStringPiece<T>& search,
		const SiCStringPiece<T>& replacement = SiCStringPiece<T>(0),
		const SiSStrReplace& cfg = SiSStrReplace() )const
	{
		std::basic_string<T> out;
		SiIStrReplCalbOutString<T> cb;
		cb.strOut = &out;
		SiSStrReplaceExt<T> sr;
		*static_cast<SiSStrReplace*>(&sr) = cfg;
		sr.eachString = &cb;
		SiCStringPiece<T> arSearch[] = {
			search,
		};
		SiCStringPiece<T> arReplacement[] = {
			replacement,
		};
		replace_priv2( arSearch, sizeof(arSearch)/sizeof(arSearch[0]),
			arReplacement, sizeof(arReplacement)/sizeof(arReplacement[0]), sr );
		return out;
	}
	void replace( const SiCStringPiece<T>& search, const SiCStringPiece<T>& replacement,
		LsStrPiece& out, const SiSStrReplace& cfg = SiSStrReplace() )const
	{
		SiIStrReplCalbStrPceList<T> ir;
		ir.Out = &out;
		SiSStrReplaceExt<T> sr;
		*static_cast<SiSStrReplace*>(&sr) = cfg;
		sr.eachString = &ir;

		SiCStringPiece<T> arSearch[] = {
			search,
		};
		SiCStringPiece<T> arReplacement[] = {
			replacement,
		};
		replace_priv2( arSearch, sizeof(arSearch)/sizeof(arSearch[0]),
			arReplacement, sizeof(arReplacement)/sizeof(arReplacement[0]), sr );

	}

	/// Search-replace using array of string pointers.
	/// \param search - Array of strings to search for, must be terminated by
	///         null pointer element.
	/// \param replace - Array of strings for replacement, must be terminated
	///         by null pointer element.
	///
	/// If index of search string doesnt exist in replacement, search is replaced by last
	/// replacement element in array.
	/// If replacement array is empty (size = 0) each element gets replaced
	/// by empty string, aka. all found elements are removed.
	std::basic_string<T> replace( const T* const* search, const T* const* replace,
		const SiSStrReplace& cfg = SiSStrReplace() )const
	{
		std::basic_string<T> out;
		SiIStrReplCalbOutString<T> cb;	//.
		cb.strOut = &out;
		SiSStrReplaceExt<T> sr;
		*static_cast<SiSStrReplace*>(&sr) = cfg;
		sr.eachString = &cb;
		LsStrPiece lsSearch, lsRepl;
		int i;
		for( i=0; search[i]; i++ )
			lsSearch.push_back( search[i] );
		for( i=0; replace && replace[i]; i++ )
			lsRepl.push_back( replace[i] );
		replace_priv2( &lsSearch[0], lsSearch.size(), &lsRepl[0], lsRepl.size(), sr );
		return out;

	}
	std::basic_string<T> replace( const SiCStringPiece<T> search2[], int len_s,
		const SiCStringPiece<T> replacement2[], int len_r,
		const SiSStrReplace& cfg = SiSStrReplace() )const
	{
		;
		std::basic_string<T> out;
		SiIStrReplCalbOutString<T> cb;
		cb.strOut = &out;
		SiSStrReplaceExt<T> sr;
		*static_cast<SiSStrReplace*>(&sr) = cfg;
		sr.eachString = &cb;
		//
		replace_priv2( search2, len_s, replacement2, len_r, sr );
		return out;

	}
	std::basic_string<T> replace_ch( const T* charsetSrch, const T* charsetRepl,
		const SiSStrReplace& cfg = SiSStrReplace() )const
	{
		LsStrPiece lsSearch, lsRepl;
		for(; *charsetSrch; charsetSrch++ ){
			T ch = *charsetSrch;
			lsSearch.push_back( SiCStringPiece<T>( charsetSrch, 1 ) );
		}
		for(; charsetRepl && *charsetRepl; charsetRepl++ ){
			lsRepl.push_back( SiCStringPiece<T>( charsetRepl, 1 ) );
		}
		return replace( &lsSearch[0], lsSearch.size(), &lsRepl[0], lsRepl.size(), cfg );
	}
	const T* find( const T* search, long size_=-1, bool bCaseInsensitive=0 )const
	{
		if( size_ == -1 )
			size_ = si_strlen( search );
		return si_strstrnn( sz, siz, search, size_, bCaseInsensitive );
	}
	long strpos( const T* search, long size_=-1, bool bCaseInsensitive=0 )const{
		const T* szPos = find( search, size_, bCaseInsensitive );
		if( szPos )
			return szPos - sz;
		return -1;
	}
	SiCStringPiece<T>& truncate( long max_size, long* truncated=0 ){
		if(truncated)*truncated = 0;
		if( siz > max_size ){
			if(truncated)
				*truncated = siz - max_size;
			siz = max_size;
		}
		return *this;
	}
	void reduceLinesDepth( LsStrPiece& out,
		const SReduceLnDpth<T>& cfg = SReduceLnDpth<T>() )const
	{
		SiCStringPiece<T> sp = *this;

		SiSSPSplit sspl;
		sspl.nLimit      = cfg.nFirstLins;
		sspl.bInclEmpty = 1;
		sspl.bCaseInsensitive = 0;
		sspl.bInclSplitter = 1;
		sp.split( cfg.strNlSplitter.c_str(), out, sspl );

		// calculate min line depth.
		int minLnDepth = cfg.maxReduce; //-1;
		{
			int dpt, notused;
			typename LsStrPiece::iterator a;
			for( a = out.begin(); a != out.end(); ){
				if( !SiCStringPiece<T>(*a).trim( cfg.strEmptyLnChars.c_str() ).empty() ){
					dpt = a->calcLineDepthCharacters( cfg.nSpcsPerTab, notused, -1, cfg.bTrailingSpcsAsTab, cfg );
					if( minLnDepth != -1 )
						minLnDepth = si_min( dpt, minLnDepth );
					else
						minLnDepth = dpt;
					++a;
				}else if( !cfg.bInclEmptyLines ){
					a = out.erase( a );
				}else
					++a;
			}
		}
		// left trim line indents by minimal depth value.
		if( minLnDepth != -1 ){
			typename LsStrPiece::iterator a;
			for( a = out.begin(); a != out.end(); ++a ){
				int chrDpth = 0;
				if( minLnDepth == a->calcLineDepthCharacters( cfg.nSpcsPerTab,
						chrDpth, minLnDepth, cfg.bTrailingSpcsAsTab, cfg ) )
				{
					a->leftSideMove( chrDpth );
				}
			}
		}

	}
	std::basic_string<T> reduceLinesDepth( const SReduceLnDpth<T>& cfg = SReduceLnDpth<T>() )const
	{
		LsStrPiece lines;
		reduceLinesDepth( lines, cfg );
		return sprintList( lines );
	}
	/**
		Extracts string until terminator character or end of string.
		Takes escape characters into account.
		\param escapes - Escape characters as null-terminated array.
		\param terms - Terminator characters...
		\param terms_ne - Terminator characters that cannot be escaped by escape character.
		\param opt - Additional options structure.
		\return - Returns position where extracting stopped. Either before or after terminator, see options structure.
	*/
	size_t getEscapedSubString( const SiCStringPiece<T>& escapes,
		const SiCStringPiece<T>& terms, const SiCStringPiece<T>& terms_ne,
		const SiSGetEscapedSubString<T>& opt = SiSGetEscapedSubString<T>() )const
	{
		SiCStringPiece<T> sp = *this;
		T ch;
		bool bEscaped = 0;
		std::basic_string<T>* out = opt.escaped;
		const T* ptr;

		for(; !sp.empty(); ){
			ch = sp[0];
			if( !bEscaped && !!escapes.find( &ch,1,opt.bCaseInsensitive ) ){
				sp.leftSideMove(1);
				bEscaped = 1;
				continue;
			}
			if( !bEscaped && !!(ptr = terms.find( &ch,1,opt.bCaseInsensitive )) ){
				if( opt.bInclTerminator ){
					sp.leftSideMove(1);
					if(out)
						*out += ch;
				}
				if(opt.terminatedby)
					*opt.terminatedby = ptr;
				break;
			}
			if( !!(ptr = terms_ne.find( &ch,1,opt.bCaseInsensitive )) ){
				if( opt.bInclNeTerminator ){
					sp.leftSideMove(1);
					if(out)
						*out += ch;
				}
				if(opt.terminatedby)
					*opt.terminatedby = ptr;
				break;
			}
			if(out)
				*out += ch;
			bEscaped = 0;
			sp.leftSideMove(1);
		}
		return sp.pointer() - this->pointer();
	}
	/// Indents all lines with given string.
	std::basic_string<T> indent( const T* indentWith )const
	{
		SiCStringPiece<T> sp( *this );
		return std::basic_string<T>(indentWith) +
			sp.replace( si_anyStr<T>("\n").c_str(),
				std::basic_string<T>( si_anyStr<T>("\n") + indentWith ).c_str() );
	}
	std::basic_string<T> padd( size_t padd_size, const T* paddWith = si_anyStr<T>(" ").c_str() )const
	{
		std::basic_string<T> str = *this;
		size_t len = si_strlen(paddWith), padd_now;
		for(; padd_size; ){
			if( padd_size > len ){
				padd_now = len;
				padd_size -= len;
			}else{
				padd_now = padd_size;
				padd_size = 0;
			}
			str.append( paddWith, padd_now );
		}
		return str;
	}
	static std::string strNoSpecialChars( const char* in ){
		std::string out;
		for(; *in; in++ ){
			if(0){
			}else if( *in == '\n' ){
				out += "\\n";
			}else if( *in == '\r' ){
				out += "\\r";
			}else if( *in == '\b' ){
				out += "\\b";
			}else{
				out += *in;
			}
		}
		return out;
	}
private:
	static void split( const SiCStringPiece<T>& subject, const SiCStringPiece<T>& separ,
		LsStrPiece& out, const SiSSPSplit& opt = SpSplitDflt )
	{
		int limit = opt.nLimit;
		int length = subject.size();
		SiCStringPiece<T> sp;
		const T* sbj = subject.pointer();
		const T* bgn = sbj;
		while( length && length >= (int) separ.size() ){
			if( !si_stroptcmp( sbj, separ.pointer(), separ.size(), opt.bCaseInsensitive ) ){
				if( !limit )
					break;
				sp.assign( bgn, sbj, (int)0 );
				if(opt.bInclSplitter)
					sp.rightSideMove( separ.size() );
				if( (opt.bInclEmpty || !sp.empty()) ){
					limit--;
					out.push_back( sp );
				}
				sbj    += separ.size();
				length -= separ.size();
				bgn     = sbj;
				continue;
			}
			sbj++;
			length--;
		}
		if( limit ){
			sp.assign( bgn, subject.end(), (int)0 );
			if( (opt.bInclEmpty || !sp.empty())/*&&(!opt.fnEachPiece || opt.fnEachPiece( sp ))*/ )
				out.push_back( sp );
		}
	}
	void replace_priv2( const SiCStringPiece<T> search2[], int len_s,
		const SiCStringPiece<T> replacement2[], int len_r,
		const SiSStrReplaceExt<T>& cfg = SiSStrReplaceExt<T>() )const
	{
		const T emptystr[] = { 0, };
		int limit = cfg.limit, i, cFnd;
		SiCStringPiece<T> sp = *this;
		const T* bgn = sp.pointer();
		for(; !sp.empty() && limit; ){
			bool found = 0;
			int cTestL = 0;
			for( i=0, cFnd=0; i<len_s; i++ ){	//for each search_ elem.
				const SiCStringPiece<T>& sr = search2[i];
				if( sp.size() >= sr.size() ){
					cTestL++;
					if( !si_stroptcmp( sp.pointer(), sr.pointer(), (long)sr.size(), cfg.bCaseInsensitive ) ){
						cFnd++;
						(*cfg.eachString)( bgn, sp.pointer() - bgn );
						int r;
						if( i<len_r ){
							r = i;
						}else{
							r = len_r - 1;
						}
						const T* ptr = 0; int len = 0;
						if( r >= 0 ){
							ptr = replacement2[r].pointer();
							len = (long)replacement2[r].size();
						}else{
							ptr = emptystr;
							len = 0;
						}
						(*cfg.eachString)( ptr, len );

						sp.leftSideMove( (long)sr.size() );
						bgn = sp.pointer();
						limit--;
						found = 1;
						break;
					}
				}
				if( found )
					break;
			}
			if( !cTestL )			//if nothing tested due to size.
				break;
			if( !found )
				sp.leftSideMove(1);
		}
		(*cfg.eachString)( bgn, sp.end() - bgn );
	}
private:
	const T*  sz;
	long      siz;
	mutable std::basic_string<T> strTmp;
};

} // end namespace jsni

#endif //_JSONT6_C_STRING_PIECE_H_
