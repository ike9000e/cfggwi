
#ifndef _JSONT6_C_TOKENIZER_H_
#define _JSONT6_C_TOKENIZER_H_
#include <stdio.h>
#include "jsont6_routines.h"
#include "jsont6_CToken.h"
#include "jsont6_CDataPiece.h"
namespace jsni{
;

template<class T> struct STokenizerError;
template<class T> struct STokenizer;

/// Base class for creating custom converter from unicode sequence to numeric value.
/// Already provides default conversion method and is used by default by the library.
class IUnicodeSequenceConversion
{
public:
	///	Converts unicode sequence, the 4 ASCII digits, provided as multibyte character
	/// array, into one character of type T.
	///	Characters in input array are in the same order as they were typed in original
	///	unicode sequence.
	///	\code
	///		unicode sequence example:
	///		\u004A.
	///     in this example, parameter 'in4digits' would point to string: "004A".
	///     NOTE: not terminated by null character.
	///	\endcode
	virtual int convertFromAscii4Digit( const char* in4digits )const{
		std::string str( in4digits, 4 );
		JSONT6_UINT64 uu = si_atoU64( str.c_str(), 16 );
		int out = (int) (size_t) uu;
		return out;
	}
};

template<class T>
class CTokenizer
{
	/// \todo Set upper limit on exponent size.
	/// \todo Optional "0x" hexadecimal numbers.
	struct SRepl {
		char c;
		char repl;
	};
	typedef std::vector<CToken<T> > LsToken3;
#ifndef JSONT6_INLINE
public:
	CTokenizer( const STokenizer<T>& in );
	~CTokenizer();
	bool processString( const CDataPiece<T>& sp, typename CToken<T>::LsToken& out );
	const STokenizerError<T>& error()const;
private:
	//--> 2. JSON Grammar, called: "structural characters"
	bool tryOperatorMatch( const CDataPiece<T>& sp, CToken<T>& match );
	//--> 2.1. Values, "false null true"
	bool tryLiteralMatch( const CDataPiece<T>& sp, CToken<T>& match );
	//whitespaces --> 2. JSON Grammar
	bool tryWhitespacesMatch( const CDataPiece<T>& sp, CToken<T>& match );
	//string --> 2.5. Strings
	bool tryStringMatch( const CDataPiece<T>& sp, CToken<T>& match, const T** end, STokenizerError<T>& error );
	//comment [extesnion]
	bool tryCommentMatch( const CDataPiece<T>& sp, CToken<T>& match, STokenizerError<T>& error );
	//number --> 2.4. Numbers
	//--> file://.../Json_T6_library/docs/JSON.org%20home.mht --> figure: "number"
	bool tryNumberMatch( const CDataPiece<T>& sp, CToken<T>& match, STokenizerError<T>& error );
	// extesnion for unquoted variable names.
	bool tryWordMatch( const CDataPiece<T>& sp, CToken<T>& match );

	bool extractEscapedSubstring( const CDataPiece<T>& sp, char chQtMode, const T** end, std::vector<T>& outStr, STokenizerError<T>& error )const;
	bool extractUnicode4DigitSeqAfterUChar( const CDataPiece<T>& sp, const T** end, std::string& outStr, STokenizerError<T>& error )const;
	virtual bool isASCIIVarnameStartCharacter( const T& in, char* outAscii )const;
	virtual bool isASCIIVarnameContinueCharacter( const T& in, char* outAscii )const;
	virtual bool isWhitespaceCharacter( const T& in )const;
	virtual bool isAsciiNonzeroDigitCharacter( const T& c, char* asciicharacter )const;
	virtual bool isAsciiAnyDigitCharacter( const T& c, char* asciicharacter )const;
	virtual bool isAsciiHexadecDigitCharacter( const T& c, char* asciicharacter )const;
	bool findEscReplacement( const T& in, const SRepl* repls, T& repl )const;

#else //JSONT6_INLINE
#	include "jsont6_CTokenizer.inl"
#endif //JSONT6_INLINE
private:
	STokenizerError<T>* Error;
	STokenizer<T>       In;
};

/// Tokenization result.
template<class T>
struct STokenizerError {
	bool            error;
	ETokenizerError code;
	std::string     message;
	CDataPiece<T> sp;
	STokenizerError() : error(0), code(ETKE_NONE) {}
	bool failure()const { return error != ETKE_NONE; }
};

template<class T>
struct STokenizer {
	size_t             uFeatureFlsgs;	///< one or more Feature Flags flags, eg. jnETKF_SingleQuote.
	IUnicodeSequenceConversion* lpUCSeqConv;
	STokenizer(
			size_t uFeatureFlsgs_,
			IUnicodeSequenceConversion* lpUCSeqConv_
			)
		: uFeatureFlsgs(uFeatureFlsgs_)
		, lpUCSeqConv(lpUCSeqConv_)
	{}
};



} // end namespace jsni

#endif //_JSONT6_C_TOKENIZER_H_
