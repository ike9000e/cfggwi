
#ifndef _XEHI_KBD_EVENT_GEN_H_
#define _XEHI_KBD_EVENT_GEN_H_

#include <stdio.h>
#include <vector>
#include <X11/Xlib.h>
#include <X11/Xutil.h>

// Sending fake keypress events to an X11 window
// http://www.doctort.org/adam/nerd-notes/x11-fake-keypress-event.html

bool xehi_SendUpDownKeyEvent( Display* display, Window winRoot, Window winFocus, size_t uKeyCode );
XKeyEvent xehi_CreateKeyEvent( Display *display, Window &winRoot, Window &winTarget, bool press, size_t keycode, size_t modifiers );
bool xehi_SendKeyEvent( Display* display, Window& winRoot, Window& winTarget, bool bPress, size_t keycode, size_t modifiers );

#endif //_XEHI_KBD_EVENT_GEN_H_
