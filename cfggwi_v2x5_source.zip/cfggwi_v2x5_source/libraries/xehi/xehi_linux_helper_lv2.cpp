
#include "xehi_linux_helper_lv2.h"
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <X11/cursorfont.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <limits.h>
#include <unistd.h>   //getuid()
#include <pwd.h>      //getpwuid()
#include "hef/hef_str.h"
#include "hef/hef_str_args.h"
#include "hef/hef_file.h"

/// \cond DOXYGEN_SKIP //{
;
struct S_53827 {
	const char* sz8;//, *sz9;
	int enumval;
}arLXDEClrNames2[] = {
	{"fg_color",          XEHILXCT_WndFgClr, },
	{"bg_color",          XEHILXCT_WndBgClr, },
	{"text_color",        XEHILXCT_TextFgClr, },
	{"base_color",        XEHILXCT_TextBgClr, },
	{"selected_fg_color", XEHILXCT_SelectFgClr, },
	{"selected_bg_color", XEHILXCT_SelectBgClr, },
	{"tooltip_fg_color",  XEHILXCT_TooltipFgClr, },
	{"tooltip_bg_color",  XEHILXCT_TooltipBgClr, },
};
struct SXehiLXClrName{
	std::string first, second;
	int enumval2;
};
/// \endcond //DOXYGEN_SKIP //}
;
/// Uses HOME dir and retrieves theme colors for Lubuntu, keept by LXApperance
/// and used by other LXDE programs.
/// related to EMODE_GetLXDELubuntuThemeColors enum.
/// \param outp - it's second member contains string with 3 comma separated,
///               RGB 0-255, values. use sscanf() to convert into ints.
///               returned size is XEHILXCT_NumColors-long and
///               index vales match enums: XEHILXCT_WndFgClr, XEHILXCT_WndBgClr, etc.
/// \param flags2 - not used.
bool xehi_GetLXDELubuntuThemeColors( std::vector<std::pair<std::string,std::string> >& outp, int flags2 )
{
	std::string strThemeFn, str;
	const char* szConfFName = ".config/lxsession/Lubuntu/desktop.conf";

	//outp2.resize( XEHILXCT_NumColors, "" );
	outp.resize( XEHILXCT_NumColors );
	std::string homedir = hf_getHomeDir();
	if( !homedir.empty() ){
		strThemeFn = HfArgs("%1/%2").arg(homedir.c_str()).arg(szConfFName).c_str();
		if( !hf_FileExists( strThemeFn.c_str() ) )
			strThemeFn.clear();
	}
	if( !strThemeFn.empty() ){
		// complete line example:
		// sGtk/ColorScheme=tooltip_fg_color:#000\nbase_color:#ededededd1d1\nselected_fg_color:#000000000000\ntext_color:#000\nbg_color:#e20bdd31bef7\ntooltip_bg_color:#faa3ffff975a\nselected_bg_color:#6758d0b5bd62\nfg_color:#000\n
		//
		// tooltip_fg_color:#000
		// base_color:#ededededd1d1  //  Text Windows
		// selected_fg_color:#000000000000
		// text_color:#000
		// bg_color:#e20bdd31bef7
		// tooltip_bg_color:#faa3ffff975a
		// selected_bg_color:#6758d0b5bd62
		// fg_color:#000
		//

		std::vector<SXehiLXClrName>::const_iterator a;
		std::vector<SXehiLXClrName> arClrValues;
		const char* szMagicLineTag = "sGtk/ColorScheme";
		FILE* fp2 = fopen( strThemeFn.c_str(), "r");
		if(fp2){
			char bfr[1024]; std::string str2; const char* sz3, *sz4, *sz5, *sz6;//, *sz7;
			for( *bfr=0;; *bfr=0 ){
				if( !fgets( bfr, sizeof(bfr), fp2 ) )
					break;
				str = hf_trim_stdstring<char>( bfr, "\r\n\x20\t" );
				if( str.substr(0,hf_strlen(szMagicLineTag)) == szMagicLineTag ){
					int i, num = sizeof(arLXDEClrNames2)/sizeof(arLXDEClrNames2[0]);
					for( i=0; i<num; i++ ){
						const S_53827& scx = arLXDEClrNames2[i];
						sz3 = hf_strstr( str.c_str(), scx.sz8 );
						if( sz3 ){
							sz3 = hf_ltrim( sz3 + hf_strlen(scx.sz8), "\x20\t" );
							if( *sz3 == ':' ){
								sz4 = hf_strstr( sz3, "#" );
								sz5 = hf_strpbrk( sz3, "0123456789abcdefABCDEF" );
								sz6 = hf_strpbrk( (sz5?sz5:""), "\\:" );
								if( sz4 && sz4 < sz5 && (sz5 < sz6 || !sz6) ){
									size_t len = strspn( sz5, "0123456789abcdefABCDEF" );
									str2.assign( sz5, len );
									//arClrValues.push_back( std::make_pair(
									//		scx.sz8, str2.c_str() ) );
									SXehiLXClrName scn;
									scn.first    = scx.sz8;
									scn.second   = str2;
									scn.enumval2 = scx.enumval;
									arClrValues.push_back(scn);
								}
							}
						}
					}
					break;
				}
			}
			fclose(fp2);
		}
		if( !arClrValues.empty() ){
			//
			// STDOUT-print colors in integer-RGB / #RRGGBB / rgb(r,g,b) formats.
			// color format from .conf may be 3, 6 or 12 hexadecimal characters.
			//
			for( a = arClrValues.begin(); a != arClrValues.end(); ++a ){
				str = a->second.c_str();
				//str = "050FFF80F";
				//str = "AA80FF";
				int uPieceLen = std::max<int>( 1, str.size() / 3 );
				std::vector<std::string> pcs;
				std::vector<int> rgbs( 3, 0 );
				hf_split( str.c_str(), uPieceLen, pcs );
				pcs.resize( 3, "0" );
				for( int i=0; i < (int)rgbs.size(); i++ ){
					int val = (int) hf_AsciiToU64( pcs[i].c_str(), 16 );
					rgbs[i] =
							( uPieceLen == 1 ? 255 * ( (float)val / ( 15 ) ) :
							( uPieceLen == 2 ? val :
							( uPieceLen == 3 ? 255 * ( (float)val / ( 4095 ) ) :
							( uPieceLen == 4 ? 255 * ( (float)val / ( 65535 ) ) :
									val ) ) ) );
				}
				//outp.push_back( std::pair<std::string,std::string>(
				//		a->first.c_str(),
				//		HfArgs("%1,%2,%3")
				//				.arg((int)rgbs[0])
				//				.arg((int)rgbs[1])
				//				.arg((int)rgbs[2]).c_str() ) );

				//outp2[a->enumval2] = HfArgs("%1,%2,%3")
				//		.arg((int)rgbs[0])
				//		.arg((int)rgbs[1])
				//		.arg((int)rgbs[2]).c_str();

				outp[a->enumval2] = std::pair<std::string,std::string>(
						a->first.c_str(),
						HfArgs("%1,%2,%3")
								.arg((int)rgbs[0])
								.arg((int)rgbs[1])
								.arg((int)rgbs[2]).c_str() );
			}
			return 1;
		}
	}
	return 0;
}
/**
	Loads TGA image|icon into array of ulong-s provided file name.
	First two elements in returned array are set to width and height of the image.

	\sa xehi_SetWindowIcon()
*/
bool xehi_LoadTgaIconAsUlongs( const char* szIconFname, std::vector<unsigned long>& outp, std::string* err2 )
{
	std::string err3, *err = ( err2 ? err2 : &err3 );
	HfSTgaTexture tex;
	memset( &tex, 0, sizeof(tex) );
	bool res2 = hf_LoadUncompressedTGA( &tex, szIconFname, 0, err );
	if( !res2 ){
		//xwim_printf( EV_Vrbst_1,"ERROR: hf_LoadUncompressedTGA() failed.\n");
		//xwim_printf( EV_Vrbst_1,"Message: %s\n", err.c_str() );
		//*err = *err;
		return 0;
	}
	if( tex.bpp != 32 ){
		//xwim_printf( EV_Vrbst_1,"ERROR: suppors only 32-bits-per-pixel (RGBA) TGA images.\n");
		*err = "Suppors only 32-bits-per-pixel (RGBA) TGA images.";
		hf_FreeTGA( &tex );
		return 0;
	}
	outp.push_back( tex.width );
	outp.push_back( tex.height );
	int i, numpx = tex.width * tex.height;
	for( i=0; i<numpx; i++ ){
		unsigned long px2 = *( &( (uint32_t*)tex.imageData )[i] );
		outp.push_back( px2 );
	}
	hf_FreeTGA( &tex );
	return 1;
}
