
#ifndef _XEHI_LINUX_HELPER_LV2_H_
#define _XEHI_LINUX_HELPER_LV2_H_
#include "xehi_linux_helper.h"

enum{
	/// flags for xehi_GetLXDELubuntuThemeColors() output.
	XEHILXCT_WndFgClr, //fg_color
	XEHILXCT_WndBgClr, //bg_color
	XEHILXCT_TextFgClr, //text_color
	XEHILXCT_TextBgClr, //base_color
	XEHILXCT_SelectFgClr,
	XEHILXCT_SelectBgClr,
	XEHILXCT_TooltipFgClr,
	XEHILXCT_TooltipBgClr,
	XEHILXCT_NumColors,
};

bool        xehi_GetLXDELubuntuThemeColors( std::vector<std::pair<std::string,std::string> >& outp, int flags2 );
bool        xehi_LoadTgaIconAsUlongs( const char* szIconFname, std::vector<unsigned long>& outp, std::string* err2 );

#endif //_XEHI_LINUX_HELPER_LV2_H_
