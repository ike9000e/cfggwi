
#ifndef _XEHI_GLOBHOTKEY_H_
#define _XEHI_GLOBHOTKEY_H_

/*
	Global hotkey library for X11 applications.
	Helpers, fe. functions for registering global hotkeys or
	definitions of bad modkeys.

	Example is in xehi_GlobHotkeyMain(). use it as call and return
	value from actual main().
	\code
		int main()
		{
			return xehi_GlobHotkeyMain();
		}
	\endcode

	references:
	* http://www.saschahlusiak.de/linux/audacioushotkey.htm
	* http://stackoverflow.com/questions/4037230/global-hotkey-with-x11-xlib
	* /usr/include/X11/X.h
*/

#include <stdio.h>
#include <vector>
#include <string>
#include <stdint.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>

namespace hef {}
using namespace hef;



/// \cond DOXYGEN_SKIP //{
;
/// Internal structure for keeping common X11 modkeys, its names, keysymcodes, etc.
struct XehiSX11Modkey{
	int keycode;
	int modmask;
	const char* name_a;
	const char* name_b; //not used.
	int keysym;
};
/// \endcond //DOXYGEN_SKIP //}

enum{
	/// flags for xehi_TestKeysDown() function.
	XEHI_TK_LRModKeysNotMerged = 0x1,
	XEHI_TK_ModKeysNonExclusiveOk = 0x2,
};
enum{
	/// Flags for xehi_GetCommonX11ModkeyMasksAndNames().
	/// If set, appends output modkeys list with names without "_L" and "_R".
	XEHI_CM_AddNonLRModkeys = 0x1,
};

size_t   xehi_GetBadModkeys( Display* xdisplay, std::vector<size_t>& modkeys );
bool     xehi_GrabKey( size_t keycode, size_t modifier, const std::vector<size_t>& lsBadModkeys, Display* xdisplay, Window x_root_window );
void     xehi_UngrabAllKeys( Display* xdisplay, Window x_root_window );
bool     xehi_IsGHEvent( const XKeyEvent& evt2, size_t key, size_t modkeys, size_t uBadModks );
int      xehi_GlobHotkeyMain();

bool     xehi_ParseHotkeyTriggerSimple( const char* szTrig, std::vector<int>& keysOu, std::string* err );
void     xehi_GetCommonX11ModkeyMasksAndNames( std::vector<std::pair<uint32_t,std::string> >& outp, uint32_t flags2 );
uint32_t xehi_TestKeysDown( Display* dpy2, const int* arKeys, int numkeys, bool* bAllDown, uint32_t flags3 );
bool     xehi_TestKeysDown2( Display* dpy2, const int* arKeys, int numkeys, uint32_t flags3 );
uint32_t xehi_TestKeysDown3( Display* dpy2, const std::vector<int>& arKeys, bool* bAllDown, uint32_t flags3 );

#endif //_XEHI_GLOBHOTKEY_H_
