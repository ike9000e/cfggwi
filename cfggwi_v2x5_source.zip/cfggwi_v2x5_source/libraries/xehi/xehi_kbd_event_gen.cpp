
#include "xehi_kbd_event_gen.h"

//#define KEYCODE XK_Down

// Function to create a keyboard event
XKeyEvent xehi_CreateKeyEvent( Display* display,
							Window& winRoot, Window& winTarget, bool press,
							size_t keycode, size_t modifiers )
{
	XKeyEvent event;
	event.display     = display;
	event.window      = winTarget;
	event.root        = winRoot;
	event.subwindow   = None;
	event.time        = CurrentTime;
	event.x           = 1;
	event.y           = 1;
	event.x_root      = 1;
	event.y_root      = 1;
	event.same_screen = True;
	event.keycode     = XKeysymToKeycode(display, keycode);
	event.state       = modifiers;
	if(press)
		event.type = KeyPress;
	else
		event.type = KeyRelease;
	return event;
}
bool xehi_SendKeyEvent( Display* display,
							Window& winRoot, Window& winTarget, bool bPress,
							size_t keycode, size_t modifiers )
{
	XKeyEvent evt;
	evt = xehi_CreateKeyEvent( display, winRoot, winTarget, bPress, keycode, modifiers );
	XSendEvent( evt.display, evt.window, 1, KeyPressMask, (XEvent*)&evt );
	return 0;
}

bool xehi_SendUpDownKeyEvent( Display *display, Window winRoot, Window winFocus,
							size_t uKeyCode )
{
	// Send a fake key press event to the window.
	XKeyEvent event = xehi_CreateKeyEvent( display, winRoot, winFocus, true, uKeyCode, 0 );
	XSendEvent( event.display, event.window, 1, KeyPressMask, (XEvent *)&event );

	// Send a fake key release event to the window.
	event = xehi_CreateKeyEvent( display, winRoot, winFocus, false, uKeyCode, 0 );
	XSendEvent( event.display, event.window, 1, KeyPressMask, (XEvent *)&event );

	return 1;
}

int xehi_KbdGenMain()
{
	Display *display = XOpenDisplay(0);
	if( display == NULL )
		return -1;
	Window winRoot = XDefaultRootWindow(display);

	// Find the window which has the current keyboard focus.
	Window winFocus;
	int    revert;
	XGetInputFocus(display, &winFocus, &revert);
	/*
	// Send a fake key press event to the window.
	XKeyEvent event = xehi_CreateKeyEvent_( display, winFocus, winRoot, true, KEYCODE, 0 );
	XSendEvent(event.display, event.window, True, KeyPressMask, (XEvent *)&event);

	// Send a fake key release event to the window.
	event = xehi_CreateKeyEvent_( display, winFocus, winRoot, false, KEYCODE, 0 );
	XSendEvent(event.display, event.window, True, KeyPressMask, (XEvent *)&event);
	//*/
	xehi_SendUpDownKeyEvent( display, winRoot, winFocus, XK_Down );

	// Done.
	XCloseDisplay(display);

	return 0;
}
