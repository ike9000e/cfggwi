
#ifndef _XEHI_CLIPBOARD_CLIENT_H_
#define _XEHI_CLIPBOARD_CLIENT_H_

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>
#include <algorithm>
#include <cstring>
#include <assert.h>
#include <stdint.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xutil.h>
#include <unistd.h>   //usleep()

namespace hef{}
using namespace hef;

/// \cond DOXYGEN_SKIP //[7h2tjIsky]
;
struct xehi_SCBData{
	Time tmClaimedAt;
};

/// Internal data, initialized in xehi_CBClientInit().
typedef struct {
	Display*    dpy4;
	Atom        xaTargets;  //"TARGETS"
	Atom        xaClip;     //"CLIPBOARD"
	Atom        xaWmDelete, xaCbRcv; //"WM_DELETE_WINDOW"
	Window      wndThr;
	pthread_t   idWndThr;  //pthread_create(), pthread_self()
	const char* szWmDeleteWindow, *szWmCBRcv;
	bool        bThrActive;
	int         msPoolItrvl2;
	bool        bAclrtdMsgLoop, bMsglWorking;
	int         verify2, verify3;
	std::vector<uint8_t>* data3;
	uint64_t    uDataRcvdAt;
	char        szOwnerName[64], szUtilWndTitle2[128];
	GC          gc3;
	int         nBytesMax2, nReadd, flags3; //fe. XEHI_CBC_ClipMonitor
	std::vector<Atom>* formatsMain3;
	std::vector<Atom>* formatsAlt3;
	std::vector<Atom>* formatsMain4;
	std::vector<Atom>* formatsAlt4;
	xehi_SCBData cbd;
}xehi_SCBClnt;
extern xehi_SCBClnt XehiCbClnt;

/// \endcond //DOXYGEN_SKIP //[7h2tjIsky]
;
/// Input parameter for xehi_CBClientGetData().
/// All member variables default values provided.
/// Members 'nNumItrns' and 'nNumWorkItrns' are used in
/// conjunction with 'msPoolItrvl' parameter passed prevoiysly to xehi_CBClientInit().
struct xehi_SCBGetData {
	/// set -1 for no limit, max num of bytes to retrieve.
	int nBytesMax;
	/// number of iterations to wait before gave up, while
	/// trying to retrieve the data.
	int nNumItrns;
	/// num of iterations to add to wait after started processing clipboard data.
	/// setting this to value -1 causes unlimited wait.
	int nNumWorkItrns;
	/// optional formats as Atom list, created with XInternAtom().
	/// if null, default formats for text retrieval are used.
	std::vector<Atom>* formatsMain5;
	/// optional alternate formats. used only if 'formatsMain5' are set (not null).
	std::vector<Atom>* formatsAlt5;
	/// Constructor.
	xehi_SCBGetData() : nBytesMax(-1), nNumItrns(16), nNumWorkItrns(64),
			formatsMain5(0), formatsAlt5(0) {}
};
enum {
	/// Clipboard monitor functionality.
	/// Window procedure exits when other window takes clipboard owneship and
	/// the 'SelectionClear' message is recieved.
	/// Expected to be used with XEHI_CBC_NoWndThreadInit flag.
	/// Function xehi_CBClientGetData2() must be used to get received clipboard data back.
	XEHI_CBC_ClipMonitor = 0x1,
	/// If set, remote window thread is not created.
	/// Function xehi_CBClientThreadProc() wont be entered automatically.
	/// Call to xehi_CBClientThreadProc() is expected to be done by user.
	XEHI_CBC_NoWndThreadInit = 0x2,
	/// Hides the helper window.
	XEHI_CBC_WindowHidden = 0x4,
	XEHI_CBC_NoWindowProcCleanup = 0x8,
	/// If set and XEHI_CBC_ClipMonitor flag is used, clipboard data is not retrieved.
	XEHI_CBC_NoCBDataOnExit = 0x10,
};
bool  xehi_CBClientInit( int flags2, int msPoolItrvl = 50000, std::string* err=0, const char* szUtilWndTitle = "xehi_CBClientInit" );
bool  xehi_CBClientDeinit( std::string* err = 0 );
bool  xehi_CBClientGetData( std::vector<uint8_t>* outp2, const xehi_SCBGetData& cfg, std::string* err = 0 );
bool  xehi_CBClientGetData2( std::vector<uint8_t>* outp2, std::string* err );
void* xehi_CBClientThreadProc( void* param3 );
bool  xehi_CBClientMakeClipboardOwned( Display* dpy, Window wid, Time tmstamp );
void  xehi_CBClientWindowCleanup();
//
int   xehi_CBClientFnMainExample_1( int argc, const char*const* argv );
int   xehi_CBClientFnMainExample_2( int argc, const char*const* argv );

#endif //_XEHI_CLIPBOARD_CLIENT_H_
