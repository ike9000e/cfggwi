
#include "xehi_clipboard_client.h"
#include "hef/hef_str.h"
#include "hef/hef_str_piece.h"
#include "hef/hef_str_args.h"
#include "hef/hef_file.h"
#include "hef/hef_data.h"
#include "xehi_linux_helper.h"


//
// references:
// * XGetSelectionOwner()
// * Fl::paste()
// * .../fltk-1.3.2/src/Fl_x.cxx
//

//
// https://bbs.archlinux.org/viewtopic.php?id=85378
// compile and usage example:
// $ gcc -Wall -lX11 xrectsel.c -o xrectsel
// $ ./xrectsel
// 492x538+552+54
//

/// \defgroup GP_cb_client Clipboard client functions.
/// ...
/// xehi_CBClientInit() \n
/// xehi_CBClientDeinit() \n
/// xehi_CBClientGetData() \n

/// \cond DOXYGEN_SKIP //[aPInunBX]
;
bool  xehi_CBClientCreateThread( void*(*calb2)(void*), void* param2, pthread_t* thread3=0 );
bool  xehi_CBClientGetDataOnNotify( const XSelectionEvent& ev2, Display* dpy, bool* bHaveAllData, std::vector<uint8_t>* outp );
void  xehi_CBClientSendClientMessage( Display* dpy2, Window window, Atom message, unsigned long d0, unsigned long d1=0, unsigned long d2=0, unsigned long d3=0, unsigned long d4=0 );
bool  xehi_CBClientCreateWindow();
bool  xehi_CBClientCheckInitDone( std::string* err );
void  xehi_CBClientDummySelectionRequestResponse( Display* dpy, const XSelectionRequestEvent& ev2 );

/// Global data used by 'xehi_CBClient' function family.
/// Has extern in the header file.
xehi_SCBClnt XehiCbClnt;

bool xehi_CBClientCreateThread( void*(*calb2)(void*), void* param2, pthread_t* thread3 )
{
	pthread_t thread4, *thread2 = ( thread3 ? thread3 : &thread4 );
	*thread2 = 0;
	XehiCbClnt.bThrActive = 1;
	XehiCbClnt.idWndThr = 0;
	int iret = pthread_create( thread2, 0, calb2, param2 );
	if( iret ){ // if error
		XehiCbClnt.idWndThr = 0;
		XehiCbClnt.bThrActive = 0;
		printf( "ERROR: pthread_create() failed, return code %d\n", iret );
		return 0;
	}
	XehiCbClnt.idWndThr = *thread2;
	return 1;
}

bool xehi_CBClientCreateWindow()
{
	Window*   wnd = &XehiCbClnt.wndThr;
	Display** dpy = &XehiCbClnt.dpy4;
	int direction, ascent, descent, X, Y, W=0, H;
	int height2 = 0;
	int black2, white2;
	size_t lines = 0;
	XFontStruct* font2;
	XCharStruct overall;
//	XSizeHints hints;

	// Get us a white and black color
	black2 = BlackPixel( *dpy, DefaultScreen(*dpy) );
	white2 = WhitePixel( *dpy, DefaultScreen(*dpy) );

	// Create a window with the specified title.
	*wnd = XCreateSimpleWindow( *dpy, DefaultRootWindow(*dpy), 0, 0, 100, 100,
							 0, white2, white2 );
	xehi_SetWindowPropertyAsLong( *dpy, *wnd, "_NET_WM_PID", getpid() );

	;//_NET_WM_STATE_SKIP_TASKBAR
	//message_type = _NET_WM_STATE
	//xehi_SetWindowTaskbarState( *dpy, *wnd, 0, 0 );

	int wmmask = ( ExposureMask | StructureNotifyMask | SubstructureRedirectMask |
						  KeyReleaseMask | KeyPressMask | PointerMotionMask |
						  ButtonPressMask | ButtonReleaseMask ); // NoEventMask
	XSelectInput( *dpy, *wnd, wmmask );

	if( !(XehiCbClnt.flags3 & XEHI_CBC_WindowHidden) ){
		XMapWindow( *dpy, *wnd );
	}
	XStoreName( *dpy, *wnd, XehiCbClnt.szUtilWndTitle2 );

	XSetWMProtocols( *dpy, *wnd, &XehiCbClnt.xaWmDelete, 1 );

	// Create a graphics context for the window
	XehiCbClnt.gc3 = XCreateGC( *dpy, *wnd, 0, 0 );

	XSetForeground( *dpy, XehiCbClnt.gc3, black2 );
	XSetBackground( *dpy, XehiCbClnt.gc3, white2 );

	// Compute the printed width and height_ of the text_
	if( !(font2 = XQueryFont( *dpy, XGContextFromGC(XehiCbClnt.gc3) )) ){
		//goto cleanup;
		XFreeGC( *dpy, XehiCbClnt.gc3 );
		XDestroyWindow( *dpy, *wnd );
		XCloseDisplay( *dpy );
		//err2 = "Font init failed.";
		return 0;
	}
	// Compute the shape of the window and adjust the window accordingly
	W += 20;
	H = lines*height2 + height2 + 40;
	W = std::max( W, 200 );
	X = DisplayWidth ( *dpy, DefaultScreen(*dpy) )/2 - W/2;
	Y = DisplayHeight( *dpy, DefaultScreen(*dpy) )/2 - H/2;

	XMoveResizeWindow( *dpy, *wnd, X, Y, W, H );

	// Compute the shape of the OK button
	XTextExtents( font2, "OK", 2, &direction, &ascent, &descent, &overall );

	XFreeFontInfo( 0, font2, 1 ); // We don't need that anymore

	if( !(XehiCbClnt.flags3 & XEHI_CBC_WindowHidden) )
		XMapRaised( *dpy, *wnd );
	return 1;
}

void* xehi_CBClientThreadProc( void* )
{
	Display** dpy = &XehiCbClnt.dpy4;
	Window*   wnd = &XehiCbClnt.wndThr;
	XEvent e; std::string nmeXa;
	XFlush( *dpy );
	while( 1 ){
		int nump = XPending(*dpy);	// ClientMessage
		if( nump ){
			XFlush(*dpy);
		}else{
			if( !XehiCbClnt.bAclrtdMsgLoop )
				usleep( (XehiCbClnt.msPoolItrvl2 * 1000) / 2 );
			continue;
		}
		XNextEvent( *dpy, &e );
		if( e.xany.window != XehiCbClnt.wndThr ){
			XPutBackEvent( *dpy, &e );
			continue;
		}
		switch( e.type ){
		case Expose:
		case MapNotify:
			XClearWindow( *dpy, *wnd );
			XFlush( *dpy );
			break;
		case KeyPress:
		case KeyRelease: //KeyReleaseMask
			{
				int ksm = XLookupKeysym( &e.xkey, 0 );
				if( ksm == XK_Escape || ksm == XK_Return || ( e.type==KeyRelease && ksm == 0x20) )
					goto cleanup;
				if( e.type == KeyPress && ksm == 'c' ){
					printf("c, %lu.\n", (size_t)e.xkey.time );
					xehi_CBClientMakeClipboardOwned( *dpy, *wnd, e.xkey.time );
				}
			}
			break;
		case ClientMessage:
			nmeXa = xehi_GetAtomName( *dpy, e.xclient.message_type );
			if( nmeXa == XehiCbClnt.szWmDeleteWindow ){
				goto cleanup;
			}else if( nmeXa == XehiCbClnt.szWmCBRcv ){ //xaCbRcv
				Window wndOwnr = XGetSelectionOwner( *dpy, XehiCbClnt.xaClip );
				//printf("cb-owner: [%s] (%d), xaClip:%d, xaTargets:%d\n",
				//		xehi_GetWindowName(*dpy,wndOwnr).c_str(), (int)wndOwnr,
				//		(int)XehiCbClnt.xaClip, (int)XehiCbClnt.xaTargets );
				std::string str = xehi_GetWindowName(*dpy,wndOwnr);
				str.resize( sizeof(XehiCbClnt.szOwnerName)-1, 0 );
				strcpy( XehiCbClnt.szOwnerName, str.c_str() );
				XehiCbClnt.szOwnerName[str.size()] = 0;
				// Initializes the 'SelectionNotify' event.
				XehiCbClnt.data3->clear();
				XConvertSelection( *dpy, XehiCbClnt.xaClip, XehiCbClnt.xaTargets,
						XehiCbClnt.xaClip, *wnd,
						CurrentTime );
			}
			break;
		case SelectionNotify:
			{
				XehiCbClnt.bMsglWorking = 1;
				XSelectionEvent& ev2 = *((XSelectionEvent*)&e);
				// member 'ev2.selection' (atom) should be set to "CLIPBOARD" string.
				std::string strSlcnName = xehi_GetAtomName( *dpy, ev2.selection );
				if( strSlcnName == "CLIPBOARD" ){
					//printf("SelectionNotify: time:%d, [%s], eq:%d, [%s]\n",
					//	(int)ev2.time, strSlcnName.c_str(),
					//	(int)(XehiCbClnt.xaClip == ev2.selection),
					//	XehiCbClnt.szOwnerName );
					bool bReceivedAllData2 = 0, rs3;
					rs3 = xehi_CBClientGetDataOnNotify( ev2, *dpy, &bReceivedAllData2, XehiCbClnt.data3 );
					//printf("bReceivedAllData2:%d, n:%d [%s]\n", (int)bReceivedAllData2, (int)XehiCbClnt.data3->size(), XehiCbClnt.szOwnerName );
					//std::vector<uint8_t> data5( data2 );
					//data5.resize( 42, 0 );
					//data5.resize( data5.size()+1, 0 );
					//printf("[%s]\n", &data5[0] );
					if( bReceivedAllData2 || !rs3 ){
						XehiCbClnt.uDataRcvdAt = time(0);
						XehiCbClnt.bMsglWorking = 0;
						if( XehiCbClnt.flags3 & XEHI_CBC_ClipMonitor )
							goto cleanup;
					}
				}
			}
			break;
		case SelectionRequest:{
			XSelectionRequestEvent& ev2 = *((XSelectionRequestEvent*)&e);
			//printf("SelectionRequest-msg, [%s] [%s] t:[%s] p:[%s]\n",
			//		xehi_GetWindowName(*dpy,ev2.requestor).c_str(), xehi_GetAtomName(*dpy,ev2.selection).c_str(),
			//		xehi_GetAtomName(*dpy,ev2.target).c_str(), xehi_GetAtomName(*dpy,ev2.property).c_str()  );
			xehi_CBClientDummySelectionRequestResponse( *dpy, ev2 );
			}break;
		case SelectionClear:{
			if( XehiCbClnt.flags3 & XEHI_CBC_ClipMonitor ){
				//XSelectionClearEvent& ev2 = *((XSelectionClearEvent*)&e);
				Window wnd2 = XGetSelectionOwner( *dpy, XehiCbClnt.xaClip );
				//printf("SelectionClear [%s] [%s]\n",
				//		xehi_GetAtomName(*dpy,ev2.selection).c_str(),
				//		xehi_GetWindowName(*dpy,wnd2).c_str() );
				//usleep(333000);
				//std::vector<uint8_t> data4; std::string err;
				//xehi_SCBGetData scgd;
				//xehi_CBClientGetData_( &data4, scgd, &err );
				//printf("num:%d [%s]\n", (int)data4.size(), err.c_str() );
				if( wnd2 != *wnd ){
					if( (XehiCbClnt.flags3 & XEHI_CBC_NoCBDataOnExit) ){
						goto cleanup;
					}else{
						xehi_CBClientSendClientMessage( XehiCbClnt.dpy4,
							XehiCbClnt.wndThr,
							XehiCbClnt.xaCbRcv, 0,0,0,0,0 );
					}
				}
			}
			break;}
		default:
			break;
		}
	}
cleanup:
	//XFreeGC( *dpy, XehiCbClnt.gc3 );
	//XDestroyWindow( *dpy, *wnd );
	//XCloseDisplay( *dpy );
	//XehiCbClnt.bThrActive = 0;
	if( !(XehiCbClnt.flags3 & XEHI_CBC_NoWindowProcCleanup) )
		xehi_CBClientWindowCleanup();
	return 0;
}
void xehi_CBClientWindowCleanup()
{
	XFreeGC( XehiCbClnt.dpy4, XehiCbClnt.gc3 );
	XDestroyWindow( XehiCbClnt.dpy4, XehiCbClnt.wndThr );
	XCloseDisplay( XehiCbClnt.dpy4 );
	XehiCbClnt.bThrActive = 0;
}
void xehi_CBClientSendClientMessage( Display* dpy2, Window window2, Atom message,
								unsigned long d0, unsigned long d1, unsigned long d2,
								unsigned long d3, unsigned long d4 )
{
	static XClientMessageEvent e;
	memset( &e, 0, sizeof(e) );
	e.type = ClientMessage;
	e.display = dpy2;//0
	e.window = window2;//0
	e.message_type = message;
	e.format = 32;
	e.data.l[0] = d0;
	e.data.l[1] = d1;
	e.data.l[2] = d2;
	e.data.l[3] = d3;
	e.data.l[4] = d4;
	XSendEvent( dpy2, window2, 0, 0, (XEvent*)&e);
}
bool xehi_CBClientCheckInitDone( std::string* err )
{
	std::string err3, &err2 = ( err ? *err : err3 );
	if( XehiCbClnt.verify2 != ~XehiCbClnt.verify3 ){
		err2 = "Unexpected, no prior call to xehi_CBClientInit().";
		return 0;
	}
	return 1;
}
/*
	Clipboard atom examples.
	// 'codeblocks'
	SelectionNotify: time:0, [CLIPBOARD], eq:1, [codeblocks]
	cb-atom-name: [TIMESTAMP]
	cb-atom-name: [TARGETS]
	cb-atom-name: [MULTIPLE]
	cb-atom-name: [TIMESTAMP]
	cb-atom-name: [application/x-cbrectdata]
	cb-atom-name: [UTF8_STRING]
	// 'mtpaint'
	SelectionNotify: time:0, [CLIPBOARD], eq:1, [mtpaint]
	cb-atom-name: [TIMESTAMP]
	cb-atom-name: [TARGETS]
	cb-atom-name: [MULTIPLE]
	cb-atom-name: [application/x-mtpaint-clipboard]
	cb-atom-name: [image/png]
	cb-atom-name: [image/bmp]
	cb-atom-name: [image/x-bmp]
	cb-atom-name: [image/x-MS-bmp]
	cb-atom-name: [PIXMAP]
	cb-atom-name: [BITMAP]
	// 'cli-organizer - CLI clipboard via Hyper+Y'
	SelectionNotify: time:0, [CLIPBOARD], eq:1, []
	cb-atom-name: [TIMESTAMP]
	cb-atom-name: [MULTIPLE]
	cb-atom-name: [TARGETS]
	cb-atom-name: [DELETE]
	cb-atom-name: [INCR]
	cb-atom-name: [TEXT]
	cb-atom-name: [UTF8_STRING]
*/
/// Intended to be called on first and any consecutive X11 SelectionNotify event.
/// Whichever call, data is appended to the 'outp' buffer.
bool xehi_CBClientGetDataOnNotify( const XSelectionEvent& ev2, Display* dpy,
						bool* bHaveAllData, std::vector<uint8_t>* outp )
{
	long bytesread = 0;
	*bHaveAllData = 0;
	if( ev2.property ){
		while( 1 ){ //[LKVrJY1nPC]
			// The Xdnd code pastes 64K chunks together, possibly to avoid
			// bugs in X servers, or maybe to avoid an extra round-trip to
			// get the property length.  I copy this here:
			Atom actual2; int format2, rs2; unsigned long count2, remaining2;
			unsigned char* portion2 = 0;
			rs2 = XGetWindowProperty( dpy, ev2.requestor, ev2.property,
								 bytesread/4, 65536, 1, 0,
								 &actual2, &format2, &count2, &remaining2,
								 &portion2 );
			if( rs2 )
				return 0; // quit on error
			if( actual2 == XehiCbClnt.xaTargets || actual2 == XA_ATOM ){ //[ZsXhgIOE]
				Atom type2 = XA_STRING; //XA_STRING => "STRING"
				const std::vector<Atom>* lst2 = ( !XehiCbClnt.formatsMain4->empty() ? XehiCbClnt.formatsMain4 : XehiCbClnt.formatsMain3 );
				const std::vector<Atom>* lst3 = ( !XehiCbClnt.formatsMain4->empty() ? XehiCbClnt.formatsAlt4  : XehiCbClnt.formatsAlt3 );
				for( unsigned i = 0; i<count2; i++ ){
					Atom atm3 = ((Atom*)portion2)[i];
					if( std::find( lst2->begin(), lst2->end(), atm3 ) != lst2->end() ){
						type2 = atm3;
						break;
					}
					// by defult, rest are only used if no utf-8 available.
					if( std::find( lst3->begin(), lst3->end(), atm3 ) != lst3->end() )
						type2 = atm3;
				}
				XFree(portion2);
				XConvertSelection( dpy, ev2.property, type2, ev2.property,
						XehiCbClnt.wndThr, CurrentTime );
				return 1;
			} //[ZsXhgIOE]
			// // Make sure we got something sane...
			if( !portion2 || (format2 != 8) || !count2 ){
				*bHaveAllData = 1;
				if (portion2) XFree(portion2);
				return 1;
			}
			bool bLimited = 0;
			if( XehiCbClnt.nBytesMax2 != -1 ){
				int num = XehiCbClnt.nReadd + count2;
				if( num > XehiCbClnt.nBytesMax2 ){
					count2 -= ( num - XehiCbClnt.nBytesMax2 );
					assert( count2 >= 0 );
					bLimited = 1;
				}
			}
			XehiCbClnt.nReadd += count2;
			{
				size_t pos = outp->size();
				outp->resize( pos + count2, 0 );
				memcpy( &(*outp)[pos], portion2, count2 );
			}
			XFree( portion2 );
			portion2 = 0;
			bytesread += count2;
			if( !remaining2 || bLimited )
				break;
		}//[LKVrJY1nPC]
	}
	*bHaveAllData = 1;
	return 1;
}

/// \endcond //DOXYGEN_SKIP //[aPInunBX]
;
/// Initializes clipboard client functionality for the process.
/// Whenever fails or not, corresponding xehi_CBClientDeinit() should be called.
/// Tasks performed:
/// * Initializes global data.
/// * Creates new window.
/// * Creates new thread and enters window procedure (if flag
///   XEHI_CBC_ClipMonitor is NOT specified).
/// \param flags2 - flags, fe. \ref XEHI_CBC_ClipMonitor.
/// \sa GP_cb_client
bool xehi_CBClientInit( int flags2, int msPoolItrvl, std::string* err, const char* szUtilWndTitle )
{
	std::string err3, &err2 = ( err ? *err : err3 ), str;
	szUtilWndTitle = ( szUtilWndTitle ? szUtilWndTitle : "xehi_CBClientInit" );
	memset( &XehiCbClnt, 0, sizeof(xehi_SCBClnt) );
	XehiCbClnt.szWmDeleteWindow = "WM_DELETE_WINDOW";
	XehiCbClnt.szWmCBRcv    = "WM_CLIPBOARD_RCV";
	XehiCbClnt.msPoolItrvl2 = msPoolItrvl;
	XehiCbClnt.data3        = new std::vector<uint8_t>;
	XehiCbClnt.verify2      = time(0);
	XehiCbClnt.verify3      = ~XehiCbClnt.verify2;
	XehiCbClnt.nBytesMax2   = -1;
	XehiCbClnt.formatsMain3 = new std::vector<Atom>;
	XehiCbClnt.formatsAlt3  = new std::vector<Atom>;
	XehiCbClnt.formatsMain4 = new std::vector<Atom>;
	XehiCbClnt.formatsAlt4  = new std::vector<Atom>;
	XehiCbClnt.flags3       = flags2;

	str = szUtilWndTitle;
	str.resize( sizeof(XehiCbClnt.szUtilWndTitle2)-1, 0 );
	strcpy( XehiCbClnt.szUtilWndTitle2, str.c_str() );
	XehiCbClnt.szUtilWndTitle2[str.size()] = 0;

	if( !( XehiCbClnt.dpy4  = XOpenDisplay( 0 )) ){
		err2 = "XOpenDisplay() failed.";
		return 0;
	}
	XehiCbClnt.xaWmDelete = XInternAtom( XehiCbClnt.dpy4, XehiCbClnt.szWmDeleteWindow, 0 );
	XehiCbClnt.xaCbRcv    = XInternAtom( XehiCbClnt.dpy4, XehiCbClnt.szWmCBRcv, 0 );
	XehiCbClnt.xaTargets  = XInternAtom( XehiCbClnt.dpy4, "TARGETS", 0 );
	XehiCbClnt.xaClip     = XInternAtom( XehiCbClnt.dpy4, "CLIPBOARD", 0 );
	if( !XehiCbClnt.xaWmDelete || !XehiCbClnt.xaTargets || !XehiCbClnt.xaClip || !XehiCbClnt.xaCbRcv ){
		err2 = "XInternAtom() failed (1).";
		return 0;
	}
	XehiCbClnt.formatsMain3->push_back( XInternAtom(XehiCbClnt.dpy4, "UTF8_STRING", 0) );
	XehiCbClnt.formatsMain3->push_back( XInternAtom(XehiCbClnt.dpy4, "text/plain;charset=UTF-8", 0 ) );
	XehiCbClnt.formatsMain3->push_back( XInternAtom(XehiCbClnt.dpy4, "text/plain", 0 ) );
	const std::vector<Atom>& lst = *XehiCbClnt.formatsMain3;
	if( std::find( lst.begin(), lst.end(), 0 ) != lst.end() ){
		err2 = "XInternAtom() failed (2).";
		return 0;
	}
	XehiCbClnt.formatsAlt3->push_back( XInternAtom(XehiCbClnt.dpy4, "TEXT", 0 ) );
	XehiCbClnt.formatsAlt3->push_back( XInternAtom(XehiCbClnt.dpy4, "text/uri-list", 0 ) );
	XehiCbClnt.formatsAlt3->push_back( XInternAtom(XehiCbClnt.dpy4, "COMPOUND_TEXT", 0 ) );
	const std::vector<Atom>& lst2 = *XehiCbClnt.formatsAlt3;
	if( std::find( lst2.begin(), lst2.end(), 0 ) != lst2.end() ){
		err2 = "XInternAtom() failed (3).";
		return 0;
	}
	if( !xehi_CBClientCreateWindow() )
		return 0;
	if( XehiCbClnt.flags3 & XEHI_CBC_ClipMonitor ){
		if(!xehi_CBClientMakeClipboardOwned( XehiCbClnt.dpy4, XehiCbClnt.wndThr, 0 ) ){
			err2 = "Failed to claim clipboard owneship.";
			return 0;
		}
	}
	if( XehiCbClnt.flags3 & XEHI_CBC_NoWndThreadInit ){
		return 1;
	}else{
		return xehi_CBClientCreateThread( xehi_CBClientThreadProc, 0, 0 );
	}
}
/// Deinits clipboard client.
/// \sa GP_cb_client
bool xehi_CBClientDeinit( std::string* err )
{
	if( !xehi_CBClientCheckInitDone( err ) )
		return 0;
	//printf("snd msg, wnd:%d, dpy:%d, atom-del:%d\n",
	//	(int)XehiCbClnt.wndThr,
	//	(int)(size_t)XehiCbClnt.dpy4,
	//	(int)XehiCbClnt.xaWmDelete );
	xehi_CBClientSendClientMessage( XehiCbClnt.dpy4,
			XehiCbClnt.wndThr,
			XehiCbClnt.xaWmDelete, 0 );
	while( XehiCbClnt.bThrActive ){
		usleep( (XehiCbClnt.msPoolItrvl2 * 1000) / 4 ); //50000
	}
	//printf("exited.\n");
	delete XehiCbClnt.data3;
	delete XehiCbClnt.formatsMain3;
	delete XehiCbClnt.formatsAlt3;
	delete XehiCbClnt.formatsMain4;
	delete XehiCbClnt.formatsAlt4;
	memset( &XehiCbClnt, 0, sizeof(XehiCbClnt) );
	return 1;
}
/// Retrieves clipboard data as the array of bytes.
/// Returns true on success.
/// Success is assumed also if no text-compatible clipboard formats has been found,
/// in which case returned array is empty.
/// \param outp2         - stores data here.
/// \param cfg           - see \ref xehi_SCBGetData.
/// \param err           - textual message on error.
/// \sa GP_cb_client
bool xehi_CBClientGetData( std::vector<uint8_t>* outp2, const xehi_SCBGetData& cfg, std::string* err )
{
	// Wait here for clipboard data to arrive thru remote window message-loop.
	// Switch remote message loop into "fast" mode for the duration of the wait.
	std::string err3, &err2 = ( err ? *err : err3 );
	if( !xehi_CBClientCheckInitDone( &err2 ) )
		return 0;
//	if( XehiCbClnt.idWndThr == pthread_self() ){
//		err2 = "Call from same thread window proc is in. Cannot continue.";
//		return 0;
//	}
	XehiCbClnt.data3->clear();
	XehiCbClnt.uDataRcvdAt = 0;
	XehiCbClnt.bAclrtdMsgLoop = 1;
	XehiCbClnt.szOwnerName[0] = 0;
	XehiCbClnt.nBytesMax2 = cfg.nBytesMax;

	if( cfg.formatsMain5 ){
		*XehiCbClnt.formatsMain4 = *cfg.formatsMain5;
	}else{
		XehiCbClnt.formatsMain4->clear();
	}
	if( cfg.formatsAlt5 ){
		*XehiCbClnt.formatsAlt4 = *cfg.formatsAlt5;
	}else{
		XehiCbClnt.formatsAlt4->clear();
	}
	uint64_t tmRqAt = time(0);
	xehi_CBClientSendClientMessage( XehiCbClnt.dpy4,
			XehiCbClnt.wndThr,
			XehiCbClnt.xaCbRcv, 0,0,0,0,0 );
	int i, numw = cfg.nNumItrns;
	bool bGotCbData = 0, bWorkIncrd = 0;
	for( i=0; numw-- || (bWorkIncrd && cfg.nNumWorkItrns == -1) ; i++ ){
		if( XehiCbClnt.uDataRcvdAt >= tmRqAt ){
			bGotCbData = 1;
			break;
		}
		usleep( (XehiCbClnt.msPoolItrvl2 * 1000) / 4 );
		if( XehiCbClnt.bMsglWorking && !bWorkIncrd ){
			bWorkIncrd = 1;
			numw += cfg.nNumWorkItrns;
		}
	}
//	std::vector<uint8_t>& dt3 = *XehiCbClnt.data3_;
//	printf("-- cb-data: %s, i:%d n:%d wi:%d, o:[%s] --\n",
//			(bGotCbData ? "YES" : "NO!"), i, (int)dt3.size(), (int)bWorkIncrd,
//			XehiCbClnt.szOwnerName );
	XehiCbClnt.bAclrtdMsgLoop = 0;
	XehiCbClnt.bMsglWorking = 0;
	if( !bGotCbData ){
		err2 = "Couldn't retrieve clipboard data.";
		return 0;
	}
	if( XehiCbClnt.data3->empty() ){
		err2 = "Empty clipboard data.";
		return 0;
	}
	std::swap( *outp2, *XehiCbClnt.data3 );
	XehiCbClnt.data3->clear();
	return 1;
}
bool xehi_CBClientGetData2( std::vector<uint8_t>* outp2, std::string* err )
{
	std::string err3, &err2 = ( err ? *err : err3 );
	if( !xehi_CBClientCheckInitDone( &err2 ) )
		return 0;
	*outp2 = *XehiCbClnt.data3;
	return 1;
}

bool xehi_CBClientMakeClipboardOwned( Display* dpy, Window wid, Time tmstamp )
{
	//printf("XSetSelectionOwner(,,%d,%lu).\n", (int)wid, (size_t)tmstamp );
	XehiCbClnt.cbd.tmClaimedAt = 0;
	XSetSelectionOwner( dpy, XehiCbClnt.xaClip, wid, tmstamp ); //hf_getTimeTicksMs()
	Window wid2 = XGetSelectionOwner( dpy, XehiCbClnt.xaClip );
	if( wid != wid2 ){
		printf("ERROR: XSetSelectionOwner() failed.\n");
		return 0;
	}
	XehiCbClnt.cbd.tmClaimedAt = tmstamp;
	//SelectionRequest,SelectionClear
	return 1;
}
/// Dummy response on X11 SelectionRequest event message.
/// When CB Client owns the clipboard (XSetSelectionOwner()), the
/// SelectionRequest event must
/// be dispatched according to X11 rules. this function is a minimal
/// implementation of this, it notifies requestor that the data is invalid.
/// Otherwise, if SelectionRequest event wasn't to be implemented, it may cause
/// unexpected behaviour in other applications, fe:
/// * Mozilla Firefox - freezes for aprox 3 seconds.
/// * Code::Blocks - copy|paste stops to function for unknown period of time.
void xehi_CBClientDummySelectionRequestResponse( Display* dpy, const XSelectionRequestEvent& ev2 )
{
	XSelectionEvent se2;
	memset( &se2, 0, sizeof(se2) );
	se2.type       = SelectionNotify;
	se2.send_event = 1;
	se2.display    = dpy;
	se2.time       = ev2.time; //0;//hf_getTimeTicksMs();
	se2.property   = None;
	se2.selection  = ev2.selection;
	se2.requestor  = ev2.requestor; //Important.
	//long msk = SubstructureNotifyMask | SubstructureRedirectMask;
	XSendEvent( dpy, ev2.requestor, 1, 0, (XEvent*)&se2 );
}

/// Example main() function that uses CB-client functions and exits when
/// other application claims clipboard owneship.
int xehi_CBClientFnMainExample_1( int argc, const char*const* argv )
{
	std::string err;
	int fl2 = XEHI_CBC_ClipMonitor | XEHI_CBC_NoWndThreadInit;
	fl2 |= XEHI_CBC_WindowHidden;
	if( !xehi_CBClientInit( fl2, 51, &err, 0 ) ){ //ClientMessage
		printf("xehi_CBClientInit() failed [%s].\n", err.c_str() );
		return 1;
	}
	xehi_CBClientThreadProc(0);

	std::vector<uint8_t> data2;
	xehi_CBClientGetData2( &data2, 0 );
	data2.resize( data2.size()+1, 0 );
	printf("cb: [%s]\n", (const char*)&data2[0] );

	if( !xehi_CBClientDeinit() )
		return 1;
	return 0;
}
/// Example main() function that prints every clipboard change,
/// a montor thru STDOUT.
int xehi_CBClientFnMainExample_2( int argc, const char*const* argv )
{
	std::string err;
	int fl2 = XEHI_CBC_ClipMonitor | XEHI_CBC_NoWndThreadInit;
	fl2 |= XEHI_CBC_WindowHidden;
	fl2 |= XEHI_CBC_NoWindowProcCleanup;
	if( !xehi_CBClientInit( fl2, 51, &err, 0 ) ){ //ClientMessage
		printf("xehi_CBClientInit() failed [%s].\n", err.c_str() );
		return 1;
	}
	for( ;; ){
		xehi_CBClientThreadProc(0);

		std::vector<uint8_t> data2;
		xehi_CBClientGetData2( &data2, 0 ); //SelectionClear
		data2.resize( data2.size()+1, 0 );
		Window wndOwnr = XGetSelectionOwner( XehiCbClnt.dpy4, XehiCbClnt.xaClip );
		printf("cb: [%s] [%s]\n", (const char*)&data2[0],
				xehi_GetWindowName(XehiCbClnt.dpy4,wndOwnr).c_str() );

		xehi_CBClientMakeClipboardOwned(
			XehiCbClnt.dpy4, XehiCbClnt.wndThr, 0 );
	}
	xehi_CBClientWindowCleanup();
	if( !xehi_CBClientDeinit() )
		return 1;
	return 0;
}
