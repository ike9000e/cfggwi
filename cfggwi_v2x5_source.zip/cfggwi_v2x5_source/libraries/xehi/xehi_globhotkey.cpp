
#include "xehi_globhotkey.h"
#include <string.h>
#include "hef/hef_str.h"
#include "hef/hef_str_piece.h"

/// Returns "bad" modkeys, problematic on X11. Since there is no good
/// way to avoid CapsLock/Numlock to count as modkey, this function returns them
/// in output array.
/// Some concepts taken from Audacius global hotkeys plugin.
/// Hardcoded return value, most importantly, function serves as an example.
/// Comprehensive way would be to provide configuration to end-user for finding
/// out unwanted modkeys.
size_t xehi_GetBadModkeys( Display* dpy, std::vector<size_t>& modifiers2 )
{
	int i;
	XModifierKeymap *modmap;
	KeyCode nlock, slock;
	static const int mask_table[8] = {
		ShiftMask, LockMask, ControlMask, Mod1Mask,
		Mod2Mask, Mod3Mask, Mod4Mask, Mod5Mask
	};
	nlock = XKeysymToKeycode( dpy, XK_Num_Lock );
	slock = XKeysymToKeycode( dpy, XK_Scroll_Lock );
	//
	// Find out the masks for the NumLock and ScrollLock modifiers,
	// so that we can bind the grabs for when they are enabled too.
	//
	modmap = XGetModifierMapping(dpy);
	if( modmap ){
		for( i = 0; i < 8 * modmap->max_keypermod; i++ ){
			if( modmap->modifiermap[i] == nlock && nlock ){
				// numlock_mask
				modifiers2.push_back( mask_table[i / modmap->max_keypermod] );
			}else if( modmap->modifiermap[i] == slock && slock ){
				// scrolllock_mask
				modifiers2.push_back( mask_table[i / modmap->max_keypermod] );
			}
		}
	}
	//capslock_mask = LockMask;
	modifiers2.push_back( LockMask );
	if( modmap ){
		XFreeModifiermap (modmap);
	}
	//
	size_t uBadModks2 = 0;
	std::vector<size_t>::const_iterator a;
	for( a = modifiers2.begin(); a != modifiers2.end(); ++a ){
		//printf("badmodk: 0x%X\n", (uint)*a );
		uBadModks2 |= *a;
	}
	return uBadModks2;
}
/// Implementation of XGrabKey() as more comprehensive function.
bool xehi_GrabKey( size_t keycode, size_t modifier,
				const std::vector<size_t>& lsBadModkeys, Display* xdisplay,
				Window x_root_window )
{
	// capslock_mask = LockMask;	//ShiftMask
	size_t uCntKey = 0;
	{
		// modifier &= ~(numlock_mask | capslock_mask | scrolllock_mask);
		std::vector<size_t>::const_iterator a;
		for( a = lsBadModkeys.begin(); a != lsBadModkeys.end(); ++a ){
			modifier &= ~(*a);
		}
	}
	//printf("Adding hotkey, n:%d.\n", (int)uCntKey );
	int res = XGrabKey( xdisplay, keycode, modifier, x_root_window,
				False, GrabModeAsync, GrabModeAsync );
	//if( res )	//if error
	if( res == BadAccess || res == BadValue || res == BadWindow ){
		return 0;
	}
	++uCntKey;
	if( modifier == AnyModifier )
		return 0;
	//
	{
		std::vector<size_t>::const_iterator a;
		for( a = lsBadModkeys.begin(); a != lsBadModkeys.end(); ++a ){
			++uCntKey;
			//printf("Adding hotkey, n:%d.\n", (int)uCntKey );
			XGrabKey( xdisplay, keycode, modifier | *a,
					x_root_window, false, GrabModeAsync, GrabModeAsync );
		}
	}
	{
		std::vector<size_t>::const_iterator a, b;
		for( a = lsBadModkeys.begin(); a != lsBadModkeys.end(); ++a ){
			for( b = lsBadModkeys.begin(); b != lsBadModkeys.end(); ++b ){
				if( a != b ){
					++uCntKey;
					//printf("Adding hotkey, n:%d.\n", (int)uCntKey );
					XGrabKey( xdisplay, keycode, modifier | *a | *b,
							x_root_window, false, GrabModeAsync, GrabModeAsync );
				}
			}
		}
	}
	return 1;
}

/// Suplementary of xehi_GrabKey(), intended to be called once application is done
/// with all it's registered global hotkeys.
/// Note that currently (20140712) thare are
/// no function that can un-grab single key sequence.
void xehi_UngrabAllKeys( Display* xdisplay, Window x_root_window )
{
	//if (!grabbed) return;
	if (!xdisplay)
		return;
	XUngrabKey( xdisplay, AnyKey, AnyModifier, x_root_window );
	//grabbed = 0;
}

/// Intended to be used to test whenever X key-press event
/// (XEvent::XKeyEvent==KeyPress) is a global hotkey event.
/// Fe. when actual x11 key event happens, call to this function
/// will return true if it is in regard to a combination given in
/// 'key' and 'modkeys' parameters.
/// 'key' and 'modkeys' correspond to 'keycode' and 'modifier' in call to
/// xehi_GrabKey(), respectivelly, an original call that registered global hotkey.
bool xehi_IsGHEvent( const XKeyEvent& evt2, size_t key, size_t modkeys, size_t uBadModks )
{
	// evt: XEvent
	// evt.xkey: XKeyEvent
	if( evt2.keycode == key ){
		if( modkeys == (evt2.state & ~uBadModks) ){
			return 1;
		}
	}
	return 0;
}

/// Test function for main(). Ie. application can replace it's main() with
/// this one.
/// Registers following global combinations:
/// 1. Alt+Shift+S
/// 2. Alt+Shift+E
/// Once 2 is triggered, all global hotkeys are turned off.
/// Press Ctrl+C to close.
int xehi_GlobHotkeyMain()
{
	//return xehi_main();
	Display* dpy = XOpenDisplay(0);
	Window   rootw = DefaultRootWindow(dpy);
	XEvent   evt;
	size_t   uModkeys = ShiftMask | Mod1Mask;	//Mod1Mask = Alt. ControlMask | ShiftMask;
	int      nKey1 = XKeysymToKeycode(dpy,XK_S);
	int      nKey2 = XKeysymToKeycode(dpy,XK_E);

	std::vector<size_t> lsBadModkeys2;
	size_t uBadModks3 = xehi_GetBadModkeys( dpy, lsBadModkeys2 );
	xehi_GrabKey( nKey1, uModkeys, lsBadModkeys2, dpy, rootw );
	xehi_GrabKey( nKey2, uModkeys, lsBadModkeys2, dpy, rootw );
	XSelectInput( dpy, rootw, KeyPressMask );
	printf("Entering message loop...\n");
	while(1){
		bool shouldQuit = 0;
		XNextEvent(dpy, &evt);
		switch(evt.type){
		case KeyPress:{
				bool bKey1 = xehi_IsGHEvent( evt.xkey, nKey1, uModkeys, uBadModks3 );
				printf("Hot key pressed, k:%u, state:%u, bKey1:%d, tm:%X.\n",
						evt.xkey.keycode, evt.xkey.state, bKey1,
						(unsigned int)evt.xkey.time );
				bool bKey2 = xehi_IsGHEvent( evt.xkey, nKey2, uModkeys, uBadModks3 );
				if(bKey2){
					xehi_UngrabAllKeys( dpy, rootw );
				}
			}
			break;
		}
		if(shouldQuit)
			break;
	}
	xehi_UngrabAllKeys( dpy, rootw );
	XCloseDisplay(dpy);
	return 0;
}
/*
	// XK_Shift_L   = 0xffe1, ShiftMask=1<<0 = 1
	// XK_Shift_R   = 0xffe2, ShiftMask=1<<0 = 1
	// XK_Control_L = 0xffe3, ControlMask=1<<2 = 4
	// XK_Control_R = 0xffe4, ControlMask=1<<2 = 4
	// XK_Alt_L     = 0xffe9, Mod1Mask=1<<3 = 8
	// XK_Alt_R     = 0xffea, Mod1Mask=1<<3 = 8
	// XK_Super_L   = 0xffeb, Mod4Mask=1<<6 = 64
	// XK_Super_R   = 0xffec, Mod4Mask=1<<6 = 64
	// Note: Mod1Mask is mask for both Alt modkeys
	//       Mod4Mask is mask for both Super modkeys (aka Winkey)
	// references:
	// * /usr/include/X11/keysymdef.h
	// * /usr/include/X11/X.h
*/

int xehi_GetCommonX11Modkeys( const XehiSX11Modkey** outp )
{
	static const XehiSX11Modkey arModkeys[] = {
		{ XK_Shift_L   , ShiftMask  , "Shift_L"  , 0, 0xFFE1, },
		{ XK_Shift_R   , ShiftMask  , "Shift_R"  , 0, 0xFFE2, },
		{ XK_Control_L , ControlMask, "Control_L", 0, 0xFFE3, },
		{ XK_Control_R , ControlMask, "Control_R", 0, 0xFFE4, },
		{ XK_Alt_L     , Mod1Mask   , "Alt_L"    , 0, 0xFFE9, },
		{ XK_Alt_R     , Mod1Mask   , "Alt_R"    , 0, 0xFE03, },
		{ XK_Super_L   , Mod4Mask   , "Super_L"  , 0, 0xFFEB, },
		{ XK_Super_R   , Mod4Mask   , "Super_R"  , 0, 0xFFEC, },
		// keysym code for Hyper keys unknown ATM.
		{ XK_Hyper_L   , Mod5Mask   , "Hyper_L"  , 0, 0, },
		{ XK_Hyper_R   , Mod5Mask   , "Hyper_R"  , 0, 0, },
	};
	// use XKeysymToString() on keyco
	// KeySym ksm = XKeycodeToKeysym( dpy, kcc, 0 ); //deprecated...
	*outp = arModkeys;
    return sizeof(arModkeys)/sizeof(arModkeys[0]);
}
/// Returns masks and names array.
/// \param flags2 - fe. \ref XEHI_CM_AddNonLRModkeys.
void xehi_GetCommonX11ModkeyMasksAndNames( std::vector<std::pair<uint32_t,std::string> >& outp, uint32_t flags2 )
{
	const XehiSX11Modkey* ar2;
	int nummk = xehi_GetCommonX11Modkeys( &ar2 );
	for( int i=0; i<nummk; i++ ){
		const XehiSX11Modkey* smk = &ar2[i];
		outp.push_back( std::make_pair( smk->modmask, smk->name_a ) );
	}
	if( flags2 & XEHI_CM_AddNonLRModkeys ){
		// reiterate, convert and add fe Control_L -> Control, Shift_R -> Shift, etc.
		std::vector<std::pair<uint32_t,std::string> >::iterator a;
		std::vector<int>::iterator b;
		std::vector<int> idxsadd; int i; std::string str;
		const char* szULSuff = "_L";
		for( i=0, a = outp.begin(); a != outp.end(); i++, ++a ){
			if( hf_strEndsWith( a->second.c_str(), szULSuff ) )
				idxsadd.push_back(i);
		}
		for( b = idxsadd.begin(); b != idxsadd.end(); ++b ){
			uint32_t modkkmask2 = outp[*b].first;
			str = outp[*b].second;
			str.resize( str.size() - hf_strlen(szULSuff) );
			outp.push_back( std::make_pair( modkkmask2, str.c_str() ) );
		}
	}
}

/*
	//XFreeModifiermap()
	//
	// >> To obtain the KeyCodes used as modifiers, use XGetModifierMapping().
	// XStringToKeysym()
	// XKeycodeToKeysym()
	// XKeysymToString()

	int kcmin = 0, kcmax = 0;
	XDisplayKeycodes( dpy, &kcmin, &kcmax );
	printf("kcmin:%d, kcmax:%d\n", kcmin, kcmax );
	int kccount = kcmax - kcmin + 1, ksmpkc = 0; KeySym* keysyms = 0;
	keysyms = XGetKeyboardMapping( dpy, kcmin, kccount, &ksmpkc );
	if( !keysyms )
		return 0;
	printf("kccount:%d, ksmpkc:%d\n", kccount, ksmpkc );
	int nKssCount = kccount * ksmpkc;
	nKssCount=nKssCount;
	// XStringToKeysym()
	for( int x=0; x<kccount; x++ ){
		int idx2 = x * ksmpkc;
		int y=0;
		for( y=0; y<ksmpkc; y++ ){
			KeySym kss = keysyms[ idx2 + y ];
			KeyCode kcc2 = XKeysymToKeycode(dpy,kss);
			int kcc3 = kcmin + x;
		//	if( kss == 0x20 ){
				const char* szKy2 = XKeysymToString( kss );
				printf("szKy2#%d#%d: %d [%s], kcc2:0x%X, kcc3:0x%X\n", x, y, (kss==NoSymbol?0:1), (szKy2 ? szKy2 : "<null>" ), (uint32_t)kcc2, kcc3 );
		//	}
		}
	}
	XFree( keysyms );
	*/
/*	XModifierKeymap* sxm = XGetModifierMapping( dpy );
	if(!sxm)
		return 0;
	printf("max_keypermod: %d\n", sxm->max_keypermod );
	for( int i=0; i < sxm->max_keypermod; i++ ){
		KeyCode kcc = sxm->modifiermap[i];
		KeySym ksm = XKeycodeToKeysym( dpy, kcc, 0 ); //deprecated...
		const char* szKy = XKeysymToString( ksm );
		printf("szKy: [%s], kcc:%d\n", (szKy ? szKy : "<null>"), kcc );
	}
	XFreeModifiermap(sxm);
*/

/// Parses hotkey combination as one or more key names separated by plus ("+") character.
/// \param szTrig - key combination, plus-separated key names, can contain whitespaces inbetween.
/// \param err - optional, message on error.
/// Returns 0 on failure.
/// based on: CGlobHtks::parseHotkeyTrigger
bool xehi_ParseHotkeyTriggerSimple( const char* szTrig, std::vector<int>& keysOu, std::string* err )
{
	std::vector<std::string> strs; KeySym ksm;
	std::vector<std::string>::const_iterator b;
	std::string err3, *err2 = ( err ? err : &err3 ); char bfr[128];
	*err2 = "";
	keysOu.clear();
	hf_explode( szTrig, "+", strs, "\r\n\x20\t" );
	for( b = strs.begin(); b != strs.end(); ++b ){
		ksm = XStringToKeysym( b->c_str() );
		if( ksm == NoSymbol ){
			sprintf(bfr,"Key name not recognized (%s).", std::string(b->c_str(), std::min<int>(b->size(),42)).c_str() );
			*err2 = bfr;
			return 0;
		}else{
			keysOu.push_back( ksm );
		}//*/
	}//*/
	if( keysOu.empty() ){
		*err2 = "No key names found.";
		return 0;
	}
	return 1;
}

/**
	Return key states as 32-bit integer.
	Returned are flags corresponding to key values in input array.
	0x1 is set if corresponding arKeys[0] key is pressed,
	0x2 is set if corresponding arKeys[1] key is pressed,
	0x4 is set if corresponding arKeys[2] key is pressed,
	and so forth.
	\param bAllDown - optional, set if all requested keys were pressed down.
	\param flags3 - flags, fe. \ref XEHI_TK_LRModKeysNotMerged.
	\code
		// Example:
		std::vector<int> arKeys = {XK_Shift_L,XK_Shift_R,};
		uint32_t states2 = xehi_TestKeysDown( display2, &arKeys[0], arKeys.size(), 0,0 );
		printf("states2: 0x%X\n", states2 );
		// output is 0x3 if both shift keys were pressed, ie. two lower bits set.
		// if only right shift (XK_Shift_R) was pressed, returned is 0x2.
	\endcode
*/
uint32_t xehi_TestKeysDown( Display* dpy2, const int* arKeys, int numkeys, bool* bAllDown, uint32_t flags3 )
{
	//KeyCode kc4 = XKeysymToKeycode( dpy2, XK_Shift_L );
	//KeyCode kc5 = XKeysymToKeycode( dpy2, XK_Shift_R );
	//printf("kc4-dn: %d\n", (int)( !!( keys_return[ kc4>>3 ] & ( 1<<(kc4&7) ) ) ) );
	//printf("kc5-dn: %d\n", (int)( !!( keys_return[ kc5>>3 ] & ( 1<<(kc5&7) ) ) ) );
	bool bNoLrm = ( flags3 & XEHI_TK_LRModKeysNotMerged );
	static const int arrL[] = { XK_Control_L, XK_Shift_L, XK_Alt_L, XK_Super_L, XK_Hyper_L, };
	static const int arrR[] = { XK_Control_R, XK_Shift_R, XK_Alt_R, XK_Super_R, XK_Hyper_R, };
	static const int nmodkL = sizeof(arrL)/sizeof(arrL[0]);
	char mdksfnd[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};
	uint32_t outp = 0;
	bool bDown; KeyCode kc2; int i;
	char keys_return[32];
	XQueryKeymap( dpy2, keys_return );
	for( i=0; i<numkeys; i++ ){
		kc2 = XKeysymToKeycode( dpy2, arKeys[i] );
		bDown = 0;
		bDown |= !!( keys_return[ kc2>>3 ] & ( 1<<(kc2&7) ) );
		if( !bDown && !bNoLrm ){
			for( int k=0; k<nmodkL; k++ ){
				if( arrL[k] == arKeys[i] ){
					kc2 = XKeysymToKeycode( dpy2, arrR[k] );
					bDown |= !!( keys_return[ kc2>>3 ] & ( 1<<(kc2&7) ) );
					break;
				}else if( arrR[k] == arKeys[i] ){
					kc2 = XKeysymToKeycode( dpy2, arrL[k] );
					bDown |= !!( keys_return[ kc2>>3 ] & ( 1<<(kc2&7) ) );
					break;
				}
			}
		}
		if( !(flags3 & XEHI_TK_ModKeysNonExclusiveOk) ){
			for( int k=0; k<nmodkL; k++ ){
				if( arrL[k] == arKeys[i] || arrR[k] == arKeys[i] ){
					mdksfnd[k] = 1;
				}
			}
		}
		outp |= ( bDown << i );
	}
	bool bOtherMdksDown = 0;
	if( !(flags3 & XEHI_TK_ModKeysNonExclusiveOk) ){
		// check if other modkeys are down to prevent over-trigger.
		for( int k=0; k<nmodkL; k++ ){
			if( !mdksfnd[k] ){
				kc2 = XKeysymToKeycode( dpy2, arrL[k] );
				bDown = !!( keys_return[ kc2>>3 ] & ( 1<<(kc2&7) ) );
				kc2 = XKeysymToKeycode( dpy2, arrR[k] );
				bDown |= !!( keys_return[ kc2>>3 ] & ( 1<<(kc2&7) ) );
				if( bDown ){
					bOtherMdksDown = 1;
					break;
				}
			}
		}
	}
	if(bAllDown)
		*bAllDown = !!( !bOtherMdksDown && ( outp == (uint32_t) ( ( 1<<numkeys ) - 1) ) );
	return outp;
}
/// Differs from xehi_TestKeysDown() by return value.
/// Returns true if all keys were down (pressed).
/// \param flags3 - flags fe. \ref XEHI_TK_LRModKeysNotMerged.
bool xehi_TestKeysDown2( Display* dpy2, const int* arKeys, int numkeys, uint32_t flags3 )
{
	bool bAllDown = 0;
	xehi_TestKeysDown( dpy2, arKeys, numkeys, &bAllDown, flags3 );
	return bAllDown;
}
/// Alternate parameters version.
/// \sa xehi_TestKeysDown()
uint32_t xehi_TestKeysDown3( Display* dpy2, const std::vector<int>& arKeys, bool* bAllDown, uint32_t flags3 )
{
	return xehi_TestKeysDown( dpy2, &arKeys[0], arKeys.size(), bAllDown, flags3 );
}
