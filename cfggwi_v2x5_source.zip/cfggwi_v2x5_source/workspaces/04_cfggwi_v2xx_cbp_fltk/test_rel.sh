#!/bin/bash
#

	szBasedir="$(dirname "$(readlink -f "$0")")"
	
	szExec="$szBasedir/bin/Release/cfggwi"

	##cd /tmp

	"$szExec" -c "$szBasedir/user_ctrls.json" -d "$szBasedir/user_dflts.ini" \
				-o "$szBasedir/out.ini" \
				--LXColorsFix --bFontS2 1 --fUiScale 1.6 \
				--fltk-- -bg2 "#AABBCC" \
				"$@"
